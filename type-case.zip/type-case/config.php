<?php

$con = mysqli_connect("localhost","demowdix_typecase","deWLrh?}N6P[","demowdix_typecase")or die("Not Database connect");


?>