<?php 
    function path(){
        echo "https://demowdi.xyz/type-case";
    }
    // session_start();
    include 'config.php';
?>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="icon" href="<?php path();?>/assets/images/favicon.png" type="image/x-icon" />
<title>Typecase</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;400;500;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?php path();?>/assets/css/swiper-bundle.min.css">
<!--Plugin CSS file with desired skin-->
<link rel="stylesheet" href="<?php path();?>/assets/css/ion.rangeSlider.min.css"/>
<link rel="stylesheet" href="<?php path();?>/assets/css/font-awesome.min.css"/>
  
<!-- Icon css link -->
<link href="<?php path();?>/assets/css/bootstrap.min.css" rel="stylesheet">
<link href="<?php path();?>/assets/css/style.css" rel="stylesheet">
<script async src="https://cdn.razorpay.com/widgets/trusted-badge.js" ></script>