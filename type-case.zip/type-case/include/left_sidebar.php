<div class="left_sidebar">
    <ul>
        <li><a href="<?php path();?>/dashboard.php">dashboard</a></li>
        <li><a href="<?php path();?>/my-account.php">My account</a></li>
        <li><a href="<?php path();?>/orders.php">My Orders</a></li>
        <li><a href="<?php path();?>/track-order.php">Track Orders</a></li>
        <li><a href="<?php path();?>/addresses.php">Addresses</a></li>
        <li><a href="<?php path();?>/logout.php">Logout</a></li>
    </ul>
</div>