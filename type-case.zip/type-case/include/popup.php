<div class="popup fixed-stretch d-none js-popup">
    <div class="popup__bg fixed-stretch cursor-pointer pointer-events-none"></div>
    <div class="popup__body position-relative d-none flex-lg-column" id="navigation">
        <div class="popup-navigation js-popup-navigation">
            <div class="popup-navigation__head p-2 pt-3 d-lg-none">
                <div class="container">
                    <div class="popup-navigation__button d-flex align-items-center" data-js-popup-navigation-button="close">
                        <i class="popup-navigation__close cursor-pointer" data-js-popup-close="" data-button-content="close">
                            <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-theme-164" viewBox="0 0 24 24">
                                <path d="M19.583 4.965a.65.65 0 0 1-.176.449l-6.445 6.426 6.445 6.426c.117.131.176.28.176.449a.65.65 0 0 1-.176.449.846.846 0 0 1-.215.127.596.596 0 0 1-.468 0 .846.846 0 0 1-.215-.127l-6.426-6.445-6.426 6.445a.846.846 0 0 1-.215.127.596.596 0 0 1-.468 0 .846.846 0 0 1-.215-.127.65.65 0 0 1-.176-.449c0-.169.059-.318.176-.449l6.445-6.426-6.445-6.426a.65.65 0 0 1-.176-.449c0-.169.059-.318.176-.449a.652.652 0 0 1 .449-.176c.169 0 .319.059.449.176l6.426 6.445 6.426-6.445a.652.652 0 0 1 .449-.176c.169 0 .319.059.449.176.117.13.176.28.176.449z"></path>
                            </svg>
                        </i>
                        <i class="popup-navigation__back cursor-pointer d-lg-none" data-button-content="back">
                            <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-theme-012" viewBox="0 0 24 24">
                                <path d="M21.036 12.569a.601.601 0 0 1-.439.186H4.601l4.57 4.551c.117.13.176.28.176.449a.652.652 0 0 1-.176.449.877.877 0 0 1-.215.127.596.596 0 0 1-.468 0 .877.877 0 0 1-.215-.127l-5.625-5.625a2.48 2.48 0 0 1-.068-.107c-.02-.032-.042-.068-.068-.107a.736.736 0 0 1 0-.468 2.48 2.48 0 0 0 .068-.107c.02-.032.042-.068.068-.107l5.625-5.625a.652.652 0 0 1 .449-.176c.169 0 .319.059.449.176.117.13.176.28.176.449a.652.652 0 0 1-.176.449l-4.57 4.551h15.996a.6.6 0 0 1 .439.186.601.601 0 0 1 .186.439.599.599 0 0 1-.186.437z"></path>
                            </svg>
                        </i>
                    </div>
                </div>
            </div>
            <div class="popup-navigation__search search pt-lg-4 pb-lg-4 px-2 px-lg-0 js-popup-search-ajax" data-js-max-products="6">
                <div class="container">
                    <div class="d-none d-lg-flex align-items-lg-center mb-1 mb-lg-2">
                        <p class="m-0">WHAT ARE YOU LOOKING FOR?</p>
                        <i class="search__close ml-auto cursor-pointer" data-js-popup-close="">
                            <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-theme-164" viewBox="0 0 24 24">
                                <path d="M19.583 4.965a.65.65 0 0 1-.176.449l-6.445 6.426 6.445 6.426c.117.131.176.28.176.449a.65.65 0 0 1-.176.449.846.846 0 0 1-.215.127.596.596 0 0 1-.468 0 .846.846 0 0 1-.215-.127l-6.426-6.445-6.426 6.445a.846.846 0 0 1-.215.127.596.596 0 0 1-.468 0 .846.846 0 0 1-.215-.127.65.65 0 0 1-.176-.449c0-.169.059-.318.176-.449l6.445-6.426-6.445-6.426a.65.65 0 0 1-.176-.449c0-.169.059-.318.176-.449a.652.652 0 0 1 .449-.176c.169 0 .319.059.449.176l6.426 6.445 6.426-6.445a.652.652 0 0 1 .449-.176c.169 0 .319.059.449.176.117.13.176.28.176.449z"></path>
                            </svg>
                        </i>
                    </div>
                    <form class="position-relative d-flex align-items-center pb-1 pb-lg-3 mb-0 border-bottom" action="/search" method="get" role="search" siq_id="autopick_2906">
                        <input type="search" class="border-0 p-0 mb-0" name="q" id="Search" value="" placeholder="Search products...">
                        <input type="hidden" name="options[prefix]" value="" aria-hidden="true">
                        <label class="position-absolute right-0 mb-0 mr-0 m-lg-0 cursor-pointer" for="Search">
                            <i>
                                <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-theme-168" viewBox="0 0 24 24">
                                    <path d="M13.261 2.475a8.177 8.177 0 0 1 2.588 1.738 8.172 8.172 0 0 1 1.738 2.588 7.97 7.97 0 0 1 .635 3.164 7.836 7.836 0 0 1-.527 2.861 8.355 8.355 0 0 1-1.426 2.412l4.902 4.902c.117.131.176.28.176.449s-.059.319-.176.449c-.065.052-.137.095-.215.127s-.156.049-.234.049-.156-.017-.234-.049-.149-.075-.215-.127l-4.902-4.902c-.703.6-1.507 1.074-2.412 1.426s-1.859.528-2.862.528a7.945 7.945 0 0 1-3.164-.635 8.144 8.144 0 0 1-2.588-1.738 8.15 8.15 0 0 1-1.738-2.588 7.962 7.962 0 0 1-.635-3.164 7.97 7.97 0 0 1 .635-3.164 8.172 8.172 0 0 1 1.738-2.588 8.15 8.15 0 0 1 2.588-1.738c.989-.423 2.044-.635 3.164-.635s2.174.212 3.164.635zM3.759 12.641c.358.834.85 1.563 1.475 2.188s1.354 1.117 2.188 1.475c.833.358 1.726.537 2.676.537s1.843-.179 2.676-.537c.833-.357 1.563-.85 2.188-1.475s1.116-1.354 1.475-2.188a6.705 6.705 0 0 0 .537-2.676c0-.95-.179-1.842-.537-2.676-.358-.833-.85-1.563-1.475-2.188s-1.354-1.116-2.188-1.475c-.835-.356-1.727-.536-2.677-.536s-1.843.18-2.676.537c-.833.358-1.563.85-2.188 1.475S4.117 6.456 3.759 7.289a6.694 6.694 0 0 0-.537 2.676c0 .951.178 1.843.537 2.676z"></path>
                                </svg>
                            </i>
                        </label>
                    </form>
                    <div class="search__content">
                        <div class="search__result row pt-2 pt-lg-0 mt-3 mt-lg-4 d-none"></div>
                        <div class="search__view-all pb-20 pb-lg-0 mt-20 mt-lg-10 d-none">
                            <a href="/search?q=&amp;options[prefix]=last" class="btn-link">View all products</a>
                        </div>
                    </div>
                    <p class="search__empty pb-20 pb-lg-0 mt-20 mt-lg-30 mb-0 d-none">
                        <a href="/search?q=&amp;options[prefix]=last" class="btn-link">Search for d-lg-none" <span></span>" </a>
                    </p>
                </div>
            </div>
            <div class="popup-navigation__menu px-10" data-js-menu-mobile="">
                <div class="container" data-js-position-mobile="vertical-menu"></div>
            </div>
            <div class="popup-navigation__menu pt-4 pb-4 px-2" data-js-menu-mobile="">
                <div class="container" data-js-position-mobile="menu">
                    <nav class="menu menu--main js-menu js-position menu--loaded" data-js-position-name="menu">
                        <div class="menu__panel menu__list menu__level-01 d-flex flex-column flex-lg-row flex-lg-wrap d-lg-none" data-mobile-level="1">
                            <div class="menu__curtain d-none position-lg-absolute"></div>
                            <div class="menu__item menu__item--has-children has_subchild position-lg-relative">
                                <a href="javascript:void(0)" class="d-flex align-items-center" data-parent="2">
                                    <span>Products</span>
                                    <i class="menu__item_arrow d-none d-lg-flex position-lg-relative mr-0">
                                        <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-theme-229" viewBox="0 0 24 24">
                                            <path d="M11.783 14.088l-3.75-3.75a.652.652 0 0 1-.176-.449c0-.169.059-.319.176-.449a.65.65 0 0 1 .449-.176c.169 0 .318.059.449.176l3.301 3.32 3.301-3.32a.65.65 0 0 1 .449-.176c.169 0 .318.059.449.176.117.13.176.28.176.449a.652.652 0 0 1-.176.449l-3.75 3.75a.877.877 0 0 1-.215.127.596.596 0 0 1-.468 0 .841.841 0 0 1-.215-.127z"></path>
                                        </svg>
                                    </i>
                                    <i class="menu__item_arrow ml-auto">
                                        <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-theme-231" viewBox="0 0 24 24">
                                            <path d="M10.806 7.232l3.75 3.75c.117.13.176.28.176.449a.652.652 0 0 1-.176.449l-3.75 3.75a.877.877 0 0 1-.215.127.596.596 0 0 1-.468 0 .877.877 0 0 1-.215-.127.652.652 0 0 1-.176-.449c0-.169.059-.319.176-.449l3.32-3.301L9.907 8.13a.652.652 0 0 1-.176-.449c0-.169.059-.319.176-.449a.652.652 0 0 1 .449-.176c.169 0 .319.058.45.176z"></path>
                                        </svg>
                                    </i>
                                </a>
                                <div class="menu__dropdown position-lg-absolute">
                                    <div class="menu__list menu__list--styled menu__level-02 menu__level-02 p-lg-20">
                                        <div class="menu__item menu__back d-lg-none">
                                            <a href="collection.php">Products</a>
                                        </div>
                                        <?php 
                                            foreach ($icat_arr as $catId => $catName) {
                                            $query = mysqli_query($con, "SELECT * FROM tbl_top_category where tcat_id='$catId'");
                                            $record = mysqli_fetch_assoc($query);
                                            $top=$record['slug'];
                                        ?>
                                         <div class="menu__item menu__item--has-children has_subchild position-lg-relative">
                                            <a href="javascript:void(0)" class="d-flex align-items-center px-lg-5" data-parent="3">
                                                <span><?php echo $catName ?></span>
                                                <i class="ml-auto">
                                                    <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-theme-231" viewBox="0 0 24 24">
                                                        <path d="M10.806 7.232l3.75 3.75c.117.13.176.28.176.449a.652.652 0 0 1-.176.449l-3.75 3.75a.877.877 0 0 1-.215.127.596.596 0 0 1-.468 0 .877.877 0 0 1-.215-.127.652.652 0 0 1-.176-.449c0-.169.059-.319.176-.449l3.32-3.301L9.907 8.13a.652.652 0 0 1-.176-.449c0-.169.059-.319.176-.449a.652.652 0 0 1 .449-.176c.169 0 .319.058.45.176z"></path>
                                                    </svg>
                                                </i>
                                            </a>
                                        <?php if (!empty($sub_arr[$catId])) { ?>
                                            <div class="menu__list menu__level-03 position-lg-absolute p-lg-15">
                                                <?php foreach ($sub_arr[$catId] as $scid => $scname) { 
                                                    $query1 = mysqli_query($con, "SELECT * FROM tbl_mid_category where mcat_id='$scid'");
                                                    $record1 = mysqli_fetch_assoc($query1);
                                                    $mid=$record1['slug'];
                                                ?>
                                                <div class="menu__item menu__back d-lg-none">
                                                    <a href="<?php echo path() ?>/category/<?php echo $top."/".$mid ?>"><?php echo $scname ?></a>
                                                </div>
                                                <?php } ?>
                                            </div>
                                        <?php } ?>
                                        </div>
                                        <?php } ?>
                                    </div>
                                </div>
                            </div>
                            <div class="menu__item menu__item--has-children has_subchild position-lg-relative">
                                <a href="business.php" class="d-flex align-items-center" data-parent="2">
                                    <span>Business</span>
                                    <i class="menu__item_arrow d-none d-lg-flex position-lg-relative mr-0">
                                        <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-theme-229" viewBox="0 0 24 24">
                                            <path d="M11.783 14.088l-3.75-3.75a.652.652 0 0 1-.176-.449c0-.169.059-.319.176-.449a.65.65 0 0 1 .449-.176c.169 0 .318.059.449.176l3.301 3.32 3.301-3.32a.65.65 0 0 1 .449-.176c.169 0 .318.059.449.176.117.13.176.28.176.449a.652.652 0 0 1-.176.449l-3.75 3.75a.877.877 0 0 1-.215.127.596.596 0 0 1-.468 0 .841.841 0 0 1-.215-.127z"></path>
                                        </svg>
                                    </i>
                                    <i class="menu__item_arrow ml-auto">
                                        <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-theme-231" viewBox="0 0 24 24">
                                            <path d="M10.806 7.232l3.75 3.75c.117.13.176.28.176.449a.652.652 0 0 1-.176.449l-3.75 3.75a.877.877 0 0 1-.215.127.596.596 0 0 1-.468 0 .877.877 0 0 1-.215-.127.652.652 0 0 1-.176-.449c0-.169.059-.319.176-.449l3.32-3.301L9.907 8.13a.652.652 0 0 1-.176-.449c0-.169.059-.319.176-.449a.652.652 0 0 1 .449-.176c.169 0 .319.058.45.176z"></path>
                                        </svg>
                                    </i>
                                </a>
                                <div class="menu__dropdown position-lg-absolute" style="">
                                    <div class="menu__list menu__list--styled menu__level-02 menu__level-02 p-lg-20">
                                        <div class="menu__item menu__back d-lg-none">
                                            <a href="business.php">Business</a>
                                        </div>
                                        <div class="menu__item">
                                            <a href="affilate.php" class="d-flex align-items-center px-lg-5">
                                                <span>Affiliate Program</span>
                                            </a>
                                        </div>
                                        <div class="menu__item">
                                            <a href="become-a-reseller.php" class="d-flex align-items-center px-lg-5">
                                                <span>Become a Reseller</span>
                                            </a>
                                        </div>
                                        <div class="menu__item">
                                            <a href="business-order.php" class="d-flex align-items-center px-lg-5">
                                                <span>Business Orders</span>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="menu__item">
                                <a href="" class="d-flex align-items-center">
                                    <span>Support</span>
                                </a>
                            </div>
                            <div class="menu__item">
                                <a href="article.php" class="d-flex align-items-center">
                                    <span>Blog</span>
                                </a>
                            </div>
                        </div>
                    </nav>
                </div>
            </div>
            <div class="popup-navigation__currency px-10" data-js-position-mobile="currencies"></div>
            <div class="popup-navigation__currency px-10" data-js-position-mobile="languages"></div>
        </div>
    </div>
    <div class="popup__body position-relative d-none justify-content-end" id="wishlist" data-popup-right="">
        <div class="popup-wishlist py-25 px-20" data-popup-content="">
            <div class="popup-wishlist__head d-flex align-items-center">
                <h5 class="m-0">MY WISHLIST <span data-js-popup-wishlist-count="">(0)</span>
                </h5>
                <i class="popup-wishlist__close ml-auto cursor-pointer" data-js-popup-close="" onclick="nav_close()">
                    <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-theme-164" viewBox="0 0 24 24">
                        <path d="M19.583 4.965a.65.65 0 0 1-.176.449l-6.445 6.426 6.445 6.426c.117.131.176.28.176.449a.65.65 0 0 1-.176.449.846.846 0 0 1-.215.127.596.596 0 0 1-.468 0 .846.846 0 0 1-.215-.127l-6.426-6.445-6.426 6.445a.846.846 0 0 1-.215.127.596.596 0 0 1-.468 0 .846.846 0 0 1-.215-.127.65.65 0 0 1-.176-.449c0-.169.059-.318.176-.449l6.445-6.426-6.445-6.426a.65.65 0 0 1-.176-.449c0-.169.059-.318.176-.449a.652.652 0 0 1 .449-.176c.169 0 .319.059.449.176l6.426 6.445 6.426-6.445a.652.652 0 0 1 .449-.176c.169 0 .319.059.449.176.117.13.176.28.176.449z"></path>
                    </svg>
                </i>
            </div>
            <div class="popup-wishlist__content">
                <div class="popup-wishlist__items mt-15 border-bottom">
                    <div>
                        <div class="product-store-lists d-flex flex-row align-items-start mb-20" data-js-product="" data-product-handle="typecase-magic-style-keyboard-case-for-ipad-pro-12-9-2021-5th-4th-3rd-gen" data-product-variant-id="41285783388213">
                            <div class="product-store-lists__image mr-15">
                                <a href="/products/typecase-magic-style-keyboard-case-for-ipad-pro-12-9-2021-5th-4th-3rd-gen?variant=41285783388213" class="d-block">
                                    <img srcset="https://cdn.shopify.com/s/files/1/0286/4726/0213/products/1_1973ac08-ce55-4ae8-8d39-3f1dc56cc900_120x.jpg, https://cdn.shopify.com/s/files/1/0286/4726/0213/products/1_1973ac08-ce55-4ae8-8d39-3f1dc56cc900_240x.jpg 2x">
                                </a>
                            </div>
                            <div class="product-store-lists__content d-flex flex-column align-items-start">
                                <div class="product-store-lists__title mb-3">
                                    <h3 class="h6 m-0">
                                        <a href="/products/typecase-magic-style-keyboard-case-for-ipad-pro-12-9-2021-5th-4th-3rd-gen?variant=41285783388213">Typecase Magic-Style Keyboard Case for iPad Pro 12.9 2021 5th &amp; 4th &amp; 3rd Gen</a>
                                    </h3>
                                </div>
                                <div class="product-store-lists__variant">Black</div>
                                <div class="product-store-lists__price mt-10 mb-10">
                                    <span class="price" data-js-product-price="">
                                        <span>$149.98</span>
                                    </span>
                                </div>
                                <span class="product-store-lists__remove btn-link js-store-lists-remove-wishlist">Remove</span>
                            </div>
                        </div>
                    </div>
                    <div>
                        <div class="product-store-lists d-flex flex-row align-items-start mb-20" data-js-product="" data-product-handle="typecase-magic-style-keyboard-case-for-ipad-pro-12-9-2021-5th-4th-3rd-gen" data-product-variant-id="41285783388213">
                            <div class="product-store-lists__image mr-15">
                                <a href="/products/typecase-magic-style-keyboard-case-for-ipad-pro-12-9-2021-5th-4th-3rd-gen?variant=41285783388213" class="d-block">
                                    <img srcset="https://cdn.shopify.com/s/files/1/0286/4726/0213/products/1_1973ac08-ce55-4ae8-8d39-3f1dc56cc900_120x.jpg, https://cdn.shopify.com/s/files/1/0286/4726/0213/products/1_1973ac08-ce55-4ae8-8d39-3f1dc56cc900_240x.jpg 2x">
                                </a>
                            </div>
                            <div class="product-store-lists__content d-flex flex-column align-items-start">
                                <div class="product-store-lists__title mb-3">
                                    <h3 class="h6 m-0">
                                        <a href="/products/typecase-magic-style-keyboard-case-for-ipad-pro-12-9-2021-5th-4th-3rd-gen?variant=41285783388213">Typecase Magic-Style Keyboard Case for iPad Pro 12.9 2021 5th &amp; 4th &amp; 3rd Gen</a>
                                    </h3>
                                </div>
                                <div class="product-store-lists__variant">Black</div>
                                <div class="product-store-lists__price mt-10 mb-10">
                                    <span class="price" data-js-product-price="">
                                        <span>$149.98</span>
                                    </span>
                                </div>
                                <span class="product-store-lists__remove btn-link js-store-lists-remove-wishlist">Remove</span>
                            </div>
                        </div>
                    </div>
                    <div>
                        <div class="product-store-lists d-flex flex-row align-items-start mb-20" data-js-product="" data-product-handle="typecase-magic-style-keyboard-case-for-ipad-pro-12-9-2021-5th-4th-3rd-gen" data-product-variant-id="41285783388213">
                            <div class="product-store-lists__image mr-15">
                                <a href="/products/typecase-magic-style-keyboard-case-for-ipad-pro-12-9-2021-5th-4th-3rd-gen?variant=41285783388213" class="d-block">
                                    <img srcset="https://cdn.shopify.com/s/files/1/0286/4726/0213/products/1_1973ac08-ce55-4ae8-8d39-3f1dc56cc900_120x.jpg, https://cdn.shopify.com/s/files/1/0286/4726/0213/products/1_1973ac08-ce55-4ae8-8d39-3f1dc56cc900_240x.jpg 2x">
                                </a>
                            </div>
                            <div class="product-store-lists__content d-flex flex-column align-items-start">
                                <div class="product-store-lists__title mb-3">
                                    <h3 class="h6 m-0">
                                        <a href="/products/typecase-magic-style-keyboard-case-for-ipad-pro-12-9-2021-5th-4th-3rd-gen?variant=41285783388213">Typecase Magic-Style Keyboard Case for iPad Pro 12.9 2021 5th &amp; 4th &amp; 3rd Gen</a>
                                    </h3>
                                </div>
                                <div class="product-store-lists__variant">Black</div>
                                <div class="product-store-lists__price mt-10 mb-10">
                                    <span class="price" data-js-product-price="">
                                        <span>$149.98</span>
                                    </span>
                                </div>
                                <span class="product-store-lists__remove btn-link js-store-lists-remove-wishlist">Remove</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="popup-wishlist__buttons mt-5">
                    <a href="javascript:void(0)" class="btn btn--full mt-20 js-popup-button" data-js-popup-button="wishlist-full">VIEW WISHLIST</a>
                </div>
            </div>
            <div class="popup-wishlist__empty mt-15">Your wishlist is empty.</div>
        </div>
    </div>
    <div class="popup__body position-relative d-none justify-content-end" id="cart" data-popup-right="">
        <div class="popup-cart py-25 px-20 js-popup-cart-ajax" data-popup-content="">
            <div class="popup-cart__head d-flex align-items-center">
                <h5 class="m-0"><span data-js-popup-cart-count="" class="count_cart">(<?php echo count($_SESSION['cart']) ?>)</span>
                </h5>
                <i class="popup-cart__close ml-auto cursor-pointer" data-js-popup-close="" onclick="nav_close()">
                    <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-theme-164" viewBox="0 0 24 24">
                        <path d="M19.583 4.965a.65.65 0 0 1-.176.449l-6.445 6.426 6.445 6.426c.117.131.176.28.176.449a.65.65 0 0 1-.176.449.846.846 0 0 1-.215.127.596.596 0 0 1-.468 0 .846.846 0 0 1-.215-.127l-6.426-6.445-6.426 6.445a.846.846 0 0 1-.215.127.596.596 0 0 1-.468 0 .846.846 0 0 1-.215-.127.65.65 0 0 1-.176-.449c0-.169.059-.318.176-.449l6.445-6.426-6.445-6.426a.65.65 0 0 1-.176-.449c0-.169.059-.318.176-.449a.652.652 0 0 1 .449-.176c.169 0 .319.059.449.176l6.426 6.445 6.426-6.445a.652.652 0 0 1 .449-.176c.169 0 .319.059.449.176.117.13.176.28.176.449z"></path>
                    </svg>
                </i>
            </div>
            <div class="popup-cart__content">
                <div class="popup-cart__items mt-15 border-bottom">
                    <div>
                        <div class="product-cart d-flex flex-row align-items-start mb-20" data-js-product="" data-product-variant-id="39783307411509">
                            <div class="product-cart__image mr-15">
                                <a href="/products/typecase-touch-pro-11-air-4?variant=39783307411509" class="d-block">
                                    <img src="https://cdn.shopify.com/s/files/1/0286/4726/0213/products/KB201T-129-3.3198_120x.png" srcset="https://cdn.shopify.com/s/files/1/0286/4726/0213/products/KB201T-129-3.3198_120x.png, https://cdn.shopify.com/s/files/1/0286/4726/0213/products/KB201T-129-3.3198_240x.png 2x">
                                </a>
                            </div>
                            <div class="product-cart__content d-flex flex-column align-items-start">
                                <div class="product-cart__title mb-3">
                                    <h3 class="h6 m-0">
                                        <a href="/products/typecase-touch-pro-11-air-4?variant=39783307411509">Typecase Keyboard Case with Trackpad for iPad Pro 11 &amp; iPad Air 5th &amp; 4th Gen</a>
                                    </h3>
                                </div>
                                <div class="product-cart__variant">Black</div>
                                <div class="product-cart__price mt-10 mb-10">
                                    <span class="product-cart__quantity">1</span>
                                    <span>x</span>
                                    <span class="price">
                                        <span>$69.99</span>
                                    </span>
                                </div>
                                <a href="/cart/change?line=1&amp;amp;quantity=0" class="product-cart__remove btn-link js-product-button-remove-from-cart">Remove</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="popup-cart__subtotal h5 d-flex align-items-center mt-15 mb-0">
                    <p class="m-0">SUBTOTAL</p>
                    <span class="ml-auto">
                        <span class="price" data-js-popup-cart-subtotal="">
                            <span>$69.99</span>
                        </span>
                    </span>
                </div>
                <div class="popup-cart__buttons mt-15">
                    <a href="/checkout" class="btn btn--full btn--secondary">PROCEED TO CHECKOUT</a>
                    <a href="/cart" class="btn btn--full mt-20">VIEW SHOPPING BAG</a>
                </div>
            </div>
            <div class="popup-cart__empty mt-20 d-none">Your shopping bag is empty.</div>
        </div>
    </div>
    <div class="popup__body position-relative d-none flex-center px-15 py-30" id="compare-full" data-popup-center="">
        <div class="popup-compare-full py-25 px-20" data-popup-content="">
            <div class="popup-compare-full__head d-flex align-items-center">
                <i class="popup-compare-full__close ml-auto cursor-pointer" onclick="nav_close()">
                    <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-theme-164" viewBox="0 0 24 24">
                        <path d="M19.583 4.965a.65.65 0 0 1-.176.449l-6.445 6.426 6.445 6.426c.117.131.176.28.176.449a.65.65 0 0 1-.176.449.846.846 0 0 1-.215.127.596.596 0 0 1-.468 0 .846.846 0 0 1-.215-.127l-6.426-6.445-6.426 6.445a.846.846 0 0 1-.215.127.596.596 0 0 1-.468 0 .846.846 0 0 1-.215-.127.65.65 0 0 1-.176-.449c0-.169.059-.318.176-.449l6.445-6.426-6.445-6.426a.65.65 0 0 1-.176-.449c0-.169.059-.318.176-.449a.652.652 0 0 1 .449-.176c.169 0 .319.059.449.176l6.426 6.445 6.426-6.445a.652.652 0 0 1 .449-.176c.169 0 .319.059.449.176.117.13.176.28.176.449z"></path>
                    </svg>
                </i>
            </div>
            <div class="popup-compare-full__content mt-10">
                <div class="compare">
                    <div class="container">
                        <div class="compare__head d-flex justify-content-lg-center align-items-center position-relative px-15 mb-15 mb-lg-30">
                            <h2 class="h3 mb-0 text-center" data-js-store-lists-has-items-compare="">Compare</h2>
                            <div class="compare__button-remove position-absolute d-inline-flex align-items-center cursor-pointer right-0 mr-5 js-store-lists-clear-compare" data-js-store-lists-has-items-compare="">
                                <i class="mb-4 mr-4">
                                    <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-theme-165" viewBox="0 0 24 24">
                                        <path d="M4.741 21.654a.601.601 0 0 1-.186-.439v-15h-1.25a.598.598 0 0 1-.439-.186.597.597 0 0 1-.186-.439.6.6 0 0 1 .186-.439.604.604 0 0 1 .439-.186h5v-2.5a.6.6 0 0 1 .186-.439.598.598 0 0 1 .439-.186h6.25c.169 0 .315.063.439.186a.601.601 0 0 1 .186.439v2.5h5c.169 0 .315.063.439.186a.601.601 0 0 1 .186.439c0 .17-.062.316-.186.439a.601.601 0 0 1-.439.186h-1.25v15a.6.6 0 0 1-.186.439.601.601 0 0 1-.439.186H5.18a.598.598 0 0 1-.439-.186zM18.305 6.215h-12.5V20.59h12.5V6.215zM9.37 9.525a.601.601 0 0 1 .186.439v6.875c0 .17-.062.316-.186.439a.601.601 0 0 1-.439.186.598.598 0 0 1-.439-.186.598.598 0 0 1-.186-.439V9.965a.6.6 0 0 1 .186-.439.594.594 0 0 1 .438-.186c.169 0 .316.062.44.185zm.185-4.56h5V3.09h-5v1.875zm2.94 4.56a.601.601 0 0 1 .186.439v6.875c0 .17-.062.316-.186.439a.601.601 0 0 1-.439.186.598.598 0 0 1-.439-.186.598.598 0 0 1-.186-.439V9.965a.6.6 0 0 1 .186-.439.604.604 0 0 1 .439-.186c.168 0 .315.062.439.185zm2.246 0a.604.604 0 0 1 .439-.186c.169 0 .315.063.439.186a.601.601 0 0 1 .186.439v6.875c0 .17-.062.316-.186.439a.601.601 0 0 1-.439.186.598.598 0 0 1-.439-.186.598.598 0 0 1-.186-.439V9.965c0-.169.062-.316.186-.44z"></path>
                                    </svg>
                                </i>REMOVE ALL
                            </div>
                        </div>
                        <table class="table d-block pb-20" data-js-store-lists-has-items-compare="">
                            <tbody>
                                <tr>
                                    <td class="compare__title pt-0 pl-0 border-right border-top-0">
                                        <h4 class="h6 mb-0">PRODUCTS</h4>
                                    </td>
                                    <td class="pt-0 border-top-0">
                                        <div class="compare__items d-flex">
                                            <div class="compare__item col">
                                                <div class="product-compare d-flex flex-column" data-js-product="" data-js-store-lists-product-compare="" data-product-handle="typecase-for-ipad-8th-generation" data-product-variant-id="33283234889781">
                                                    <form method="post" action="/cart/add" accept-charset="UTF-8" class="d-flex flex-column m-0" enctype="multipart/form-data" data-js-product-form="">
                                                        <input type="hidden" name="form_type" value="product">
                                                        <input type="hidden" name="utf8" value="✓">
                                                        <div class="product-compare__remove btn-link mb-15 js-store-lists-remove-compare">Remove</div>
                                                        <div class="product-compare__image product-image product-image--hover-fade position-relative w-100 js-product-images-navigation js-product-images-hovered-end">
                                                            <a href="/collections/all/products/typecase-for-ipad-8th-generation" class="d-block cursor-default" data-js-product-image="">
                                                                <div class="rimage" style="padding-top:128%">
                                                                    <img class="rimage__img rimage__img--contain lazyload loaded" data-master="//cdn.shopify.com/s/files/1/0286/4726/0213/products/81_{width}x.progressive.jpg?v=1606466397" data-aspect-ratio="0.78125" data-srcset="//cdn.shopify.com/s/files/1/0286/4726/0213/products/81_170x.progressive.jpg?v=1606466397 1x, //cdn.shopify.com/s/files/1/0286/4726/0213/products/81_340x.progressive.jpg?v=1606466397 2x" data-image-id="20726979428405" alt="Typecase Keyboard Case for iPad 9th Generation (10.2&quot;, 2021) iPad 8th Gen (2020), 7th Gen, Air 3 (10.5&quot;), Pro 10.5" srcset="//cdn.shopify.com/s/files/1/0286/4726/0213/products/81_170x.progressive.jpg?v=1606466397, //cdn.shopify.com/s/files/1/0286/4726/0213/products/81_340x.progressive.jpg?v=1606466397 2x" data-was-processed="true">
                                                                </div>
                                                            </a>
                                                            <div class="product-image__overlay-top position-absolute d-flex flex-wrap top-0 left-0 w-100 px-10 pt-10">
                                                                <a href="/collections/all/products/typecase-for-ipad-8th-generation" class="absolute-stretch cursor-default"></a>
                                                                <div class="product-image__overlay-top-left product-compare__labels position-relative d-flex flex-column align-items-start mb-10">
                                                                    <div class="label label--hot mb-3 mr-3 text-nowrap d-none" data-js-product-label-hot="">Hot</div>
                                                                    <div class="label label--new mb-3 mr-3 text-nowrap d-none" data-js-product-label-new="">New</div>
                                                                    <div class="label label--sale mb-3 mr-3 text-nowrap d-none" data-js-product-label-sale=""></div>
                                                                    <div class="label label--pre-order mb-3 mr-3 text-nowrap d-none" data-js-product-label-pre-order="">Pre-order</div>
                                                                    <div class="label label--out-stock mb-3 mr-3 text-nowrap d-none" data-js-product-label-out-stock="">Out stock</div>
                                                                </div>
                                                                <div class="product-image__overlay-top-right product-compare__button-quick-view position-lg-relative d-none d-lg-flex mb-lg-10 ml-lg-auto">
                                                                    <a href="" class="button-quick-view d-flex flex-center rounded-circle js-popup-button" data-js-popup-button="quick-view">
                                                                        <i>
                                                                            <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-theme-154" viewBox="0 0 24 24">
                                                                                <path d="M8.528 17.238c-1.107-.592-2.074-1.25-2.9-1.973-.827-.723-1.491-1.393-1.992-2.012-.501-.618-.771-.96-.811-1.025a.571.571 0 0 1-.117-.352c0-.13.039-.247.117-.352.039-.064.306-.406.801-1.025.495-.618 1.159-1.289 1.992-2.012.833-.723 1.803-1.38 2.91-1.973a7.424 7.424 0 0 1 3.555-.889c1.263 0 2.448.297 3.555.889 1.106.593 2.073 1.25 2.9 1.973.827.723 1.491 1.394 1.992 2.012.501.619.771.961.811 1.025a.573.573 0 0 1 .117.352.656.656 0 0 1-.117.371c-.039.053-.31.391-.811 1.016-.501.625-1.169 1.296-2.002 2.012-.833.717-1.804 1.371-2.91 1.963a7.375 7.375 0 0 1-3.535.889 7.415 7.415 0 0 1-3.555-.889zm.869-9.746c-.853.41-1.631.889-2.334 1.436s-1.312 1.101-1.826 1.66c-.515.561-.889.99-1.123 1.289.234.3.608.729 1.123 1.289.514.561 1.123 1.113 1.826 1.66s1.484 1.025 2.344 1.436 1.751.615 2.676.615c.924 0 1.813-.205 2.666-.615.853-.41 1.634-.889 2.344-1.436.709-.547 1.318-1.1 1.826-1.66.508-.56.885-.989 1.133-1.289a41.634 41.634 0 0 0-1.133-1.289c-.508-.56-1.113-1.113-1.816-1.66s-1.484-1.025-2.344-1.436-1.751-.615-2.676-.615c-.937 0-1.833.205-2.686.615zm.04 7.031c-.736-.735-1.104-1.617-1.104-2.646 0-1.028.368-1.91 1.104-2.646.735-.735 1.618-1.104 2.646-1.104 1.028 0 1.911.368 2.646 1.104.735.736 1.104 1.618 1.104 2.646 0 1.029-.368 1.911-1.104 2.646-.736.736-1.618 1.104-2.646 1.104-1.029 0-1.911-.367-2.646-1.104zm.878-4.414a2.41 2.41 0 0 0-.732 1.768c0 .69.244 1.279.732 1.768s1.077.732 1.768.732c.69 0 1.279-.244 1.768-.732s.732-1.077.732-1.768c0-.689-.244-1.279-.732-1.768s-1.078-.732-1.768-.732-1.279.244-1.768.732z"></path>
                                                                            </svg>
                                                                        </i>
                                                                    </a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="product-compare__content d-flex flex-column align-items-start mt-15">
                                                            <div class="product-compare__title mb-3">
                                                                <h3 class="m-0">
                                                                    <a href="/collections/all/products/typecase-for-ipad-8th-generation">Typecase Keyboard Case for iPad 9th Generation (10.2", 2021) iPad 8th Gen (2020), 7th Gen, Air 3 (10.5"), Pro 10.5</a>
                                                                </h3>
                                                            </div>
                                                            <div class="product-compare__price mb-10">
                                                                <span class="price" data-js-product-price="">
                                                                    <span>$63.99</span>
                                                                </span>
                                                            </div>
                                                            <div class="d-flex flex-column">
                                                                <div class="product-compare__variants d-none">
                                                                    <select name="id" class="m-0" data-js-product-variants="control">
                                                                        <option selected="selected" value="33283234889781">Black − $63.99</option>
                                                                        <option value="33283234922549">Midnight Green − $69.99</option>
                                                                        <option value="33283234955317">Rose Gold − $69.99</option>
                                                                        <option value="33283235020853">Silver − $69.99</option>
                                                                        <option value="33283235053621">Space Gray − $69.99</option>
                                                                        <option value="33293837860917">Violet − $69.99</option>
                                                                        <option value="33293843005493">Purple − $69.99</option>
                                                                        <option value="39695371730997">Pacific Blue − $69.99</option>
                                                                    </select>
                                                                </div>
                                                                <div class="product-compare__buttons d-flex flex-column flex-lg-row align-items-lg-center flex-wrap mt-4">
                                                                    <div class="product-compare__button-add-to-cart mb-10">
                                                                        <a href="/collections/all/products/typecase-for-ipad-8th-generation" class="btn btn--status btn--animated js-product-button-add-to-cart" name="add" data-js-product-button-add-to-cart="">
                                                                            <span class="d-flex flex-center">
                                                                                <i class="btn__icon mr-5 mb-4">
                                                                                    <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-theme-109" viewBox="0 0 24 24">
                                                                                        <path d="M19.884 21.897a.601.601 0 0 1-.439.186h-15a.6.6 0 0 1-.439-.186.601.601 0 0 1-.186-.439v-15a.6.6 0 0 1 .186-.439.601.601 0 0 1 .439-.186h3.75c0-1.028.368-1.911 1.104-2.646.735-.735 1.618-1.104 2.646-1.104s1.911.368 2.646 1.104c.735.736 1.104 1.618 1.104 2.646h3.75a.6.6 0 0 1 .439.186.601.601 0 0 1 .186.439v15a.604.604 0 0 1-.186.439zM18.819 7.083h-3.125v2.5a.598.598 0 0 1-.186.439c-.124.124-.271.186-.439.186s-.315-.062-.439-.186a.6.6 0 0 1-.186-.439v-2.5h-5v2.5a.598.598 0 0 1-.186.439c-.124.124-.271.186-.439.186s-.315-.062-.439-.186a.6.6 0 0 1-.186-.439v-2.5H5.069v13.75h13.75V7.083zm-8.642-3.018a2.409 2.409 0 0 0-.733 1.768h5c0-.69-.244-1.279-.732-1.768s-1.077-.732-1.768-.732-1.279.244-1.767.732z"></path>
                                                                                    </svg>
                                                                                </i>
                                                                                <span class="btn__text">Add To Cart</span>
                                                                            </span>
                                                                            <span class="d-flex flex-center" data-button-content="added">
                                                                                <i class="mr-5 mb-4">
                                                                                    <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-theme-110" viewBox="0 0 24 24">
                                                                                        <path d="M19.855 5.998a.601.601 0 0 0-.439-.186h-3.75c0-1.028-.368-1.911-1.104-2.646-.735-.735-1.618-1.104-2.646-1.104s-1.911.369-2.646 1.104c-.736.736-1.104 1.618-1.104 2.647h-3.75a.6.6 0 0 0-.439.186.598.598 0 0 0-.186.439v15a.6.6 0 0 0 .186.439c.124.123.27.186.439.186h15a.6.6 0 0 0 .439-.186.601.601 0 0 0 .186-.439v-15a.602.602 0 0 0-.186-.44zm-9.707-1.953c.488-.488 1.077-.732 1.768-.732s1.279.244 1.768.732.732 1.078.732 1.768h-5c0-.69.244-1.28.732-1.768zm6.926 7.194l-6.25 6.25a.877.877 0 0 1-.215.127.596.596 0 0 1-.468 0 .896.896 0 0 1-.215-.127l-2.5-2.5a.652.652 0 0 1-.176-.449c0-.169.059-.319.176-.449.13-.117.28-.176.449-.176s.319.059.449.176l2.051 2.07 5.801-5.82c.13-.117.28-.176.449-.176s.319.059.449.176c.117.13.176.28.176.449a.652.652 0 0 1-.176.449z"></path>
                                                                                    </svg>
                                                                                </i>Added </span>
                                                                            <span class="d-flex flex-center" data-button-content="sold-out">Sold Out</span>
                                                                            <span class="d-flex flex-center" data-button-content="pre-order">
                                                                                <i class="btn__icon mr-5 mb-4">
                                                                                    <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-theme-109" viewBox="0 0 24 24">
                                                                                        <path d="M19.884 21.897a.601.601 0 0 1-.439.186h-15a.6.6 0 0 1-.439-.186.601.601 0 0 1-.186-.439v-15a.6.6 0 0 1 .186-.439.601.601 0 0 1 .439-.186h3.75c0-1.028.368-1.911 1.104-2.646.735-.735 1.618-1.104 2.646-1.104s1.911.368 2.646 1.104c.735.736 1.104 1.618 1.104 2.646h3.75a.6.6 0 0 1 .439.186.601.601 0 0 1 .186.439v15a.604.604 0 0 1-.186.439zM18.819 7.083h-3.125v2.5a.598.598 0 0 1-.186.439c-.124.124-.271.186-.439.186s-.315-.062-.439-.186a.6.6 0 0 1-.186-.439v-2.5h-5v2.5a.598.598 0 0 1-.186.439c-.124.124-.271.186-.439.186s-.315-.062-.439-.186a.6.6 0 0 1-.186-.439v-2.5H5.069v13.75h13.75V7.083zm-8.642-3.018a2.409 2.409 0 0 0-.733 1.768h5c0-.69-.244-1.279-.732-1.768s-1.077-.732-1.768-.732-1.279.244-1.767.732z"></path>
                                                                                    </svg>
                                                                                </i>
                                                                                <span class="btn__text">Pre-Order</span>
                                                                            </span>
                                                                        </a>
                                                                    </div>
                                                                    <div class="product-collection__buttons-section d-flex d-lg-none px-lg-10">
                                                                        <div class="product-compare__button-quick-view-mobile mb-10">
                                                                            <a href="" class="btn btn--text pt-2 px-lg-6 js-popup-button" data-js-popup-button="quick-view">
                                                                                <i>
                                                                                    <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-theme-154" viewBox="0 0 24 24">
                                                                                        <path d="M8.528 17.238c-1.107-.592-2.074-1.25-2.9-1.973-.827-.723-1.491-1.393-1.992-2.012-.501-.618-.771-.96-.811-1.025a.571.571 0 0 1-.117-.352c0-.13.039-.247.117-.352.039-.064.306-.406.801-1.025.495-.618 1.159-1.289 1.992-2.012.833-.723 1.803-1.38 2.91-1.973a7.424 7.424 0 0 1 3.555-.889c1.263 0 2.448.297 3.555.889 1.106.593 2.073 1.25 2.9 1.973.827.723 1.491 1.394 1.992 2.012.501.619.771.961.811 1.025a.573.573 0 0 1 .117.352.656.656 0 0 1-.117.371c-.039.053-.31.391-.811 1.016-.501.625-1.169 1.296-2.002 2.012-.833.717-1.804 1.371-2.91 1.963a7.375 7.375 0 0 1-3.535.889 7.415 7.415 0 0 1-3.555-.889zm.869-9.746c-.853.41-1.631.889-2.334 1.436s-1.312 1.101-1.826 1.66c-.515.561-.889.99-1.123 1.289.234.3.608.729 1.123 1.289.514.561 1.123 1.113 1.826 1.66s1.484 1.025 2.344 1.436 1.751.615 2.676.615c.924 0 1.813-.205 2.666-.615.853-.41 1.634-.889 2.344-1.436.709-.547 1.318-1.1 1.826-1.66.508-.56.885-.989 1.133-1.289a41.634 41.634 0 0 0-1.133-1.289c-.508-.56-1.113-1.113-1.816-1.66s-1.484-1.025-2.344-1.436-1.751-.615-2.676-.615c-.937 0-1.833.205-2.686.615zm.04 7.031c-.736-.735-1.104-1.617-1.104-2.646 0-1.028.368-1.91 1.104-2.646.735-.735 1.618-1.104 2.646-1.104 1.028 0 1.911.368 2.646 1.104.735.736 1.104 1.618 1.104 2.646 0 1.029-.368 1.911-1.104 2.646-.736.736-1.618 1.104-2.646 1.104-1.029 0-1.911-.367-2.646-1.104zm.878-4.414a2.41 2.41 0 0 0-.732 1.768c0 .69.244 1.279.732 1.768s1.077.732 1.768.732c.69 0 1.279-.244 1.768-.732s.732-1.077.732-1.768c0-.689-.244-1.279-.732-1.768s-1.078-.732-1.768-.732-1.279.244-1.768.732z"></path>
                                                                                    </svg>
                                                                                </i>
                                                                            </a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                            <div class="compare__item col">
                                                <div class="product-compare d-flex flex-column" data-js-product="" data-js-store-lists-product-compare="" data-product-handle="typecase-for-ipad-6th-generation" data-product-variant-id="31652847452213">
                                                    <form method="post" action="/cart/add" accept-charset="UTF-8" class="d-flex flex-column m-0" enctype="multipart/form-data" data-js-product-form="">
                                                        <input type="hidden" name="form_type" value="product">
                                                        <input type="hidden" name="utf8" value="✓">
                                                        <div class="product-compare__remove btn-link mb-15 js-store-lists-remove-compare">Remove</div>
                                                        <div class="product-compare__image product-image product-image--hover-fade position-relative w-100 js-product-images-navigation js-product-images-hovered-end">
                                                            <a href="/collections/all/products/typecase-for-ipad-6th-generation" class="d-block cursor-default" data-js-product-image="">
                                                                <div class="rimage" style="padding-top:128%">
                                                                    <img class="rimage__img rimage__img--contain lazyload loaded" data-master="//cdn.shopify.com/s/files/1/0286/4726/0213/products/main_black_{width}x.progressive.jpg?v=1606706530" data-aspect-ratio="0.78125" data-srcset="//cdn.shopify.com/s/files/1/0286/4726/0213/products/main_black_170x.progressive.jpg?v=1606706530 1x, //cdn.shopify.com/s/files/1/0286/4726/0213/products/main_black_340x.progressive.jpg?v=1606706530 2x" data-image-id="14196889976885" alt="Typecase Case with Keyboard for iPad 2018 (6th Gen) - iPad 2017 (5th Gen) - iPad Pro 9.7 - iPad Air 2 &amp; 1" srcset="//cdn.shopify.com/s/files/1/0286/4726/0213/products/main_black_170x.progressive.jpg?v=1606706530, //cdn.shopify.com/s/files/1/0286/4726/0213/products/main_black_340x.progressive.jpg?v=1606706530 2x" data-was-processed="true">
                                                                </div>
                                                            </a>
                                                            <div class="product-image__overlay-top position-absolute d-flex flex-wrap top-0 left-0 w-100 px-10 pt-10">
                                                                <a href="/collections/all/products/typecase-for-ipad-6th-generation" class="absolute-stretch cursor-default"></a>
                                                                <div class="product-image__overlay-top-left product-compare__labels position-relative d-flex flex-column align-items-start mb-10">
                                                                    <div class="label label--hot mb-3 mr-3 text-nowrap d-none" data-js-product-label-hot="">Hot</div>
                                                                    <div class="label label--new mb-3 mr-3 text-nowrap d-none" data-js-product-label-new="">New</div>
                                                                    <div class="label label--sale mb-3 mr-3 text-nowrap d-none" data-js-product-label-sale=""></div>
                                                                    <div class="label label--pre-order mb-3 mr-3 text-nowrap d-none" data-js-product-label-pre-order="">Pre-order</div>
                                                                    <div class="label label--out-stock mb-3 mr-3 text-nowrap d-none" data-js-product-label-out-stock="">Out stock</div>
                                                                </div>
                                                                <div class="product-image__overlay-top-right product-compare__button-quick-view position-lg-relative d-none d-lg-flex mb-lg-10 ml-lg-auto">
                                                                    <a href="" class="button-quick-view d-flex flex-center rounded-circle js-popup-button" data-js-popup-button="quick-view">
                                                                        <i>
                                                                            <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-theme-154" viewBox="0 0 24 24">
                                                                                <path d="M8.528 17.238c-1.107-.592-2.074-1.25-2.9-1.973-.827-.723-1.491-1.393-1.992-2.012-.501-.618-.771-.96-.811-1.025a.571.571 0 0 1-.117-.352c0-.13.039-.247.117-.352.039-.064.306-.406.801-1.025.495-.618 1.159-1.289 1.992-2.012.833-.723 1.803-1.38 2.91-1.973a7.424 7.424 0 0 1 3.555-.889c1.263 0 2.448.297 3.555.889 1.106.593 2.073 1.25 2.9 1.973.827.723 1.491 1.394 1.992 2.012.501.619.771.961.811 1.025a.573.573 0 0 1 .117.352.656.656 0 0 1-.117.371c-.039.053-.31.391-.811 1.016-.501.625-1.169 1.296-2.002 2.012-.833.717-1.804 1.371-2.91 1.963a7.375 7.375 0 0 1-3.535.889 7.415 7.415 0 0 1-3.555-.889zm.869-9.746c-.853.41-1.631.889-2.334 1.436s-1.312 1.101-1.826 1.66c-.515.561-.889.99-1.123 1.289.234.3.608.729 1.123 1.289.514.561 1.123 1.113 1.826 1.66s1.484 1.025 2.344 1.436 1.751.615 2.676.615c.924 0 1.813-.205 2.666-.615.853-.41 1.634-.889 2.344-1.436.709-.547 1.318-1.1 1.826-1.66.508-.56.885-.989 1.133-1.289a41.634 41.634 0 0 0-1.133-1.289c-.508-.56-1.113-1.113-1.816-1.66s-1.484-1.025-2.344-1.436-1.751-.615-2.676-.615c-.937 0-1.833.205-2.686.615zm.04 7.031c-.736-.735-1.104-1.617-1.104-2.646 0-1.028.368-1.91 1.104-2.646.735-.735 1.618-1.104 2.646-1.104 1.028 0 1.911.368 2.646 1.104.735.736 1.104 1.618 1.104 2.646 0 1.029-.368 1.911-1.104 2.646-.736.736-1.618 1.104-2.646 1.104-1.029 0-1.911-.367-2.646-1.104zm.878-4.414a2.41 2.41 0 0 0-.732 1.768c0 .69.244 1.279.732 1.768s1.077.732 1.768.732c.69 0 1.279-.244 1.768-.732s.732-1.077.732-1.768c0-.689-.244-1.279-.732-1.768s-1.078-.732-1.768-.732-1.279.244-1.768.732z"></path>
                                                                            </svg>
                                                                        </i>
                                                                    </a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="product-compare__content d-flex flex-column align-items-start mt-15">
                                                            <div class="product-compare__title mb-3">
                                                                <h3 class="m-0">
                                                                    <a href="/collections/all/products/typecase-for-ipad-6th-generation">Typecase Case with Keyboard for iPad 2018 (6th Gen) - iPad 2017 (5th Gen) - iPad Pro 9.7 - iPad Air 2 &amp; 1</a>
                                                                </h3>
                                                            </div>
                                                            <div class="product-compare__price mb-10">
                                                                <span class="price" data-js-product-price="">
                                                                    <span>$64.99</span>
                                                                </span>
                                                            </div>
                                                            <div class="d-flex flex-column">
                                                                <div class="product-compare__variants d-none">
                                                                    <select name="id" class="m-0" data-js-product-variants="control">
                                                                        <option selected="selected" value="31652847452213">Black − $64.99</option>
                                                                        <option value="31652847484981">Silver − $64.99</option>
                                                                        <option value="31654898466869">Blue − $64.99</option>
                                                                        <option value="31652847583285">Rose Gold − $67.99</option>
                                                                        <option value="31652847648821">Space Gray − $64.99</option>
                                                                        <option value="31652847747125">Violet − $64.99</option>
                                                                    </select>
                                                                </div>
                                                                <div class="product-compare__buttons d-flex flex-column flex-lg-row align-items-lg-center flex-wrap mt-4">
                                                                    <div class="product-compare__button-add-to-cart mb-10">
                                                                        <a href="/collections/all/products/typecase-for-ipad-6th-generation" class="btn btn--status btn--animated js-product-button-add-to-cart" name="add" data-js-product-button-add-to-cart="">
                                                                            <span class="d-flex flex-center">
                                                                                <i class="btn__icon mr-5 mb-4">
                                                                                    <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-theme-109" viewBox="0 0 24 24">
                                                                                        <path d="M19.884 21.897a.601.601 0 0 1-.439.186h-15a.6.6 0 0 1-.439-.186.601.601 0 0 1-.186-.439v-15a.6.6 0 0 1 .186-.439.601.601 0 0 1 .439-.186h3.75c0-1.028.368-1.911 1.104-2.646.735-.735 1.618-1.104 2.646-1.104s1.911.368 2.646 1.104c.735.736 1.104 1.618 1.104 2.646h3.75a.6.6 0 0 1 .439.186.601.601 0 0 1 .186.439v15a.604.604 0 0 1-.186.439zM18.819 7.083h-3.125v2.5a.598.598 0 0 1-.186.439c-.124.124-.271.186-.439.186s-.315-.062-.439-.186a.6.6 0 0 1-.186-.439v-2.5h-5v2.5a.598.598 0 0 1-.186.439c-.124.124-.271.186-.439.186s-.315-.062-.439-.186a.6.6 0 0 1-.186-.439v-2.5H5.069v13.75h13.75V7.083zm-8.642-3.018a2.409 2.409 0 0 0-.733 1.768h5c0-.69-.244-1.279-.732-1.768s-1.077-.732-1.768-.732-1.279.244-1.767.732z"></path>
                                                                                    </svg>
                                                                                </i>
                                                                                <span class="btn__text">Add To Cart</span>
                                                                            </span>
                                                                            <span class="d-flex flex-center" data-button-content="added">
                                                                                <i class="mr-5 mb-4">
                                                                                    <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-theme-110" viewBox="0 0 24 24">
                                                                                        <path d="M19.855 5.998a.601.601 0 0 0-.439-.186h-3.75c0-1.028-.368-1.911-1.104-2.646-.735-.735-1.618-1.104-2.646-1.104s-1.911.369-2.646 1.104c-.736.736-1.104 1.618-1.104 2.647h-3.75a.6.6 0 0 0-.439.186.598.598 0 0 0-.186.439v15a.6.6 0 0 0 .186.439c.124.123.27.186.439.186h15a.6.6 0 0 0 .439-.186.601.601 0 0 0 .186-.439v-15a.602.602 0 0 0-.186-.44zm-9.707-1.953c.488-.488 1.077-.732 1.768-.732s1.279.244 1.768.732.732 1.078.732 1.768h-5c0-.69.244-1.28.732-1.768zm6.926 7.194l-6.25 6.25a.877.877 0 0 1-.215.127.596.596 0 0 1-.468 0 .896.896 0 0 1-.215-.127l-2.5-2.5a.652.652 0 0 1-.176-.449c0-.169.059-.319.176-.449.13-.117.28-.176.449-.176s.319.059.449.176l2.051 2.07 5.801-5.82c.13-.117.28-.176.449-.176s.319.059.449.176c.117.13.176.28.176.449a.652.652 0 0 1-.176.449z"></path>
                                                                                    </svg>
                                                                                </i>Added </span>
                                                                            <span class="d-flex flex-center" data-button-content="sold-out">Sold Out</span>
                                                                            <span class="d-flex flex-center" data-button-content="pre-order">
                                                                                <i class="btn__icon mr-5 mb-4">
                                                                                    <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-theme-109" viewBox="0 0 24 24">
                                                                                        <path d="M19.884 21.897a.601.601 0 0 1-.439.186h-15a.6.6 0 0 1-.439-.186.601.601 0 0 1-.186-.439v-15a.6.6 0 0 1 .186-.439.601.601 0 0 1 .439-.186h3.75c0-1.028.368-1.911 1.104-2.646.735-.735 1.618-1.104 2.646-1.104s1.911.368 2.646 1.104c.735.736 1.104 1.618 1.104 2.646h3.75a.6.6 0 0 1 .439.186.601.601 0 0 1 .186.439v15a.604.604 0 0 1-.186.439zM18.819 7.083h-3.125v2.5a.598.598 0 0 1-.186.439c-.124.124-.271.186-.439.186s-.315-.062-.439-.186a.6.6 0 0 1-.186-.439v-2.5h-5v2.5a.598.598 0 0 1-.186.439c-.124.124-.271.186-.439.186s-.315-.062-.439-.186a.6.6 0 0 1-.186-.439v-2.5H5.069v13.75h13.75V7.083zm-8.642-3.018a2.409 2.409 0 0 0-.733 1.768h5c0-.69-.244-1.279-.732-1.768s-1.077-.732-1.768-.732-1.279.244-1.767.732z"></path>
                                                                                    </svg>
                                                                                </i>
                                                                                <span class="btn__text">Pre-Order</span>
                                                                            </span>
                                                                        </a>
                                                                    </div>
                                                                    <div class="product-collection__buttons-section d-flex d-lg-none px-lg-10">
                                                                        <div class="product-compare__button-quick-view-mobile mb-10">
                                                                            <a href="" class="btn btn--text pt-2 px-lg-6 js-popup-button" data-js-popup-button="quick-view">
                                                                                <i>
                                                                                    <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-theme-154" viewBox="0 0 24 24">
                                                                                        <path d="M8.528 17.238c-1.107-.592-2.074-1.25-2.9-1.973-.827-.723-1.491-1.393-1.992-2.012-.501-.618-.771-.96-.811-1.025a.571.571 0 0 1-.117-.352c0-.13.039-.247.117-.352.039-.064.306-.406.801-1.025.495-.618 1.159-1.289 1.992-2.012.833-.723 1.803-1.38 2.91-1.973a7.424 7.424 0 0 1 3.555-.889c1.263 0 2.448.297 3.555.889 1.106.593 2.073 1.25 2.9 1.973.827.723 1.491 1.394 1.992 2.012.501.619.771.961.811 1.025a.573.573 0 0 1 .117.352.656.656 0 0 1-.117.371c-.039.053-.31.391-.811 1.016-.501.625-1.169 1.296-2.002 2.012-.833.717-1.804 1.371-2.91 1.963a7.375 7.375 0 0 1-3.535.889 7.415 7.415 0 0 1-3.555-.889zm.869-9.746c-.853.41-1.631.889-2.334 1.436s-1.312 1.101-1.826 1.66c-.515.561-.889.99-1.123 1.289.234.3.608.729 1.123 1.289.514.561 1.123 1.113 1.826 1.66s1.484 1.025 2.344 1.436 1.751.615 2.676.615c.924 0 1.813-.205 2.666-.615.853-.41 1.634-.889 2.344-1.436.709-.547 1.318-1.1 1.826-1.66.508-.56.885-.989 1.133-1.289a41.634 41.634 0 0 0-1.133-1.289c-.508-.56-1.113-1.113-1.816-1.66s-1.484-1.025-2.344-1.436-1.751-.615-2.676-.615c-.937 0-1.833.205-2.686.615zm.04 7.031c-.736-.735-1.104-1.617-1.104-2.646 0-1.028.368-1.91 1.104-2.646.735-.735 1.618-1.104 2.646-1.104 1.028 0 1.911.368 2.646 1.104.735.736 1.104 1.618 1.104 2.646 0 1.029-.368 1.911-1.104 2.646-.736.736-1.618 1.104-2.646 1.104-1.029 0-1.911-.367-2.646-1.104zm.878-4.414a2.41 2.41 0 0 0-.732 1.768c0 .69.244 1.279.732 1.768s1.077.732 1.768.732c.69 0 1.279-.244 1.768-.732s.732-1.077.732-1.768c0-.689-.244-1.279-.732-1.768s-1.078-.732-1.768-.732-1.279.244-1.768.732z"></path>
                                                                                    </svg>
                                                                                </i>
                                                                            </a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="compare__title d-lg-none w-100 pt-0 pr-0 text-right border-left border-top-0">
                                        <h4 class="h6 mb-0">PRODUCTS</h4>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="compare__title pl-0 border-right">
                                        <h4 class="h6 mb-0">DESCRIPTION</h4>
                                    </td>
                                    <td>
                                        <div class="compare__items d-flex">
                                            <div class="compare__item col py-5" data-js-store-lists-product-compare="" data-product-handle="typecase-for-ipad-8th-generation">
                                                <p class="fs-lg mb-0">✅&nbsp;&nbsp;Compatibility: Compatible with iPad 8th Gen (2020, 10.2"), iPad 7th Gen (2019, 10.2"), iPad Ai...</p>
                                            </div>
                                            <div class="compare__item col py-5" data-js-store-lists-product-compare="" data-product-handle="typecase-for-ipad-6th-generation">
                                                <p class="fs-lg mb-0">Overview: A stylish finish with grip-enhancing tech &amp; smart business-grade protection make o...</p>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="compare__title d-lg-none w-100 pr-0 text-right border-left">
                                        <h4 class="h6 mb-0">DESCRIPTION</h4>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="compare__title pl-0 border-right">
                                        <h4 class="h6 mb-0">COLLECTION</h4>
                                    </td>
                                    <td>
                                        <div class="compare__items d-flex">
                                            <div class="compare__item col" data-js-store-lists-product-compare="" data-product-handle="typecase-for-ipad-8th-generation">
                                                <p class="compare__collections mb-0">
                                                    <a href="/collections/typecase">Flexbook,</a>
                                                    <a href="/collections/ipad-7th-gen">iPad 8th Gen,</a>
                                                    <a href="/collections/ipad-air-10-5">iPad Air 10.5,</a>
                                                    <a href="/collections/keyboard-cases">Keyboard Cases</a>
                                                </p>
                                            </div>
                                            <div class="compare__item col" data-js-store-lists-product-compare="" data-product-handle="typecase-for-ipad-6th-generation">
                                                <p class="compare__collections mb-0">
                                                    <a href="/collections/typecase">Flexbook,</a>
                                                    <a href="/collections/ipad-9-7-inch">iPad 9.7 inch,</a>
                                                    <a href="/collections/keyboard-cases">Keyboard Cases</a>
                                                </p>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="compare__title d-lg-none w-100 pr-0 text-right border-left">
                                        <h4 class="h6 mb-0">COLLECTION</h4>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="compare__title pl-0 border-right">
                                        <h4 class="h6 mb-0">AVAILABILITY</h4>
                                    </td>
                                    <td>
                                        <div class="compare__items d-flex">
                                            <div class="compare__item col" data-js-store-lists-product-compare="" data-product-handle="typecase-for-ipad-8th-generation">
                                                <p class="mb-0">
                                                    <span class="in-stock">In Stock</span>
                                                </p>
                                            </div>
                                            <div class="compare__item col" data-js-store-lists-product-compare="" data-product-handle="typecase-for-ipad-6th-generation">
                                                <p class="mb-0">
                                                    <span class="in-stock">In Stock</span>
                                                </p>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="compare__title d-lg-none w-100 pr-0 text-right border-left">
                                        <h4 class="h6 mb-0">AVAILABILITY</h4>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="compare__title pl-0 border-right">
                                        <h4 class="h6 mb-0">PRODUCT TYPE</h4>
                                    </td>
                                    <td>
                                        <div class="compare__items d-flex">
                                            <div class="compare__item col" data-js-store-lists-product-compare="" data-product-handle="typecase-for-ipad-8th-generation">
                                                <p class="mb-0">FALSE</p>
                                            </div>
                                            <div class="compare__item col" data-js-store-lists-product-compare="" data-product-handle="typecase-for-ipad-6th-generation">
                                                <p class="mb-0">FALSE</p>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="compare__title d-lg-none w-100 pr-0 text-right border-left">
                                        <h4 class="h6 mb-0">PRODUCT TYPE</h4>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="compare__title pl-0 border-right">
                                        <h4 class="h6 mb-0">VENDOR</h4>
                                    </td>
                                    <td>
                                        <div class="compare__items d-flex">
                                            <div class="compare__item col" data-js-store-lists-product-compare="" data-product-handle="typecase-for-ipad-8th-generation">
                                                <p class="mb-0">Typecase</p>
                                            </div>
                                            <div class="compare__item col" data-js-store-lists-product-compare="" data-product-handle="typecase-for-ipad-6th-generation">
                                                <p class="mb-0">Typecase</p>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="compare__title d-lg-none w-100 pr-0 text-right border-left">
                                        <h4 class="h6 mb-0">VENDOR</h4>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="compare__title pl-0 border-right">
                                        <h4 class="h6 mb-0">SKU</h4>
                                    </td>
                                    <td>
                                        <div class="compare__items d-flex">
                                            <div class="compare__item col" data-js-store-lists-product-compare="" data-product-handle="typecase-for-ipad-8th-generation">
                                                <p class="mb-0">SBC01NB-10.2-BLK</p>
                                            </div>
                                            <div class="compare__item col" data-js-store-lists-product-compare="" data-product-handle="typecase-for-ipad-6th-generation">
                                                <p class="mb-0">SB01NBLKB</p>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="compare__title d-lg-none w-100 pr-0 text-right border-left">
                                        <h4 class="h6 mb-0">SKU</h4>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="compare__title pl-0 border-right">
                                        <h4 class="h6 mb-0">BARCODE</h4>
                                    </td>
                                    <td>
                                        <div class="compare__items d-flex">
                                            <div class="compare__item col" data-js-store-lists-product-compare="" data-product-handle="typecase-for-ipad-8th-generation">
                                                <p class="mb-0">850016246004</p>
                                            </div>
                                            <div class="compare__item col" data-js-store-lists-product-compare="" data-product-handle="typecase-for-ipad-6th-generation">
                                                <p class="mb-0">850016246059</p>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="compare__title d-lg-none w-100 pr-0 text-right border-left">
                                        <h4 class="h6 mb-0">BARCODE</h4>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="compare__title pl-0 border-right">
                                        <h4 class="h6 mb-0">COLOR</h4>
                                    </td>
                                    <td>
                                        <div class="compare__items d-flex">
                                            <div class="compare__item col" data-js-store-lists-product-compare="" data-product-handle="typecase-for-ipad-8th-generation">
                                                <p class="mb-0">Black</p>
                                            </div>
                                            <div class="compare__item col" data-js-store-lists-product-compare="" data-product-handle="typecase-for-ipad-6th-generation">
                                                <p class="mb-0">Black</p>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="compare__title d-lg-none w-100 pr-0 text-right border-left">
                                        <h4 class="h6 mb-0">COLOR</h4>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        <div class="d-flex flex-column align-items-center py-40 py-md-100 my-100 d-none" data-js-store-lists-dhas-items-compare="">
                            <h3>Compare</h3>
                            <p>No products were added to the compare</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="popup__body position-relative d-none flex-center px-15 py-30" id="wishlist-full" data-popup-center="">
        <div class="popup-wishlist-full py-25 px-20" data-popup-content="">
            <div class="popup-wishlist-full__head d-flex align-items-center">
                <i class="popup-wishlist-full__close ml-auto cursor-pointer" data-js-popup-close="" onclick="nav_close()">
                    <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-theme-164" viewBox="0 0 24 24">
                        <path d="M19.583 4.965a.65.65 0 0 1-.176.449l-6.445 6.426 6.445 6.426c.117.131.176.28.176.449a.65.65 0 0 1-.176.449.846.846 0 0 1-.215.127.596.596 0 0 1-.468 0 .846.846 0 0 1-.215-.127l-6.426-6.445-6.426 6.445a.846.846 0 0 1-.215.127.596.596 0 0 1-.468 0 .846.846 0 0 1-.215-.127.65.65 0 0 1-.176-.449c0-.169.059-.318.176-.449l6.445-6.426-6.445-6.426a.65.65 0 0 1-.176-.449c0-.169.059-.318.176-.449a.652.652 0 0 1 .449-.176c.169 0 .319.059.449.176l6.426 6.445 6.426-6.445a.652.652 0 0 1 .449-.176c.169 0 .319.059.449.176.117.13.176.28.176.449z"></path>
                    </svg>
                </i>
            </div>
            <div class="popup-wishlist-full__content mt-10">
                <div class="wishlist">
                    <div class="container">
                        <div class="wishlist__head d-flex justify-content-lg-center align-items-center position-relative mb-15 mb-lg-30">
                            <h2 class="h3 mb-0 text-center" data-js-store-lists-has-items-wishlist="">Wishlist</h2>
                            <div class="wishlist__button-remove position-absolute d-inline-flex align-items-center cursor-pointer right-0 js-store-lists-clear-wishlist" data-js-store-lists-has-items-wishlist="">
                                <i class="mb-4 mr-4">
                                    <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-theme-165" viewBox="0 0 24 24">
                                        <path d="M4.741 21.654a.601.601 0 0 1-.186-.439v-15h-1.25a.598.598 0 0 1-.439-.186.597.597 0 0 1-.186-.439.6.6 0 0 1 .186-.439.604.604 0 0 1 .439-.186h5v-2.5a.6.6 0 0 1 .186-.439.598.598 0 0 1 .439-.186h6.25c.169 0 .315.063.439.186a.601.601 0 0 1 .186.439v2.5h5c.169 0 .315.063.439.186a.601.601 0 0 1 .186.439c0 .17-.062.316-.186.439a.601.601 0 0 1-.439.186h-1.25v15a.6.6 0 0 1-.186.439.601.601 0 0 1-.439.186H5.18a.598.598 0 0 1-.439-.186zM18.305 6.215h-12.5V20.59h12.5V6.215zM9.37 9.525a.601.601 0 0 1 .186.439v6.875c0 .17-.062.316-.186.439a.601.601 0 0 1-.439.186.598.598 0 0 1-.439-.186.598.598 0 0 1-.186-.439V9.965a.6.6 0 0 1 .186-.439.594.594 0 0 1 .438-.186c.169 0 .316.062.44.185zm.185-4.56h5V3.09h-5v1.875zm2.94 4.56a.601.601 0 0 1 .186.439v6.875c0 .17-.062.316-.186.439a.601.601 0 0 1-.439.186.598.598 0 0 1-.439-.186.598.598 0 0 1-.186-.439V9.965a.6.6 0 0 1 .186-.439.604.604 0 0 1 .439-.186c.168 0 .315.062.439.185zm2.246 0a.604.604 0 0 1 .439-.186c.169 0 .315.063.439.186a.601.601 0 0 1 .186.439v6.875c0 .17-.062.316-.186.439a.601.601 0 0 1-.439.186.598.598 0 0 1-.439-.186.598.598 0 0 1-.186-.439V9.965c0-.169.062-.316.186-.44z"></path>
                                    </svg>
                                </i>REMOVE ALL
                            </div>
                        </div>
                        <div class="row" data-js-store-lists-has-items-wishlist="">
                            <div class="col-6 col-md-4 col-lg-3 col-xl-2">
                                <div class="product-wishlist d-flex flex-column mb-30" data-js-product="" data-js-store-lists-product-wishlist="" data-product-handle="typecase-magic-style-keyboard-case-for-ipad-pro-12-9-2021-5th-4th-3rd-gen" data-product-variant-id="41285783388213">
                                    <form method="post" action="/cart/add" accept-charset="UTF-8" class="d-flex flex-column m-0" enctype="multipart/form-data" data-js-product-form="">
                                        <input type="hidden" name="form_type" value="product">
                                        <input type="hidden" name="utf8" value="✓">
                                        <div class="product-wishlist__image product-image product-image--hover-fade position-relative w-100 js-product-images-navigation js-product-images-hovered-end">
                                            <a href="/collections/all/products/typecase-magic-style-keyboard-case-for-ipad-pro-12-9-2021-5th-4th-3rd-gen" class="d-block cursor-default" data-js-product-image="">
                                                <div class="rimage" style="padding-top:128%">
                                                    <img class="rimage__img rimage__img--contain lazyload loaded" data-master="//cdn.shopify.com/s/files/1/0286/4726/0213/products/1_1973ac08-ce55-4ae8-8d39-3f1dc56cc900_{width}x.progressive.jpg?v=1657011411" data-aspect-ratio="0.78125" data-srcset="//cdn.shopify.com/s/files/1/0286/4726/0213/products/1_1973ac08-ce55-4ae8-8d39-3f1dc56cc900_168x.progressive.jpg?v=1657011411 1x, //cdn.shopify.com/s/files/1/0286/4726/0213/products/1_1973ac08-ce55-4ae8-8d39-3f1dc56cc900_336x.progressive.jpg?v=1657011411 2x" data-image-id="32075810996277" alt="Typecase Magic-Style Keyboard Case for iPad Pro 12.9 2021 5th &amp; 4th &amp; 3rd Gen" srcset="//cdn.shopify.com/s/files/1/0286/4726/0213/products/1_1973ac08-ce55-4ae8-8d39-3f1dc56cc900_168x.progressive.jpg?v=1657011411, //cdn.shopify.com/s/files/1/0286/4726/0213/products/1_1973ac08-ce55-4ae8-8d39-3f1dc56cc900_336x.progressive.jpg?v=1657011411 2x" data-was-processed="true">
                                                </div>
                                            </a>
                                            <div class="product-image__overlay-top position-absolute d-flex flex-wrap top-0 left-0 w-100 px-10 pt-10">
                                                <a href="/collections/all/products/typecase-magic-style-keyboard-case-for-ipad-pro-12-9-2021-5th-4th-3rd-gen" class="absolute-stretch cursor-default"></a>
                                                <div class="product-image__overlay-top-left product-wishlist__labels position-relative d-flex flex-column align-items-start mb-10">
                                                    <div class="label label--hot mb-3 mr-3 text-nowrap d-none" data-js-product-label-hot="">Hot</div>
                                                    <div class="label label--new mb-3 mr-3 text-nowrap d-none" data-js-product-label-new="">New</div>
                                                    <div class="label label--sale mb-3 mr-3 text-nowrap d-none" data-js-product-label-sale=""></div>
                                                    <div class="label label--pre-order mb-3 mr-3 text-nowrap d-none" data-js-product-label-pre-order="">Pre-order</div>
                                                    <div class="label label--out-stock mb-3 mr-3 text-nowrap d-none" data-js-product-label-out-stock="">Out stock</div>
                                                </div>
                                                <div class="product-image__overlay-top-right product-wishlist__button-quick-view position-lg-relative d-none d-lg-flex mb-lg-10 ml-lg-auto">
                                                    <a href="" class="button-quick-view d-flex flex-center rounded-circle js-popup-button" data-js-popup-button="quick-view">
                                                        <i>
                                                            <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-theme-154" viewBox="0 0 24 24">
                                                                <path d="M8.528 17.238c-1.107-.592-2.074-1.25-2.9-1.973-.827-.723-1.491-1.393-1.992-2.012-.501-.618-.771-.96-.811-1.025a.571.571 0 0 1-.117-.352c0-.13.039-.247.117-.352.039-.064.306-.406.801-1.025.495-.618 1.159-1.289 1.992-2.012.833-.723 1.803-1.38 2.91-1.973a7.424 7.424 0 0 1 3.555-.889c1.263 0 2.448.297 3.555.889 1.106.593 2.073 1.25 2.9 1.973.827.723 1.491 1.394 1.992 2.012.501.619.771.961.811 1.025a.573.573 0 0 1 .117.352.656.656 0 0 1-.117.371c-.039.053-.31.391-.811 1.016-.501.625-1.169 1.296-2.002 2.012-.833.717-1.804 1.371-2.91 1.963a7.375 7.375 0 0 1-3.535.889 7.415 7.415 0 0 1-3.555-.889zm.869-9.746c-.853.41-1.631.889-2.334 1.436s-1.312 1.101-1.826 1.66c-.515.561-.889.99-1.123 1.289.234.3.608.729 1.123 1.289.514.561 1.123 1.113 1.826 1.66s1.484 1.025 2.344 1.436 1.751.615 2.676.615c.924 0 1.813-.205 2.666-.615.853-.41 1.634-.889 2.344-1.436.709-.547 1.318-1.1 1.826-1.66.508-.56.885-.989 1.133-1.289a41.634 41.634 0 0 0-1.133-1.289c-.508-.56-1.113-1.113-1.816-1.66s-1.484-1.025-2.344-1.436-1.751-.615-2.676-.615c-.937 0-1.833.205-2.686.615zm.04 7.031c-.736-.735-1.104-1.617-1.104-2.646 0-1.028.368-1.91 1.104-2.646.735-.735 1.618-1.104 2.646-1.104 1.028 0 1.911.368 2.646 1.104.735.736 1.104 1.618 1.104 2.646 0 1.029-.368 1.911-1.104 2.646-.736.736-1.618 1.104-2.646 1.104-1.029 0-1.911-.367-2.646-1.104zm.878-4.414a2.41 2.41 0 0 0-.732 1.768c0 .69.244 1.279.732 1.768s1.077.732 1.768.732c.69 0 1.279-.244 1.768-.732s.732-1.077.732-1.768c0-.689-.244-1.279-.732-1.768s-1.078-.732-1.768-.732-1.279.244-1.768.732z"></path>
                                                            </svg>
                                                        </i>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="product-wishlist__content d-flex flex-column align-items-start mt-15">
                                            <div class="product-collection__more-info mb-3">
                                                <a href="/collections/accessories?q=vd_:typecase">Typecase</a>
                                            </div>
                                            <div class="product-wishlist__title mb-3">
                                                <h3 class="m-0">
                                                    <a href="/collections/all/products/typecase-magic-style-keyboard-case-for-ipad-pro-12-9-2021-5th-4th-3rd-gen">Typecase Magic-Style Keyboard Case for iPad Pro 12.9 2021 5th &amp; 4th &amp; 3rd Gen</a>
                                                </h3>
                                            </div>
                                            <div class="product-wishlist__price mb-10">
                                                <span class="price" data-js-product-price="">
                                                    <span>$149.98</span>
                                                </span>
                                            </div>
                                            <div class="d-flex flex-column">
                                                <div class="product-wishlist__variants d-none">
                                                    <select name="id" class="m-0" data-js-product-variants="control">
                                                        <option selected="selected" value="41285783388213">Black − $149.98</option>
                                                        <option value="41285783420981">Pacific Blue − $159.98</option>
                                                        <option value="41285783453749">Rose Gold − $159.98</option>
                                                    </select>
                                                </div>
                                                <div class="product-wishlist__buttons d-flex flex-column flex-lg-row align-items-lg-center flex-wrap mt-5 mt-lg-10">
                                                    <div class="product-wishlist__button-add-to-cart mb-10">
                                                        <a href="/collections/all/products/typecase-magic-style-keyboard-case-for-ipad-pro-12-9-2021-5th-4th-3rd-gen" class="btn btn--status btn--animated js-product-button-add-to-cart" name="add" data-js-product-button-add-to-cart="">
                                                            <span class="d-flex flex-center">
                                                                <i class="btn__icon mr-5 mb-4">
                                                                    <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-theme-109" viewBox="0 0 24 24">
                                                                        <path d="M19.884 21.897a.601.601 0 0 1-.439.186h-15a.6.6 0 0 1-.439-.186.601.601 0 0 1-.186-.439v-15a.6.6 0 0 1 .186-.439.601.601 0 0 1 .439-.186h3.75c0-1.028.368-1.911 1.104-2.646.735-.735 1.618-1.104 2.646-1.104s1.911.368 2.646 1.104c.735.736 1.104 1.618 1.104 2.646h3.75a.6.6 0 0 1 .439.186.601.601 0 0 1 .186.439v15a.604.604 0 0 1-.186.439zM18.819 7.083h-3.125v2.5a.598.598 0 0 1-.186.439c-.124.124-.271.186-.439.186s-.315-.062-.439-.186a.6.6 0 0 1-.186-.439v-2.5h-5v2.5a.598.598 0 0 1-.186.439c-.124.124-.271.186-.439.186s-.315-.062-.439-.186a.6.6 0 0 1-.186-.439v-2.5H5.069v13.75h13.75V7.083zm-8.642-3.018a2.409 2.409 0 0 0-.733 1.768h5c0-.69-.244-1.279-.732-1.768s-1.077-.732-1.768-.732-1.279.244-1.767.732z"></path>
                                                                    </svg>
                                                                </i>
                                                                <span class="btn__text">Add To Cart</span>
                                                            </span>
                                                            <span class="d-flex flex-center" data-button-content="added">
                                                                <i class="mr-5 mb-4">
                                                                    <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-theme-110" viewBox="0 0 24 24">
                                                                        <path d="M19.855 5.998a.601.601 0 0 0-.439-.186h-3.75c0-1.028-.368-1.911-1.104-2.646-.735-.735-1.618-1.104-2.646-1.104s-1.911.369-2.646 1.104c-.736.736-1.104 1.618-1.104 2.647h-3.75a.6.6 0 0 0-.439.186.598.598 0 0 0-.186.439v15a.6.6 0 0 0 .186.439c.124.123.27.186.439.186h15a.6.6 0 0 0 .439-.186.601.601 0 0 0 .186-.439v-15a.602.602 0 0 0-.186-.44zm-9.707-1.953c.488-.488 1.077-.732 1.768-.732s1.279.244 1.768.732.732 1.078.732 1.768h-5c0-.69.244-1.28.732-1.768zm6.926 7.194l-6.25 6.25a.877.877 0 0 1-.215.127.596.596 0 0 1-.468 0 .896.896 0 0 1-.215-.127l-2.5-2.5a.652.652 0 0 1-.176-.449c0-.169.059-.319.176-.449.13-.117.28-.176.449-.176s.319.059.449.176l2.051 2.07 5.801-5.82c.13-.117.28-.176.449-.176s.319.059.449.176c.117.13.176.28.176.449a.652.652 0 0 1-.176.449z"></path>
                                                                    </svg>
                                                                </i>Added </span>
                                                            <span class="d-flex flex-center" data-button-content="sold-out">Sold Out</span>
                                                            <span class="d-flex flex-center" data-button-content="pre-order">
                                                                <i class="btn__icon mr-5 mb-4">
                                                                    <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-theme-109" viewBox="0 0 24 24">
                                                                        <path d="M19.884 21.897a.601.601 0 0 1-.439.186h-15a.6.6 0 0 1-.439-.186.601.601 0 0 1-.186-.439v-15a.6.6 0 0 1 .186-.439.601.601 0 0 1 .439-.186h3.75c0-1.028.368-1.911 1.104-2.646.735-.735 1.618-1.104 2.646-1.104s1.911.368 2.646 1.104c.735.736 1.104 1.618 1.104 2.646h3.75a.6.6 0 0 1 .439.186.601.601 0 0 1 .186.439v15a.604.604 0 0 1-.186.439zM18.819 7.083h-3.125v2.5a.598.598 0 0 1-.186.439c-.124.124-.271.186-.439.186s-.315-.062-.439-.186a.6.6 0 0 1-.186-.439v-2.5h-5v2.5a.598.598 0 0 1-.186.439c-.124.124-.271.186-.439.186s-.315-.062-.439-.186a.6.6 0 0 1-.186-.439v-2.5H5.069v13.75h13.75V7.083zm-8.642-3.018a2.409 2.409 0 0 0-.733 1.768h5c0-.69-.244-1.279-.732-1.768s-1.077-.732-1.768-.732-1.279.244-1.767.732z"></path>
                                                                    </svg>
                                                                </i>
                                                                <span class="btn__text">Pre-Order</span>
                                                            </span>
                                                        </a>
                                                    </div>
                                                    <div class="product-collection__buttons-section d-flex d-lg-none px-lg-10">
                                                        <div class="product-wishlist__button-quick-view-mobile mb-10">
                                                            <a href="" class="btn btn--text pt-2 px-lg-6 js-popup-button" data-js-popup-button="quick-view">
                                                                <i>
                                                                    <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-theme-154" viewBox="0 0 24 24">
                                                                        <path d="M8.528 17.238c-1.107-.592-2.074-1.25-2.9-1.973-.827-.723-1.491-1.393-1.992-2.012-.501-.618-.771-.96-.811-1.025a.571.571 0 0 1-.117-.352c0-.13.039-.247.117-.352.039-.064.306-.406.801-1.025.495-.618 1.159-1.289 1.992-2.012.833-.723 1.803-1.38 2.91-1.973a7.424 7.424 0 0 1 3.555-.889c1.263 0 2.448.297 3.555.889 1.106.593 2.073 1.25 2.9 1.973.827.723 1.491 1.394 1.992 2.012.501.619.771.961.811 1.025a.573.573 0 0 1 .117.352.656.656 0 0 1-.117.371c-.039.053-.31.391-.811 1.016-.501.625-1.169 1.296-2.002 2.012-.833.717-1.804 1.371-2.91 1.963a7.375 7.375 0 0 1-3.535.889 7.415 7.415 0 0 1-3.555-.889zm.869-9.746c-.853.41-1.631.889-2.334 1.436s-1.312 1.101-1.826 1.66c-.515.561-.889.99-1.123 1.289.234.3.608.729 1.123 1.289.514.561 1.123 1.113 1.826 1.66s1.484 1.025 2.344 1.436 1.751.615 2.676.615c.924 0 1.813-.205 2.666-.615.853-.41 1.634-.889 2.344-1.436.709-.547 1.318-1.1 1.826-1.66.508-.56.885-.989 1.133-1.289a41.634 41.634 0 0 0-1.133-1.289c-.508-.56-1.113-1.113-1.816-1.66s-1.484-1.025-2.344-1.436-1.751-.615-2.676-.615c-.937 0-1.833.205-2.686.615zm.04 7.031c-.736-.735-1.104-1.617-1.104-2.646 0-1.028.368-1.91 1.104-2.646.735-.735 1.618-1.104 2.646-1.104 1.028 0 1.911.368 2.646 1.104.735.736 1.104 1.618 1.104 2.646 0 1.029-.368 1.911-1.104 2.646-.736.736-1.618 1.104-2.646 1.104-1.029 0-1.911-.367-2.646-1.104zm.878-4.414a2.41 2.41 0 0 0-.732 1.768c0 .69.244 1.279.732 1.768s1.077.732 1.768.732c.69 0 1.279-.244 1.768-.732s.732-1.077.732-1.768c0-.689-.244-1.279-.732-1.768s-1.078-.732-1.768-.732-1.279.244-1.768.732z"></path>
                                                                    </svg>
                                                                </i>
                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="product-wishlist__remove btn-link js-store-lists-remove-wishlist">Remove</div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                            <div class="col-6 col-md-4 col-lg-3 col-xl-2">
                                <div class="product-wishlist d-flex flex-column mb-30" data-js-product="" data-js-store-lists-product-wishlist="" data-product-handle="typecase-touch-pro-11-air-4" data-product-variant-id="39783307411509">
                                    <form method="post" action="/cart/add" accept-charset="UTF-8" class="d-flex flex-column m-0" enctype="multipart/form-data" data-js-product-form="">
                                        <input type="hidden" name="form_type" value="product">
                                        <input type="hidden" name="utf8" value="✓">
                                        <div class="product-wishlist__image product-image product-image--hover-fade position-relative w-100 js-product-images-navigation js-product-images-hovered-end">
                                            <a href="/collections/all/products/typecase-touch-pro-11-air-4" class="d-block cursor-default" data-js-product-image="">
                                                <div class="rimage" style="padding-top:128%">
                                                    <img class="rimage__img rimage__img--contain lazyload loaded" data-master="//cdn.shopify.com/s/files/1/0286/4726/0213/products/KB201T-129-3.3198_{width}x.progressive.png.jpg?v=1626739767" data-aspect-ratio="0.78125" data-srcset="//cdn.shopify.com/s/files/1/0286/4726/0213/products/KB201T-129-3.3198_168x.progressive.png.jpg?v=1626739767 1x, //cdn.shopify.com/s/files/1/0286/4726/0213/products/KB201T-129-3.3198_336x.progressive.png.jpg?v=1626739767 2x" data-image-id="29894742605877" alt="Typecase Keyboard Case with Trackpad for iPad Pro 11 &amp; iPad Air 5th &amp; 4th Gen" srcset="//cdn.shopify.com/s/files/1/0286/4726/0213/products/KB201T-129-3.3198_168x.progressive.png.jpg?v=1626739767, //cdn.shopify.com/s/files/1/0286/4726/0213/products/KB201T-129-3.3198_336x.progressive.png.jpg?v=1626739767 2x" data-was-processed="true">
                                                </div>
                                            </a>
                                            <div class="product-image__overlay-top position-absolute d-flex flex-wrap top-0 left-0 w-100 px-10 pt-10">
                                                <a href="/collections/all/products/typecase-touch-pro-11-air-4" class="absolute-stretch cursor-default"></a>
                                                <div class="product-image__overlay-top-left product-wishlist__labels position-relative d-flex flex-column align-items-start mb-10">
                                                    <div class="label label--hot mb-3 mr-3 text-nowrap d-none" data-js-product-label-hot="">Hot</div>
                                                    <div class="label label--new mb-3 mr-3 text-nowrap d-none" data-js-product-label-new="">New</div>
                                                    <div class="label label--sale mb-3 mr-3 text-nowrap d-none" data-js-product-label-sale=""></div>
                                                    <div class="label label--pre-order mb-3 mr-3 text-nowrap d-none" data-js-product-label-pre-order="">Pre-order</div>
                                                    <div class="label label--out-stock mb-3 mr-3 text-nowrap d-none" data-js-product-label-out-stock="">Out stock</div>
                                                </div>
                                                <div class="product-image__overlay-top-right product-wishlist__button-quick-view position-lg-relative d-none d-lg-flex mb-lg-10 ml-lg-auto">
                                                    <a href="" class="button-quick-view d-flex flex-center rounded-circle js-popup-button" data-js-popup-button="quick-view">
                                                        <i>
                                                            <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-theme-154" viewBox="0 0 24 24">
                                                                <path d="M8.528 17.238c-1.107-.592-2.074-1.25-2.9-1.973-.827-.723-1.491-1.393-1.992-2.012-.501-.618-.771-.96-.811-1.025a.571.571 0 0 1-.117-.352c0-.13.039-.247.117-.352.039-.064.306-.406.801-1.025.495-.618 1.159-1.289 1.992-2.012.833-.723 1.803-1.38 2.91-1.973a7.424 7.424 0 0 1 3.555-.889c1.263 0 2.448.297 3.555.889 1.106.593 2.073 1.25 2.9 1.973.827.723 1.491 1.394 1.992 2.012.501.619.771.961.811 1.025a.573.573 0 0 1 .117.352.656.656 0 0 1-.117.371c-.039.053-.31.391-.811 1.016-.501.625-1.169 1.296-2.002 2.012-.833.717-1.804 1.371-2.91 1.963a7.375 7.375 0 0 1-3.535.889 7.415 7.415 0 0 1-3.555-.889zm.869-9.746c-.853.41-1.631.889-2.334 1.436s-1.312 1.101-1.826 1.66c-.515.561-.889.99-1.123 1.289.234.3.608.729 1.123 1.289.514.561 1.123 1.113 1.826 1.66s1.484 1.025 2.344 1.436 1.751.615 2.676.615c.924 0 1.813-.205 2.666-.615.853-.41 1.634-.889 2.344-1.436.709-.547 1.318-1.1 1.826-1.66.508-.56.885-.989 1.133-1.289a41.634 41.634 0 0 0-1.133-1.289c-.508-.56-1.113-1.113-1.816-1.66s-1.484-1.025-2.344-1.436-1.751-.615-2.676-.615c-.937 0-1.833.205-2.686.615zm.04 7.031c-.736-.735-1.104-1.617-1.104-2.646 0-1.028.368-1.91 1.104-2.646.735-.735 1.618-1.104 2.646-1.104 1.028 0 1.911.368 2.646 1.104.735.736 1.104 1.618 1.104 2.646 0 1.029-.368 1.911-1.104 2.646-.736.736-1.618 1.104-2.646 1.104-1.029 0-1.911-.367-2.646-1.104zm.878-4.414a2.41 2.41 0 0 0-.732 1.768c0 .69.244 1.279.732 1.768s1.077.732 1.768.732c.69 0 1.279-.244 1.768-.732s.732-1.077.732-1.768c0-.689-.244-1.279-.732-1.768s-1.078-.732-1.768-.732-1.279.244-1.768.732z"></path>
                                                            </svg>
                                                        </i>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="product-wishlist__content d-flex flex-column align-items-start mt-15">
                                            <div class="product-collection__more-info mb-3">
                                                <a href="/collections/typecase?q=vd_:typecase">Typecase</a>
                                            </div>
                                            <div class="product-wishlist__title mb-3">
                                                <h3 class="m-0">
                                                    <a href="/collections/all/products/typecase-touch-pro-11-air-4">Typecase Keyboard Case with Trackpad for iPad Pro 11 &amp; iPad Air 5th &amp; 4th Gen</a>
                                                </h3>
                                            </div>
                                            <div class="product-wishlist__price mb-10">
                                                <span class="price" data-js-product-price="">
                                                    <span>$69.99</span>
                                                </span>
                                            </div>
                                            <div class="d-flex flex-column">
                                                <div class="product-wishlist__variants d-none">
                                                    <select name="id" class="m-0" data-js-product-variants="control">
                                                        <option selected="selected" value="39783307411509">Black − $69.99</option>
                                                        <option value="39783307444277">Rose Dust − $72.99</option>
                                                        <option value="39849497919541">Pacific Blue − $79.99</option>
                                                        <option value="39849501327413">Violet − $89.99</option>
                                                    </select>
                                                </div>
                                                <div class="product-wishlist__buttons d-flex flex-column flex-lg-row align-items-lg-center flex-wrap mt-5 mt-lg-10">
                                                    <div class="product-wishlist__button-add-to-cart mb-10">
                                                        <a href="/collections/all/products/typecase-touch-pro-11-air-4" class="btn btn--status btn--animated js-product-button-add-to-cart" name="add" data-js-product-button-add-to-cart="">
                                                            <span class="d-flex flex-center">
                                                                <i class="btn__icon mr-5 mb-4">
                                                                    <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-theme-109" viewBox="0 0 24 24">
                                                                        <path d="M19.884 21.897a.601.601 0 0 1-.439.186h-15a.6.6 0 0 1-.439-.186.601.601 0 0 1-.186-.439v-15a.6.6 0 0 1 .186-.439.601.601 0 0 1 .439-.186h3.75c0-1.028.368-1.911 1.104-2.646.735-.735 1.618-1.104 2.646-1.104s1.911.368 2.646 1.104c.735.736 1.104 1.618 1.104 2.646h3.75a.6.6 0 0 1 .439.186.601.601 0 0 1 .186.439v15a.604.604 0 0 1-.186.439zM18.819 7.083h-3.125v2.5a.598.598 0 0 1-.186.439c-.124.124-.271.186-.439.186s-.315-.062-.439-.186a.6.6 0 0 1-.186-.439v-2.5h-5v2.5a.598.598 0 0 1-.186.439c-.124.124-.271.186-.439.186s-.315-.062-.439-.186a.6.6 0 0 1-.186-.439v-2.5H5.069v13.75h13.75V7.083zm-8.642-3.018a2.409 2.409 0 0 0-.733 1.768h5c0-.69-.244-1.279-.732-1.768s-1.077-.732-1.768-.732-1.279.244-1.767.732z"></path>
                                                                    </svg>
                                                                </i>
                                                                <span class="btn__text">Add To Cart</span>
                                                            </span>
                                                            <span class="d-flex flex-center" data-button-content="added">
                                                                <i class="mr-5 mb-4">
                                                                    <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-theme-110" viewBox="0 0 24 24">
                                                                        <path d="M19.855 5.998a.601.601 0 0 0-.439-.186h-3.75c0-1.028-.368-1.911-1.104-2.646-.735-.735-1.618-1.104-2.646-1.104s-1.911.369-2.646 1.104c-.736.736-1.104 1.618-1.104 2.647h-3.75a.6.6 0 0 0-.439.186.598.598 0 0 0-.186.439v15a.6.6 0 0 0 .186.439c.124.123.27.186.439.186h15a.6.6 0 0 0 .439-.186.601.601 0 0 0 .186-.439v-15a.602.602 0 0 0-.186-.44zm-9.707-1.953c.488-.488 1.077-.732 1.768-.732s1.279.244 1.768.732.732 1.078.732 1.768h-5c0-.69.244-1.28.732-1.768zm6.926 7.194l-6.25 6.25a.877.877 0 0 1-.215.127.596.596 0 0 1-.468 0 .896.896 0 0 1-.215-.127l-2.5-2.5a.652.652 0 0 1-.176-.449c0-.169.059-.319.176-.449.13-.117.28-.176.449-.176s.319.059.449.176l2.051 2.07 5.801-5.82c.13-.117.28-.176.449-.176s.319.059.449.176c.117.13.176.28.176.449a.652.652 0 0 1-.176.449z"></path>
                                                                    </svg>
                                                                </i>Added </span>
                                                            <span class="d-flex flex-center" data-button-content="sold-out">Sold Out</span>
                                                            <span class="d-flex flex-center" data-button-content="pre-order">
                                                                <i class="btn__icon mr-5 mb-4">
                                                                    <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-theme-109" viewBox="0 0 24 24">
                                                                        <path d="M19.884 21.897a.601.601 0 0 1-.439.186h-15a.6.6 0 0 1-.439-.186.601.601 0 0 1-.186-.439v-15a.6.6 0 0 1 .186-.439.601.601 0 0 1 .439-.186h3.75c0-1.028.368-1.911 1.104-2.646.735-.735 1.618-1.104 2.646-1.104s1.911.368 2.646 1.104c.735.736 1.104 1.618 1.104 2.646h3.75a.6.6 0 0 1 .439.186.601.601 0 0 1 .186.439v15a.604.604 0 0 1-.186.439zM18.819 7.083h-3.125v2.5a.598.598 0 0 1-.186.439c-.124.124-.271.186-.439.186s-.315-.062-.439-.186a.6.6 0 0 1-.186-.439v-2.5h-5v2.5a.598.598 0 0 1-.186.439c-.124.124-.271.186-.439.186s-.315-.062-.439-.186a.6.6 0 0 1-.186-.439v-2.5H5.069v13.75h13.75V7.083zm-8.642-3.018a2.409 2.409 0 0 0-.733 1.768h5c0-.69-.244-1.279-.732-1.768s-1.077-.732-1.768-.732-1.279.244-1.767.732z"></path>
                                                                    </svg>
                                                                </i>
                                                                <span class="btn__text">Pre-Order</span>
                                                            </span>
                                                        </a>
                                                    </div>
                                                    <div class="product-collection__buttons-section d-flex d-lg-none px-lg-10">
                                                        <div class="product-wishlist__button-quick-view-mobile mb-10">
                                                            <a href="" class="btn btn--text pt-2 px-lg-6 js-popup-button" data-js-popup-button="quick-view">
                                                                <i>
                                                                    <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-theme-154" viewBox="0 0 24 24">
                                                                        <path d="M8.528 17.238c-1.107-.592-2.074-1.25-2.9-1.973-.827-.723-1.491-1.393-1.992-2.012-.501-.618-.771-.96-.811-1.025a.571.571 0 0 1-.117-.352c0-.13.039-.247.117-.352.039-.064.306-.406.801-1.025.495-.618 1.159-1.289 1.992-2.012.833-.723 1.803-1.38 2.91-1.973a7.424 7.424 0 0 1 3.555-.889c1.263 0 2.448.297 3.555.889 1.106.593 2.073 1.25 2.9 1.973.827.723 1.491 1.394 1.992 2.012.501.619.771.961.811 1.025a.573.573 0 0 1 .117.352.656.656 0 0 1-.117.371c-.039.053-.31.391-.811 1.016-.501.625-1.169 1.296-2.002 2.012-.833.717-1.804 1.371-2.91 1.963a7.375 7.375 0 0 1-3.535.889 7.415 7.415 0 0 1-3.555-.889zm.869-9.746c-.853.41-1.631.889-2.334 1.436s-1.312 1.101-1.826 1.66c-.515.561-.889.99-1.123 1.289.234.3.608.729 1.123 1.289.514.561 1.123 1.113 1.826 1.66s1.484 1.025 2.344 1.436 1.751.615 2.676.615c.924 0 1.813-.205 2.666-.615.853-.41 1.634-.889 2.344-1.436.709-.547 1.318-1.1 1.826-1.66.508-.56.885-.989 1.133-1.289a41.634 41.634 0 0 0-1.133-1.289c-.508-.56-1.113-1.113-1.816-1.66s-1.484-1.025-2.344-1.436-1.751-.615-2.676-.615c-.937 0-1.833.205-2.686.615zm.04 7.031c-.736-.735-1.104-1.617-1.104-2.646 0-1.028.368-1.91 1.104-2.646.735-.735 1.618-1.104 2.646-1.104 1.028 0 1.911.368 2.646 1.104.735.736 1.104 1.618 1.104 2.646 0 1.029-.368 1.911-1.104 2.646-.736.736-1.618 1.104-2.646 1.104-1.029 0-1.911-.367-2.646-1.104zm.878-4.414a2.41 2.41 0 0 0-.732 1.768c0 .69.244 1.279.732 1.768s1.077.732 1.768.732c.69 0 1.279-.244 1.768-.732s.732-1.077.732-1.768c0-.689-.244-1.279-.732-1.768s-1.078-.732-1.768-.732-1.279.244-1.768.732z"></path>
                                                                    </svg>
                                                                </i>
                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="product-wishlist__remove btn-link js-store-lists-remove-wishlist">Remove</div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <div class="d-flex flex-column align-items-center py-40 py-md-100 my-100 d-none" data-js-store-lists-dhas-items-wishlist="">
                            <h3>Wishlist</h3>
                            <p>No products were added to the Wishlist</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="popup__body position-relative d-none flex-center px-15 py-30" id="product-detail-popup" data-popup-center="">
        <div class="popup-product-detail-full py-25 px-20" data-popup-content="">
            <div class="popup-product-detail-full__head d-flex align-items-center">
                <i class="popup-product-detail-full__close ml-auto cursor-pointer" onclick="nav_close()">
                    <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-theme-164" viewBox="0 0 24 24">
                        <path d="M19.583 4.965a.65.65 0 0 1-.176.449l-6.445 6.426 6.445 6.426c.117.131.176.28.176.449a.65.65 0 0 1-.176.449.846.846 0 0 1-.215.127.596.596 0 0 1-.468 0 .846.846 0 0 1-.215-.127l-6.426-6.445-6.426 6.445a.846.846 0 0 1-.215.127.596.596 0 0 1-.468 0 .846.846 0 0 1-.215-.127.65.65 0 0 1-.176-.449c0-.169.059-.318.176-.449l6.445-6.426-6.445-6.426a.65.65 0 0 1-.176-.449c0-.169.059-.318.176-.449a.652.652 0 0 1 .449-.176c.169 0 .319.059.449.176l6.426 6.445 6.426-6.445a.652.652 0 0 1 .449-.176c.169 0 .319.059.449.176.117.13.176.28.176.449z"></path>
                    </svg>
                </i>
            </div>
            <div class="product-page mt-30 mb-30">
            <div class="container">
                <div class="product-page__container">
                    <div class="product-page__main">
                        <div class="row">
                            <div class="col-12 col-lg-6">
                                <div class="product-page-gallery mx-auto pb-20 position-relative top-0">
                                    <div class="d-flex">
                                        <div class="d-none d-lg-block mr-10">
                                            <div thumbsSlider="" class="swiper popup-mySwiper product-page-gallery__preview">
                                                <div class="swiper-wrapper">
                                                    <div class="swiper-slide">
                                                    <img src="https://swiperjs.com/demos/images/nature-1.jpg" />
                                                    </div>
                                                    <div class="swiper-slide">
                                                    <img src="https://swiperjs.com/demos/images/nature-2.jpg" />
                                                    </div>
                                                    <div class="swiper-slide">
                                                    <img src="https://swiperjs.com/demos/images/nature-3.jpg" />
                                                    </div>
                                                    <div class="swiper-slide">
                                                    <img src="https://swiperjs.com/demos/images/nature-4.jpg" />
                                                    </div>
                                                    <div class="swiper-slide">
                                                    <img src="https://swiperjs.com/demos/images/nature-5.jpg" />
                                                    </div>
                                                    <div class="swiper-slide">
                                                    <img src="https://swiperjs.com/demos/images/nature-6.jpg" />
                                                    </div>
                                                    <div class="swiper-slide">
                                                    <img src="https://swiperjs.com/demos/images/nature-7.jpg" />
                                                    </div>
                                                    <div class="swiper-slide">
                                                    <img src="https://swiperjs.com/demos/images/nature-8.jpg" />
                                                    </div>
                                                    <div class="swiper-slide">
                                                    <img src="https://swiperjs.com/demos/images/nature-9.jpg" />
                                                    </div>
                                                    <div class="swiper-slide">
                                                    <img src="https://swiperjs.com/demos/images/nature-10.jpg" />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="swiper popup-mySwiper2 product-page-gallery__main">
                                            <div class="swiper-wrapper">
                                                <div class="swiper-slide">
                                                <img src="https://swiperjs.com/demos/images/nature-1.jpg" />
                                                </div>
                                                <div class="swiper-slide">
                                                <img src="https://swiperjs.com/demos/images/nature-2.jpg" />
                                                </div>
                                                <div class="swiper-slide">
                                                <img src="https://swiperjs.com/demos/images/nature-3.jpg" />
                                                </div>
                                                <div class="swiper-slide">
                                                <img src="https://swiperjs.com/demos/images/nature-4.jpg" />
                                                </div>
                                                <div class="swiper-slide">
                                                <img src="https://swiperjs.com/demos/images/nature-5.jpg" />
                                                </div>
                                                <div class="swiper-slide">
                                                <img src="https://swiperjs.com/demos/images/nature-6.jpg" />
                                                </div>
                                                <div class="swiper-slide">
                                                <img src="https://swiperjs.com/demos/images/nature-7.jpg" />
                                                </div>
                                                <div class="swiper-slide">
                                                <img src="https://swiperjs.com/demos/images/nature-8.jpg" />
                                                </div>
                                                <div class="swiper-slide">
                                                <img src="https://swiperjs.com/demos/images/nature-9.jpg" />
                                                </div>
                                                <div class="swiper-slide">
                                                <img src="https://swiperjs.com/demos/images/nature-10.jpg" />
                                                </div>
                                            </div>
                                            <div class="swiper-button-next"></div>
                                            <div class="swiper-button-prev"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-12 col-lg-6">
                                <div class="product-page-info">
                                    <div class="product-page-info__labels d-flex justify-content-center justify-content-lg-start"><div class="label label--hot mb-3 mr-3 text-nowrap d-none" data-js-product-label-hot="">Hot</div>
                                        <div class="label d-none label--new mb-3 mr-3 text-nowrap">New</div>
                                        <div class="label d-none label--sale mb-3 mr-3 text-nowrap"></div>
                                        <div class="label label--in-stock mb-3 mr-3 text-nowrap">In stock</div>
                                        <div class="label d-none label--pre-order mb-3 mr-3 text-nowrap ">Pre-order</div>
                                        <div class="label d-none label--out-stock mb-3 mr-3 text-nowrap">Out stock</div>
                                    </div>
                                    <div class="product-page-info__title mb-15 text-center text-lg-left"><h1 class="m-0">2 Pack Dog Collar Holder for Airtag - Black/Blue</h1></div>
                                    <div class="product-page-info__details mb-25 text-center text-lg-left">
                                        <div class="product-page-info__sku mb-5">
                                            <p class="m-0" data-js-product-sku="">SKU: <span>HYY-ATG-PET-FL-2P-VS1</span></p>
                                        </div>
                                        <div class="product-page-info__vendor mb-5">
                                            <p class="m-0" data-js-product-vendor="">VENDOR: <span>Typecase</span></p>
                                        </div>
                                    </div>
                                    <div class="product-page-info__price text-center text-lg-left mb-25">
                                        <span class="price" data-js-product-price="">$12.99</span>
                                    </div>
                                    <p class="product-page-info__price-sale-details mt-5 mt-lg-10 text-center text-lg-left d-none" data-js-product-price-sale-details=""></p>
                                    <div class="mt-20">
                                        <klarna-placement class="mw-100-inner" data-key="credit-promotion-small" data-locale="en-US" data-purchase-amount="1299"></klarna-placement>
                                    </div>
                                    <div class="product-page-info__text-countdown mt-35 mb-25">
                                        <div class="text-countdown px-8 py-3 text-center text-lg-left js-text-countdown text-countdown--init" data-reset-time="2" data-delivery-time="3" data-delivery-format="Day MM/DD/YYYY" data-delivery-excludes="Saturday, Sunday">
                                            <i class="mr-4"><svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-theme-116" viewBox="0 0 24 24"><path d="M21.93 6.088l.029.029c.007.007.01.017.01.029l.039.127a.47.47 0 0 1 .02.127v15a.6.6 0 0 1-.186.439.601.601 0 0 1-.439.186H2.652a.6.6 0 0 1-.439-.186.601.601 0 0 1-.186-.439v-15a.47.47 0 0 1 .02-.127l.039-.127c0-.013.003-.022.01-.029a.387.387 0 0 0 .029-.029.478.478 0 0 1 .049-.078.844.844 0 0 1 .049-.059l.02-.02 4.375-3.75a.776.776 0 0 1 .195-.117.575.575 0 0 1 .215-.039h10c.078 0 .149.013.215.039.065.026.13.065.195.117l4.375 3.75v.02a.19.19 0 0 1 .068.059.557.557 0 0 1 .049.078zm-1.153 14.687V7.025h-5.625v5.625a.598.598 0 0 1-.186.439.601.601 0 0 1-.439.186h-5a.6.6 0 0 1-.439-.186.6.6 0 0 1-.186-.439V7.025H3.277v13.75h17.5zM7.262 3.275l-2.93 2.5h4.805l1.25-2.5H7.262zm2.89 8.75h3.75v-5h-3.75v5zm1.641-8.75l-1.25 2.5h2.969l-1.25-2.5h-.469zm7.93 2.5l-2.93-2.5h-3.125l1.25 2.5h4.805z"></path></svg></i> Order in the next <span class="text-countdown__counter" data-js-text-countdown-counter="">13 hours 50 minutes</span> to get it by <span class="text-underline" data-js-text-countdown-delivery="">Friday 01/06/2023</span>
                                        </div>
                                    </div>
                                    <div class="product-page-info__visitors mt-25 mb-25">
                                        <div class="visitors ls-0 text-center text-lg-left js-visitors visitors--processing visitors--init" data-min="10" data-max="25" data-interval-min="2" data-interval-max="6" data-stroke="4">
                                        Real time <span class="visitors__counter d-inline-block px-8" data-js-counter="">23</span> visitor right now
                                        </div>
                                    </div>
                                    <form method="post" action="/cart/add" accept-charset="UTF-8" class="d-flex flex-column w-100 m-0" enctype="multipart/form-data" data-js-product-form="" siq_id="autopick_1686">
                                        <div class="product-page-info__options mb-15">
                                            <div class="product-options product-options--type-page js-product-options" data-js-product-options="" data-js-change-history="" data-variant-was-chanched="true">
                                                <div data-section-container="">
                                                    <label>
                                                        <span>Pack:</span>
                                                        <span class="ml-5" data-label-value="">Floral</span>
                                                    </label>
                                                    <div class="product-options__section d-flex flex-wrap" data-style="text" data-property="pack">
                                                        <div class="product-options__value product-options__value--text d-flex flex-center border cursor-pointer" data-js-option-value="" data-value="blackblue" data-js-trigger-id="footbar-pack-blackblue" data-bg="none" data-scale="2" data-was-processed="true" style="background-image:none">Black/Blue</div>
                                                        <div class="product-options__value product-options__value--text d-flex flex-center border cursor-pointer" data-js-option-value="" data-value="blackwhite" data-js-trigger-id="footbar-pack-blackwhite" data-bg="none" data-scale="2" data-was-processed="true" style="background-image:none">Black/White</div>
                                                        <div class="product-options__value product-options__value--text d-flex flex-center border cursor-pointer" data-js-option-value="" data-value="purplepink" data-js-trigger-id="footbar-pack-purplepink" data-bg="none" data-scale="2" data-was-processed="true" style="background-image:none">Purple/Pink</div>
                                                        <div class="product-options__value product-options__value--text d-flex flex-center border cursor-pointer" data-js-option-value="" data-value="mintgreen" data-js-trigger-id="footbar-pack-mintgreen" data-bg="none" data-scale="2" data-was-processed="true" style="background-image:none">Mint Green</div>
                                                        <div class="product-options__value product-options__value--text d-flex flex-center border cursor-pointer active" data-js-option-value="" data-value="floral" data-js-trigger-id="footbar-pack-floral" data-bg="none" data-scale="2" data-was-processed="true" style="background-image:none">Floral</div>
                                                        <div class="product-options__value product-options__value--text d-flex flex-center border cursor-pointer" data-js-option-value="" data-value="greenblue" data-js-trigger-id="footbar-pack-greenblue" data-bg="none" data-scale="2" data-was-processed="true" style="background-image:none">Green+Blue</div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="product-page-info__variants mb-15 d-none">
                                            <select name="id" class="m-0" data-js-product-variants="">
                                                <option selected="selected" value="39787369332789">Black/Blue</option>
                                                <option value="39787369365557">Black/White</option>
                                                <option value="39787369398325">Purple/Pink</option>
                                                <option value="39847463190581">Mint Green</option>
                                                <option value="39847464370229">Floral</option>
                                                <option value="39847545274421">Green+Blue</option>
                                            </select>
                                        </div>
                                        <div class="product-page-info__details-buttons mb-30 mb-lg-15">
                                            <div class="row justify-content-center justify-content-lg-start">
                                                <div class="col-auto">
                                                    <div class="btn-link h6 d-flex align-items-center mb-10 js-popup-button" data-js-popup-button="delivery-return">
                                                        <i class="mr-7">
                                                            <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-theme-135" viewBox="0 0 24 24">
                                                                <path d="M21.87 18.387a.601.601 0 0 1 .186.439.598.598 0 0 1-.186.439.601.601 0 0 1-.439.186H8.247a3.038 3.038 0 0 1-1.074 1.787 3.03 3.03 0 0 1-1.992.713 3.01 3.01 0 0 1-2.207-.918 3.01 3.01 0 0 1-.918-2.207c0-.755.237-1.419.713-1.992a3.033 3.033 0 0 1 1.787-1.074V3.201H2.68a.598.598 0 0 1-.439-.186.6.6 0 0 1-.186-.439.6.6 0 0 1 .186-.439.6.6 0 0 1 .439-.186h2.5a.6.6 0 0 1 .439.186.601.601 0 0 1 .186.439V15.76a3.11 3.11 0 0 1 1.582.859c.442.443.729.97.859 1.582H21.43c.169 0 .316.062.44.186zM6.508 20.154a1.81 1.81 0 0 0 .547-1.328 1.81 1.81 0 0 0-.547-1.328 1.812 1.812 0 0 0-1.328-.547 1.81 1.81 0 0 0-1.328.547 1.808 1.808 0 0 0-.547 1.328c0 .521.182.964.547 1.328.364.365.807.547 1.328.547s.964-.182 1.328-.547zm1.797-3.828a.598.598 0 0 1-.439-.186.6.6 0 0 1-.186-.439V6.326a.6.6 0 0 1 .186-.439.6.6 0 0 1 .439-.186h11.25a.6.6 0 0 1 .439.186.601.601 0 0 1 .186.439v9.375a.598.598 0 0 1-.186.439.601.601 0 0 1-.439.186H8.305zm.625-1.25h10V6.951h-10v8.125z"></path>
                                                            </svg>
                                                        </i>DELIVERY &amp; RETURN
                                                    </div>
                                                </div>
                                                <div class="col-auto">
                                                    <div class="btn-link h6 d-flex align-items-center mb-10 js-popup-button" data-js-popup-button="message">
                                                        <i class="mr-6">
                                                            <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-theme-078" viewBox="0 0 24 24">
                                                                <path d="M2.481 16.107c-.117-.13-.176-.28-.176-.449s.059-.319.176-.449l12.5-12.5c.13-.117.28-.176.449-.176s.319.059.449.176l4.375 4.375c.117.13.176.28.176.449s-.059.319-.176.449l-12.5 12.5c-.065.052-.137.095-.215.127s-.156.049-.234.049-.156-.017-.234-.049-.149-.075-.215-.127l-4.375-4.375zm2.949-2.07l-1.621 1.621 3.496 3.496L18.926 7.533 15.43 4.037l-1.621 1.621 1.445 1.426c.117.13.176.28.176.449s-.059.319-.176.449c-.065.052-.137.095-.215.127s-.156.049-.234.049-.156-.017-.234-.049-.149-.075-.215-.127L12.93 6.537l-.996.996.82.801c.117.13.176.28.176.449s-.059.319-.176.449c-.065.052-.137.095-.215.127s-.156.049-.234.049-.156-.017-.234-.049-.149-.075-.215-.127l-.801-.82-.996.996 1.445 1.426c.117.13.176.28.176.449s-.059.319-.176.449c-.065.052-.137.095-.215.127s-.156.049-.234.049-.156-.017-.234-.049-.149-.075-.215-.127L9.18 10.287l-.996.996.82.801c.117.13.176.28.176.449s-.059.319-.176.449c-.065.052-.137.095-.215.127s-.156.049-.234.049-.156-.017-.234-.049-.149-.075-.215-.127l-.801-.82-.996.996 1.445 1.426c.117.13.176.28.176.449s-.059.319-.176.449c-.065.052-.137.095-.215.127s-.156.049-.234.049-.156-.017-.234-.049-.149-.075-.215-.127L5.43 14.037z"></path>
                                                            </svg>
                                                        </i>MESSAGE
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="product-page-info__field product-page-info__notes mb-20">
                                            <label for="notes">Notes</label>
                                            <textarea id="notes" name="properties[Notes]" placeholder="Write here your notes for the order" class="mb-0"></textarea>
                                        </div>
                                        <div data-js-footbar-product-limit="">
                                            <div class="d-flex">
                                                <div>
                                                    <div class="product-page-info__field product-page-info__quantity">
                                                        <label class="d-none">Quantity</label>
                                                        <div class="input-quantity input-quantity--type-04 d-flex align-items-center position-relative mr-10 js-product-quantity" data-js-quantity-connect="footbar">
                                                            <div class="d-flex flex-center position-absolute left-0 ml-10 cursor-pointer" onclick="count(this)" data-control="-">
                                                                <i>
                                                                    <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-theme-189" viewBox="0 0 24 24">
                                                                        <path d="M7.13 12.206a.598.598 0 0 1-.186-.439.6.6 0 0 1 .186-.439.605.605 0 0 1 .439-.186h8.75c.169 0 .315.063.439.186a.601.601 0 0 1 .186.439c0 .17-.062.316-.186.439a.601.601 0 0 1-.439.186h-8.75a.6.6 0 0 1-.439-.186z"></path>
                                                                    </svg>
                                                                </i>
                                                            </div>
                                                            <input type="number" class="mb-0 px-35 text-center" name="quantity" value="1" min="1">
                                                            <div class="d-flex flex-center position-absolute right-0 mr-10 cursor-pointer" onclick="count(this)" data-control="+">
                                                                <i>
                                                                    <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-theme-188" viewBox="0 0 24 24">
                                                                        <path d="M7.158 12.206a.598.598 0 0 1-.186-.439.6.6 0 0 1 .186-.439.602.602 0 0 1 .439-.186h3.75v-3.75a.6.6 0 0 1 .186-.439.602.602 0 0 1 .439-.186c.169 0 .315.063.439.186a.605.605 0 0 1 .186.439v3.75h3.75c.169 0 .315.063.439.186a.605.605 0 0 1 .186.439.6.6 0 0 1-.186.439.601.601 0 0 1-.439.186h-3.75v3.75a.6.6 0 0 1-.186.439.601.601 0 0 1-.439.186.597.597 0 0 1-.439-.186.598.598 0 0 1-.186-.439v-3.75h-3.75a.598.598 0 0 1-.439-.186z"></path>
                                                                    </svg>
                                                                </i>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="w-100">
                                                    <div class="product-page-info__button-add-to-cart mb-10">
                                                        <button type="submit" class="btn btn--full btn--status btn--secondary btn--animated js-product-button-add-to-cart" name="add" data-js-trigger-id="add-to-cart" data-js-button-add-to-cart-clone-id="footbar" data-js-product-button-add-to-cart="">
                                                            <span class="d-flex flex-center">
                                                                <i class="btn__icon mr-5 mb-4">
                                                                    <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-theme-109" viewBox="0 0 24 24">
                                                                        <path d="M19.884 21.897a.601.601 0 0 1-.439.186h-15a.6.6 0 0 1-.439-.186.601.601 0 0 1-.186-.439v-15a.6.6 0 0 1 .186-.439.601.601 0 0 1 .439-.186h3.75c0-1.028.368-1.911 1.104-2.646.735-.735 1.618-1.104 2.646-1.104s1.911.368 2.646 1.104c.735.736 1.104 1.618 1.104 2.646h3.75a.6.6 0 0 1 .439.186.601.601 0 0 1 .186.439v15a.604.604 0 0 1-.186.439zM18.819 7.083h-3.125v2.5a.598.598 0 0 1-.186.439c-.124.124-.271.186-.439.186s-.315-.062-.439-.186a.6.6 0 0 1-.186-.439v-2.5h-5v2.5a.598.598 0 0 1-.186.439c-.124.124-.271.186-.439.186s-.315-.062-.439-.186a.6.6 0 0 1-.186-.439v-2.5H5.069v13.75h13.75V7.083zm-8.642-3.018a2.409 2.409 0 0 0-.733 1.768h5c0-.69-.244-1.279-.732-1.768s-1.077-.732-1.768-.732-1.279.244-1.767.732z"></path>
                                                                    </svg>
                                                                </i>
                                                                <span class="btn__text">Add To Cart</span>
                                                            </span>
                                                            <span class="d-flex flex-center" data-button-content="added">
                                                                <i class="mr-5 mb-4">
                                                                    <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-theme-110" viewBox="0 0 24 24">
                                                                        <path d="M19.855 5.998a.601.601 0 0 0-.439-.186h-3.75c0-1.028-.368-1.911-1.104-2.646-.735-.735-1.618-1.104-2.646-1.104s-1.911.369-2.646 1.104c-.736.736-1.104 1.618-1.104 2.647h-3.75a.6.6 0 0 0-.439.186.598.598 0 0 0-.186.439v15a.6.6 0 0 0 .186.439c.124.123.27.186.439.186h15a.6.6 0 0 0 .439-.186.601.601 0 0 0 .186-.439v-15a.602.602 0 0 0-.186-.44zm-9.707-1.953c.488-.488 1.077-.732 1.768-.732s1.279.244 1.768.732.732 1.078.732 1.768h-5c0-.69.244-1.28.732-1.768zm6.926 7.194l-6.25 6.25a.877.877 0 0 1-.215.127.596.596 0 0 1-.468 0 .896.896 0 0 1-.215-.127l-2.5-2.5a.652.652 0 0 1-.176-.449c0-.169.059-.319.176-.449.13-.117.28-.176.449-.176s.319.059.449.176l2.051 2.07 5.801-5.82c.13-.117.28-.176.449-.176s.319.059.449.176c.117.13.176.28.176.449a.652.652 0 0 1-.176.449z"></path>
                                                                    </svg>
                                                                </i>Added </span>
                                                            <span class="d-flex flex-center" data-button-content="sold-out">Sold Out</span>
                                                            <span class="d-flex flex-center" data-button-content="pre-order">
                                                                <i class="btn__icon mr-5 mb-4">
                                                                    <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-theme-109" viewBox="0 0 24 24">
                                                                        <path d="M19.884 21.897a.601.601 0 0 1-.439.186h-15a.6.6 0 0 1-.439-.186.601.601 0 0 1-.186-.439v-15a.6.6 0 0 1 .186-.439.601.601 0 0 1 .439-.186h3.75c0-1.028.368-1.911 1.104-2.646.735-.735 1.618-1.104 2.646-1.104s1.911.368 2.646 1.104c.735.736 1.104 1.618 1.104 2.646h3.75a.6.6 0 0 1 .439.186.601.601 0 0 1 .186.439v15a.604.604 0 0 1-.186.439zM18.819 7.083h-3.125v2.5a.598.598 0 0 1-.186.439c-.124.124-.271.186-.439.186s-.315-.062-.439-.186a.6.6 0 0 1-.186-.439v-2.5h-5v2.5a.598.598 0 0 1-.186.439c-.124.124-.271.186-.439.186s-.315-.062-.439-.186a.6.6 0 0 1-.186-.439v-2.5H5.069v13.75h13.75V7.083zm-8.642-3.018a2.409 2.409 0 0 0-.733 1.768h5c0-.69-.244-1.279-.732-1.768s-1.077-.732-1.768-.732-1.279.244-1.767.732z"></path>
                                                                    </svg>
                                                                </i>
                                                                <span class="btn__text">Pre-Order</span>
                                                            </span>
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row justify-content-center justify-content-lg-start mt-15">
                                                <div class="col-auto">
                                                    <a href="/account" class="btn btn--text btn--status px-lg-0 js-store-lists-add-wishlist">
                                                        <span class="d-flex flex-center">
                                                            <i class="mr-5 mb-1">
                                                                <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-theme-180" viewBox="0 0 24 24">
                                                                    <path d="M21.486 6.599a5.661 5.661 0 0 0-1.25-1.865c-.56-.56-1.191-.979-1.895-1.26a5.77 5.77 0 0 0-4.326 0c-.71.28-1.345.7-1.904 1.26-.026.039-.056.075-.088.107l-.107.107-.107-.107a.706.706 0 0 1-.088-.107c-.56-.56-1.194-.979-1.904-1.26s-1.433-.42-2.168-.42-1.455.14-2.158.42-1.335.7-1.895 1.26c-.547.546-.964 1.168-1.25 1.865s-.43 1.429-.43 2.197.144 1.501.43 2.197.703 1.318 1.25 1.865l7.871 7.871c.003.003.007.004.011.006l.439.436.439-.437c.003-.002.007-.003.01-.006l7.871-7.871c.547-.547.964-1.169 1.25-1.865s.43-1.429.43-2.197-.145-1.5-.431-2.196zm-1.162 3.916a4.436 4.436 0 0 1-.967 1.445l-7.441 7.441-7.441-7.441c-.417-.417-.739-.898-.967-1.445s-.342-1.12-.342-1.719.114-1.172.342-1.719.55-1.035.967-1.465c.442-.43.94-.755 1.494-.977s1.116-.332 1.689-.332a4.496 4.496 0 0 1 3.467 1.641c.098.117.186.241.264.371.117.169.293.254.527.254s.41-.085.527-.254c.078-.13.166-.254.264-.371s.198-.228.303-.332a4.5 4.5 0 0 1 3.164-1.309c.573 0 1.136.11 1.689.332s1.052.547 1.494.977c.417.43.739.918.967 1.465s.342 1.12.342 1.719-.114 1.172-.342 1.719z"></path>
                                                                </svg>
                                                            </i>Add To Wishlist </span>
                                                        <span class="d-flex flex-center" data-button-content="added">
                                                            <i class="mr-5 mb-1">
                                                                <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-theme-181" viewBox="0 0 24 24">
                                                                    <path d="M21.861 6.568a5.661 5.661 0 0 0-1.25-1.865c-.56-.56-1.191-.979-1.895-1.26a5.77 5.77 0 0 0-4.326 0c-.71.28-1.345.7-1.904 1.26-.026.039-.056.075-.088.107l-.107.107-.107-.107a.706.706 0 0 1-.088-.107c-.56-.56-1.194-.979-1.904-1.26s-1.433-.42-2.168-.42-1.455.14-2.158.42-1.335.7-1.895 1.26c-.547.547-.964 1.169-1.25 1.865s-.43 1.429-.43 2.197.144 1.501.43 2.197.703 1.318 1.25 1.865l7.871 7.871c.003.003.007.004.011.006l.439.436.439-.437c.003-.002.007-.003.01-.006l7.871-7.871c.547-.547.964-1.169 1.25-1.865s.43-1.429.43-2.197-.145-1.499-.431-2.196z"></path>
                                                                </svg>
                                                            </i>Added To Wishlist </span>
                                                    </a>
                                                </div>
                                                <div class="col-auto">
                                                    <a href="/account" class="btn btn--text btn--status px-lg-0 js-store-lists-add-compare">
                                                        <span class="d-flex flex-center">
                                                            <i class="mr-5 mb-1">
                                                                <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-theme-039" viewBox="0 0 24 24">
                                                                    <path d="M23.408 19.784c-.01.007-.024.012-.035.02l-4.275-12.11.005-.014-.011-.004-.114-.323v-.061h-6.394v-4.75a.6.6 0 0 0-.186-.439c-.124-.124-.271-.186-.439-.186s-.315.062-.439.186a.601.601 0 0 0-.186.439v4.75H4.939v.062l-.114.322-.011.004.005.014L.544 19.803c-.01-.007-.025-.012-.035-.02l-.388 1.081c1.345.846 3.203 1.363 5.286 1.363 2.08 0 3.935-.515 5.279-1.359l-.019-.054.02-.007L6.326 8.458H17.59l-4.36 12.349.02.007-.019.054c1.344.844 3.199 1.359 5.279 1.359 2.083 0 3.941-.517 5.286-1.363l-.388-1.08zm-14.122.563c-1.085.486-2.434.781-3.88.781-1.423 0-2.749-.288-3.825-.761l.326-.924h7.06l.319.904zm-.71-2.013H2.299l3.138-8.888 3.139 8.888zm9.903-8.888l3.138 8.888h-6.276l3.138-8.888zm.031 11.682c-1.446 0-2.796-.295-3.88-.781l.319-.904h7.06l.326.924c-1.076.473-2.402.761-3.825.761z"></path>
                                                                </svg>
                                                            </i>Add To Compare </span>
                                                        <span class="d-flex flex-center" data-button-content="added">
                                                            <i class="mr-5 mb-1">
                                                                <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-theme-235" viewBox="0 0 24 24">
                                                                    <path d="M23.4 19.8l-2.3-6.6c1.7-1.3 2.8-3.4 2.8-5.8 0-4.1-3.3-7.4-7.4-7.4-4 0-7.3 3.2-7.4 7.2H4.9v.1l-.1.4L.5 19.8l-.4 1.1c1.3.8 3.2 1.4 5.3 1.4 2.1 0 3.9-.5 5.3-1.4v-.1L6.3 8.5h2.9c.4 3.2 3 5.8 6.2 6.3l-2.1 6.1v.1c1.3.8 3.2 1.4 5.3 1.4 2.1 0 3.9-.5 5.3-1.4l-.5-1.2zm-14.1.5c-1.1.5-2.4.8-3.9.8-1.4 0-2.7-.3-3.8-.8l.3-.9H9l.3.9zm-.7-2H2.3l3.1-8.9 3.2 8.9zm6.6-6.9c-.1.1-.1.1-.2.1h-.2-.2c-.1 0-.1-.1-.2-.1l-2.5-2.5c-.1-.1-.2-.3-.2-.4s.1-.3.2-.4c.1-.1.3-.2.4-.2s.3.1.4.2l2.1 2.1 5.8-5.8c.1-.3.3-.4.4-.4s.3.1.4.2c.1.1.2.3.2.4s0 .4-.1.5l-6.3 6.3zm1.4 3.4c1.3 0 2.4-.3 3.5-.9l1.6 4.4h-6.3l1.2-3.5zm1.9 6.3c-1.4 0-2.8-.3-3.9-.8l.3-.9H22l.3.9c-1 .5-2.4.8-3.8.8z"></path>
                                                                </svg>
                                                            </i>Added To Compare </span>
                                                    </a>
                                                </div>
                                            </div>
                                            <div class="product-page-info__dynamic-checkout mt-20 mb-20" data-js-product-button-dynamic-checkout="">
                                                <div class="dynamic-checkout js-dynamic-checkout">
                                                    <div class="dynamic-checkout__confirmation text-center text-lg-left">
                                                        <label class="input-checkbox position-relative d-inline-flex align-items-center mx-auto cursor-pointer">
                                                            <input type="checkbox" class="d-none" name="dynamic_checkout" data-js-dynamic-checkout-confirmation="">
                                                            <span class="position-relative d-block mr-10 border">
                                                                <i class="d-none">
                                                                    <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-theme-146" viewBox="0 0 24 24">
                                                                        <path d="M9.703 15.489l-2.5-2.5a.652.652 0 0 1-.176-.449c0-.169.059-.319.176-.449.13-.117.28-.176.449-.176s.319.059.449.176l2.051 2.07 5.801-5.82c.13-.117.28-.176.449-.176s.319.059.449.176c.117.13.176.28.176.449a.652.652 0 0 1-.176.449l-6.25 6.25a.877.877 0 0 1-.215.127.596.596 0 0 1-.468 0 .93.93 0 0 1-.215-.127z"></path>
                                                                    </svg>
                                                                </i>
                                                            </span>
                                                            <span>I agree with terms and conditions</span>
                                                        </label>
                                                    </div>
                                                    <div class="dynamic-checkout__button dynamic-checkout__button--styled mt-25 disabled" data-js-dynamic-checkout-button-wrapper="">
                                                        <div data-shopify="payment-button" data-has-selling-plan="false" data-has-fixed-selling-plan="false" class="shopify-payment-button">
                                                            <div>
                                                                <div>
                                                                    <div>
                                                                        <div class="shopify-cleanslate">
                                                                            <div id="shopify-svg-symbols" class="R9tDu8JrE_i1ctOEo0v_" aria-hidden="true">
                                                                                <svg xmlns="http://www.w3.org/2000/svg" xmlnsXlink="http://www.w3.org/1999/xlink" focusable="false">
                                                                                    <defs>
                                                                                        <symbol id="shopify-svg__warning" viewBox="0 0 16 14">
                                                                                            <path d="M5.925 2.344c1.146-1.889 3.002-1.893 4.149 0l4.994 8.235c1.146 1.889.288 3.421-1.916 3.421h-10.305c-2.204 0-3.063-1.529-1.916-3.421l4.994-8.235zm1.075 1.656v5h2v-5h-2zm0 6v2h2v-2h-2z"></path>
                                                                                        </symbol>
                                                                                        <symbol id="shopify-svg__loading" viewBox="0 0 32 32">
                                                                                            <path d="M32 16c0 8.837-7.163 16-16 16S0 24.837 0 16 7.163 0 16 0v2C8.268 2 2 8.268 2 16s6.268 14 14 14 14-6.268 14-14h2z"></path>
                                                                                        </symbol>
                                                                                        <symbol id="shopify-svg__error" viewBox="0 0 18 18">
                                                                                            <path d="M9 18c5 0 9-4 9-9s-4-9-9-9-9 4-9 9 4 9 9 9z" style="fill:#ff3e3e"></path>
                                                                                            <path d="M8 4h2v6H8z" style="fill:#fff"></path>
                                                                                            <rect x="7.8" y="12" width="2.5" height="2.5" rx="1.3" style="fill:#fff"></rect>
                                                                                        </symbol>
                                                                                        <symbol id="shopify-svg__close-circle" viewBox="0 0 16 16">
                                                                                            <circle cx="8" cy="8" r="8"></circle>
                                                                                            <path d="M10.5 5.5l-5 5M5.5 5.5l5 5" stroke="#FFF" stroke-width="1.5" stroke-linecap="square"></path>
                                                                                        </symbol>
                                                                                        <symbol id="shopify-svg__close" viewBox="0 0 20 20">
                                                                                            <path d="M17.1 4.3l-1.4-1.4-5.7 5.7-5.7-5.7-1.4 1.4 5.7 5.7-5.7 5.7 1.4 1.4 5.7-5.7 5.7 5.7 1.4-1.4-5.7-5.7z"></path>
                                                                                        </symbol>
                                                                                        <symbol id="shopify-svg__arrow-right" viewBox="0 0 16 16">
                                                                                            <path d="M16 8.1l-8.1 8.1-1.1-1.1L13 8.9H0V7.3h13L6.8 1.1 7.9 0 16 8.1z"></path>
                                                                                        </symbol>
                                                                                        <symbol id="shopify-svg__payments-google-pay-light" viewBox="0 0 41 17">
                                                                                            <path d="M19.526 2.635v4.083h2.518c.6 0 1.096-.202 1.488-.605.403-.402.605-.882.605-1.437 0-.544-.202-1.018-.605-1.422-.392-.413-.888-.62-1.488-.62h-2.518zm0 5.52v4.736h-1.504V1.198h3.99c1.013 0 1.873.337 2.582 1.012.72.675 1.08 1.497 1.08 2.466 0 .991-.36 1.819-1.08 2.482-.697.665-1.559.996-2.583.996h-2.485v.001zM27.194 10.442c0 .392.166.718.499.98.332.26.722.391 1.168.391.633 0 1.196-.234 1.692-.701.497-.469.744-1.019.744-1.65-.469-.37-1.123-.555-1.962-.555-.61 0-1.12.148-1.528.442-.409.294-.613.657-.613 1.093m1.946-5.815c1.112 0 1.989.297 2.633.89.642.594.964 1.408.964 2.442v4.932h-1.439v-1.11h-.065c-.622.914-1.45 1.372-2.486 1.372-.882 0-1.621-.262-2.215-.784-.594-.523-.891-1.176-.891-1.96 0-.828.313-1.486.94-1.976s1.463-.735 2.51-.735c.892 0 1.629.163 2.206.49v-.344c0-.522-.207-.966-.621-1.33a2.132 2.132 0 0 0-1.455-.547c-.84 0-1.504.353-1.995 1.062l-1.324-.834c.73-1.045 1.81-1.568 3.238-1.568M40.993 4.889l-5.02 11.53H34.42l1.864-4.034-3.302-7.496h1.635l2.387 5.749h.032l2.322-5.75z" style="fill:#fff"></path>
                                                                                            <path d="M13.448 7.134c0-.473-.04-.93-.116-1.366H6.988v2.588h3.634a3.11 3.11 0 0 1-1.344 2.042v1.68h2.169c1.27-1.17 2.001-2.9 2.001-4.944" style="fill:#4285f4"></path>
                                                                                            <path d="M6.988 13.7c1.816 0 3.344-.595 4.459-1.621l-2.169-1.681c-.603.406-1.38.643-2.29.643-1.754 0-3.244-1.182-3.776-2.774H.978v1.731a6.728 6.728 0 0 0 6.01 3.703" style="fill:#34a853"></path>
                                                                                            <path d="M3.212 8.267a4.034 4.034 0 0 1 0-2.572V3.964H.978A6.678 6.678 0 0 0 .261 6.98c0 1.085.26 2.11.717 3.017l2.234-1.731z" style="fill:#fbbc05"></path>
                                                                                            <path d="M6.988 2.921c.992 0 1.88.34 2.58 1.008v.001l1.92-1.918C10.324.928 8.804.262 6.989.262a6.728 6.728 0 0 0-6.01 3.702l2.234 1.731c.532-1.592 2.022-2.774 3.776-2.774" style="fill:#ea4335"></path>
                                                                                        </symbol>
                                                                                        <symbol id="shopify-svg__payments-google-pay-dark" viewBox="0 0 41 17">
                                                                                            <path d="M19.526 2.635v4.083h2.518c.6 0 1.096-.202 1.488-.605.403-.402.605-.882.605-1.437 0-.544-.202-1.018-.605-1.422-.392-.413-.888-.62-1.488-.62h-2.518zm0 5.52v4.736h-1.504V1.198h3.99c1.013 0 1.873.337 2.582 1.012.72.675 1.08 1.497 1.08 2.466 0 .991-.36 1.819-1.08 2.482-.697.665-1.559.996-2.583.996h-2.485v.001zM27.194 10.442c0 .392.166.718.499.98.332.26.722.391 1.168.391.633 0 1.196-.234 1.692-.701.497-.469.744-1.019.744-1.65-.469-.37-1.123-.555-1.962-.555-.61 0-1.12.148-1.528.442-.409.294-.613.657-.613 1.093m1.946-5.815c1.112 0 1.989.297 2.633.89.642.594.964 1.408.964 2.442v4.932h-1.439v-1.11h-.065c-.622.914-1.45 1.372-2.486 1.372-.882 0-1.621-.262-2.215-.784-.594-.523-.891-1.176-.891-1.96 0-.828.313-1.486.94-1.976s1.463-.735 2.51-.735c.892 0 1.629.163 2.206.49v-.344c0-.522-.207-.966-.621-1.33a2.132 2.132 0 0 0-1.455-.547c-.84 0-1.504.353-1.995 1.062l-1.324-.834c.73-1.045 1.81-1.568 3.238-1.568M40.993 4.889l-5.02 11.53H34.42l1.864-4.034-3.302-7.496h1.635l2.387 5.749h.032l2.322-5.75z" style="fill:rgba(0,0,0,.55)"></path>
                                                                                            <path d="M13.448 7.134c0-.473-.04-.93-.116-1.366H6.988v2.588h3.634a3.11 3.11 0 0 1-1.344 2.042v1.68h2.169c1.27-1.17 2.001-2.9 2.001-4.944" style="fill:#4285f4"></path>
                                                                                            <path d="M6.988 13.7c1.816 0 3.344-.595 4.459-1.621l-2.169-1.681c-.603.406-1.38.643-2.29.643-1.754 0-3.244-1.182-3.776-2.774H.978v1.731a6.728 6.728 0 0 0 6.01 3.703" style="fill:#34a853"></path>
                                                                                            <path d="M3.212 8.267a4.034 4.034 0 0 1 0-2.572V3.964H.978A6.678 6.678 0 0 0 .261 6.98c0 1.085.26 2.11.717 3.017l2.234-1.731z" style="fill:#fbbc05"></path>
                                                                                            <path d="M6.988 2.921c.992 0 1.88.34 2.58 1.008v.001l1.92-1.918C10.324.928 8.804.262 6.989.262a6.728 6.728 0 0 0-6.01 3.702l2.234 1.731c.532-1.592 2.022-2.774 3.776-2.774" style="fill:#ea4335"></path>
                                                                                        </symbol>
                                                                                        <symbol id="shopify-svg__payments-facebook-pay-dark" viewBox="0 0 300 50">
                                                                                            <path d="M277.374 25.35a330.858 330.858 0 0 1-5.496-14.28h6.355c1.122 3.701 2.393 7.365 3.739 11.066 1.383 3.7 2.803 7.364 4.336 10.953a271.222 271.222 0 0 0 7.29-22.019h6.131a183.26 183.26 0 0 1-2.692 7.963 500.958 500.958 0 0 1-3.402 9.159c-1.271 3.29-2.766 6.99-4.411 11.028-1.57 3.813-3.327 6.542-5.196 8.224-1.907 1.645-4.225 2.505-7.028 2.505a11.37 11.37 0 0 1-2.243-.225v-5.046c.374.037.673.074.897.112h.673c1.645 0 3.028-.449 4.149-1.309 1.122-.86 2.131-2.28 3.066-4.299-2.168-4.523-4.187-9.121-6.131-13.832h-.037Zm-9.795 13.421h-5.682v-3.888c-1.009 1.458-2.28 2.58-3.85 3.365-1.571.785-3.328 1.196-5.309 1.196-2.467 0-4.635-.636-6.505-1.87-1.906-1.233-3.364-2.99-4.448-5.158-1.084-2.206-1.608-4.71-1.608-7.514 0-2.804.561-5.346 1.645-7.552 1.084-2.168 2.617-3.887 4.561-5.121 1.944-1.234 4.187-1.87 6.692-1.87 1.906 0 3.588.375 5.121 1.122 1.495.748 2.766 1.795 3.738 3.14v-3.55h5.683v27.775l-.038-.075Zm-5.794-18.056c-.636-1.57-1.608-2.841-2.953-3.738-1.346-.898-2.879-1.384-4.636-1.384-2.467 0-4.449.823-5.944 2.505-1.458 1.682-2.205 3.925-2.205 6.767 0 2.84.71 5.121 2.13 6.803 1.421 1.682 3.327 2.505 5.795 2.505 1.794 0 3.402-.449 4.785-1.383 1.383-.935 2.43-2.168 3.028-3.739v-8.336ZM209 1.5h14.131c4.747 0 8.411 1.084 10.99 3.252 2.58 2.169 3.888 5.234 3.888 9.271 0 4.038-1.271 7.103-3.85 9.271-2.58 2.169-6.243 3.253-11.028 3.253h-8.038v12.261H209V1.5Zm13.645 19.551c3.14 0 5.42-.56 6.916-1.72 1.495-1.158 2.243-2.915 2.243-5.27 0-2.355-.748-4.225-2.243-5.346-1.496-1.122-3.813-1.72-6.916-1.72h-7.552v14.056h7.552ZM71.937 1.249h7.429l12.63 22.85 12.632-22.85h7.268v37.546h-6.06V10.019L94.758 29.946h-5.686L77.997 10.019v28.776h-6.06V1.249Zm58.947 13.999c-4.346 0-6.964 3.27-7.59 7.32h14.75c-.304-4.171-2.711-7.32-7.16-7.32Zm-13.598 9.628c0-8.522 5.508-14.725 13.703-14.725 8.061 0 12.875 6.124 12.875 15.18v1.665h-20.57c.73 4.405 3.653 7.374 8.367 7.374 3.761 0 6.112-1.147 8.34-3.246l3.22 3.943c-3.033 2.79-6.891 4.398-11.775 4.398-8.872 0-14.16-6.47-14.16-14.589Zm33.926-9.09h-5.579v-4.963h5.579V2.618h5.846v8.205h8.475v4.962h-8.475v12.577c0 4.294 1.373 5.82 4.747 5.82 1.541 0 2.424-.132 3.728-.35v4.909c-1.625.459-3.176.67-4.854.67-6.312 0-9.467-3.449-9.467-10.352V15.785v.001Zm38.941 4.825c-1.174-2.965-3.794-5.148-7.644-5.148-5.003 0-8.205 3.55-8.205 9.333 0 5.638 2.948 9.36 7.966 9.36 3.944 0 6.76-2.296 7.883-5.15V20.61v.001ZM196 38.795h-5.739v-3.916c-1.605 2.305-4.524 4.586-9.253 4.586-7.604 0-12.686-6.366-12.686-14.67 0-8.381 5.204-14.644 13.009-14.644 3.858 0 6.885 1.543 8.93 4.266v-3.594H196v27.972Z" fill="#000000"></path>
                                                                                            <path d="M6.422 26.042c0 2.27.498 4.013 1.15 5.068.853 1.38 2.127 1.966 3.425 1.966 1.675 0 3.207-.415 6.16-4.499 2.364-3.273 5.151-7.867 7.027-10.747l3.175-4.88c2.206-3.388 4.76-7.155 7.687-9.708C37.436 1.158 40.015 0 42.61 0c4.357 0 8.506 2.524 11.682 7.259 3.475 5.185 5.162 11.717 5.162 18.457 0 4.007-.79 6.95-2.133 9.277-1.299 2.25-3.83 4.497-8.086 4.497v-6.414c3.645 0 4.554-3.35 4.554-7.182 0-5.463-1.273-11.525-4.079-15.856-1.99-3.073-4.571-4.95-7.41-4.95-3.07 0-5.54 2.316-8.317 6.445-1.477 2.193-2.992 4.867-4.694 7.883l-1.873 3.318c-3.763 6.672-4.716 8.192-6.597 10.7-3.298 4.391-6.114 6.056-9.82 6.056-4.398 0-7.18-1.905-8.901-4.774C.69 32.377 0 29.309 0 25.813l6.422.23v-.001Z" fill="#0081FB"></path>
                                                                                            <path d="M5.063 7.712C8.007 3.174 12.256 0 17.13 0c2.823 0 5.628.835 8.558 3.227 3.204 2.616 6.62 6.922 10.881 14.02l1.528 2.547c3.688 6.145 5.787 9.306 7.015 10.797 1.58 1.914 2.686 2.485 4.123 2.485 3.645 0 4.554-3.35 4.554-7.182l5.665-.178c0 4.007-.79 6.95-2.133 9.277-1.299 2.25-3.83 4.496-8.086 4.496-2.647 0-4.991-.574-7.584-3.02-1.993-1.877-4.323-5.212-6.116-8.21l-5.332-8.907c-2.675-4.47-5.13-7.803-6.55-9.312-1.528-1.623-3.492-3.583-6.626-3.583-2.537 0-4.691 1.78-6.494 4.503L5.064 7.712h-.001Z" fill="url(#meta-pay-button__a)"></path>
                                                                                            <path d="M17.026 6.457c-2.537 0-4.691 1.78-6.494 4.503-2.55 3.848-4.11 9.579-4.11 15.082 0 2.27.498 4.013 1.15 5.068l-5.476 3.606C.691 32.377 0 29.309 0 25.813c0-6.358 1.745-12.984 5.063-18.101C8.007 3.174 12.256 0 17.13 0l-.103 6.457h-.001Z" fill="url(#meta-pay-button__b)"></path>
                                                                                            <defs>
                                                                                                <linearGradient id="meta-pay-button__a" x1="12.612" y1="24.19" x2="53.549" y2="26.257" gradientUnits="userSpaceOnUse">
                                                                                                    <stop stop-color="#0064E1"></stop>
                                                                                                    <stop offset=".4" stop-color="#0064E1"></stop>
                                                                                                    <stop offset=".83" stop-color="#0073EE"></stop>
                                                                                                    <stop offset="1" stop-color="#0082FB"></stop>
                                                                                                </linearGradient>
                                                                                                <linearGradient id="meta-pay-button__b" x1="9.304" y1="28.738" x2="9.304" y2="13.646" gradientUnits="userSpaceOnUse">
                                                                                                    <stop stop-color="#0082FB"></stop>
                                                                                                    <stop offset="1" stop-color="#0064E0"></stop>
                                                                                                </linearGradient>
                                                                                            </defs>
                                                                                        </symbol>
                                                                                        <symbol id="shopify-svg__payments-facebook-pay-light" viewBox="0 0 300 50">
                                                                                            <path d="M277.374 25.35a330.858 330.858 0 0 1-5.496-14.28h6.355c1.122 3.701 2.393 7.365 3.739 11.066 1.383 3.7 2.803 7.364 4.336 10.953a271.222 271.222 0 0 0 7.29-22.019h6.131a183.26 183.26 0 0 1-2.692 7.963 500.958 500.958 0 0 1-3.402 9.159c-1.271 3.29-2.766 6.99-4.411 11.028-1.57 3.813-3.327 6.542-5.196 8.224-1.907 1.645-4.225 2.505-7.028 2.505a11.37 11.37 0 0 1-2.243-.225v-5.046c.374.037.673.074.897.112h.673c1.645 0 3.028-.449 4.149-1.309 1.122-.86 2.131-2.28 3.066-4.299-2.168-4.523-4.187-9.121-6.131-13.832h-.037Zm-9.795 13.421h-5.682v-3.888c-1.009 1.458-2.28 2.58-3.85 3.365-1.571.785-3.328 1.196-5.309 1.196-2.467 0-4.635-.636-6.505-1.87-1.906-1.233-3.364-2.99-4.448-5.158-1.084-2.206-1.608-4.71-1.608-7.514 0-2.804.561-5.346 1.645-7.552 1.084-2.168 2.617-3.887 4.561-5.121 1.944-1.234 4.187-1.87 6.692-1.87 1.906 0 3.588.375 5.121 1.122 1.495.748 2.766 1.795 3.738 3.14v-3.55h5.683v27.775l-.038-.075Zm-5.794-18.056c-.636-1.57-1.608-2.841-2.953-3.738-1.346-.898-2.879-1.384-4.636-1.384-2.467 0-4.449.823-5.944 2.505-1.458 1.682-2.205 3.925-2.205 6.767 0 2.84.71 5.121 2.13 6.803 1.421 1.682 3.327 2.505 5.795 2.505 1.794 0 3.402-.449 4.785-1.383 1.383-.935 2.43-2.168 3.028-3.739v-8.336ZM209 1.5h14.131c4.747 0 8.411 1.084 10.99 3.252 2.58 2.169 3.888 5.234 3.888 9.271 0 4.038-1.271 7.103-3.85 9.271-2.58 2.169-6.243 3.253-11.028 3.253h-8.038v12.261H209V1.5Zm13.645 19.551c3.14 0 5.42-.56 6.916-1.72 1.495-1.158 2.243-2.915 2.243-5.27 0-2.355-.748-4.225-2.243-5.346-1.496-1.122-3.813-1.72-6.916-1.72h-7.552v14.056h7.552ZM71.937 1.249h7.429l12.63 22.85 12.632-22.85h7.268v37.546h-6.06V10.019L94.758 29.946h-5.686L77.997 10.019v28.776h-6.06V1.249Zm58.947 13.999c-4.346 0-6.964 3.27-7.59 7.32h14.75c-.304-4.171-2.711-7.32-7.16-7.32Zm-13.598 9.628c0-8.522 5.508-14.725 13.703-14.725 8.061 0 12.875 6.124 12.875 15.18v1.665h-20.57c.73 4.405 3.653 7.374 8.367 7.374 3.761 0 6.112-1.147 8.34-3.246l3.22 3.943c-3.033 2.79-6.891 4.398-11.775 4.398-8.872 0-14.16-6.47-14.16-14.589Zm33.926-9.09h-5.579v-4.963h5.579V2.618h5.846v8.205h8.475v4.962h-8.475v12.577c0 4.294 1.373 5.82 4.747 5.82 1.541 0 2.424-.132 3.728-.35v4.909c-1.625.459-3.176.67-4.854.67-6.312 0-9.467-3.449-9.467-10.352V15.785v.001Zm38.941 4.825c-1.174-2.965-3.794-5.148-7.644-5.148-5.003 0-8.205 3.55-8.205 9.333 0 5.638 2.948 9.36 7.966 9.36 3.944 0 6.76-2.296 7.883-5.15V20.61v.001ZM196 38.795h-5.739v-3.916c-1.605 2.305-4.524 4.586-9.253 4.586-7.604 0-12.686-6.366-12.686-14.67 0-8.381 5.204-14.644 13.009-14.644 3.858 0 6.885 1.543 8.93 4.266v-3.594H196v27.972Z" fill="#fff"></path>
                                                                                            <path d="M6.422 26.042c0 2.27.498 4.013 1.15 5.068.853 1.38 2.127 1.966 3.425 1.966 1.675 0 3.207-.415 6.16-4.499 2.364-3.273 5.151-7.867 7.027-10.747l3.175-4.88c2.206-3.388 4.76-7.155 7.687-9.708C37.436 1.158 40.015 0 42.61 0c4.357 0 8.506 2.524 11.682 7.259 3.475 5.185 5.162 11.717 5.162 18.457 0 4.007-.79 6.95-2.133 9.277-1.299 2.25-3.83 4.497-8.086 4.497v-6.414c3.645 0 4.554-3.35 4.554-7.182 0-5.463-1.273-11.525-4.079-15.856-1.99-3.073-4.571-4.95-7.41-4.95-3.07 0-5.54 2.316-8.317 6.445-1.477 2.193-2.992 4.867-4.694 7.883l-1.873 3.318c-3.763 6.672-4.716 8.192-6.597 10.7-3.298 4.391-6.114 6.056-9.82 6.056-4.398 0-7.18-1.905-8.901-4.774C.69 32.377 0 29.309 0 25.813l6.422.23v-.001Z" fill="#0081FB"></path>
                                                                                            <path d="M5.063 7.712C8.007 3.174 12.256 0 17.13 0c2.823 0 5.628.835 8.558 3.227 3.204 2.616 6.62 6.922 10.881 14.02l1.528 2.547c3.688 6.145 5.787 9.306 7.015 10.797 1.58 1.914 2.686 2.485 4.123 2.485 3.645 0 4.554-3.35 4.554-7.182l5.665-.178c0 4.007-.79 6.95-2.133 9.277-1.299 2.25-3.83 4.496-8.086 4.496-2.647 0-4.991-.574-7.584-3.02-1.993-1.877-4.323-5.212-6.116-8.21l-5.332-8.907c-2.675-4.47-5.13-7.803-6.55-9.312-1.528-1.623-3.492-3.583-6.626-3.583-2.537 0-4.691 1.78-6.494 4.503L5.064 7.712h-.001Z" fill="url(#meta-pay-button__a)"></path>
                                                                                            <path d="M17.026 6.457c-2.537 0-4.691 1.78-6.494 4.503-2.55 3.848-4.11 9.579-4.11 15.082 0 2.27.498 4.013 1.15 5.068l-5.476 3.606C.691 32.377 0 29.309 0 25.813c0-6.358 1.745-12.984 5.063-18.101C8.007 3.174 12.256 0 17.13 0l-.103 6.457h-.001Z" fill="url(#meta-pay-button__b)"></path>
                                                                                            <defs>
                                                                                                <linearGradient id="meta-pay-button__a" x1="12.612" y1="24.19" x2="53.549" y2="26.257" gradientUnits="userSpaceOnUse">
                                                                                                    <stop stop-color="#0064E1"></stop>
                                                                                                    <stop offset=".4" stop-color="#0064E1"></stop>
                                                                                                    <stop offset=".83" stop-color="#0073EE"></stop>
                                                                                                    <stop offset="1" stop-color="#0082FB"></stop>
                                                                                                </linearGradient>
                                                                                                <linearGradient id="meta-pay-button__b" x1="9.304" y1="28.738" x2="9.304" y2="13.646" gradientUnits="userSpaceOnUse">
                                                                                                    <stop stop-color="#0082FB"></stop>
                                                                                                    <stop offset="1" stop-color="#0064E0"></stop>
                                                                                                </linearGradient>
                                                                                            </defs>
                                                                                        </symbol>
                                                                                        <symbol id="shopify-svg__payments-amazon-pay" viewBox="0 0 102 20">
                                                                                            <path d="M75.19 1.786c-.994 0-1.933.326-2.815.98v5.94c.896.683 1.82 1.023 2.774 1.023 1.932 0 2.899-1.32 2.899-3.96 0-2.655-.953-3.983-2.858-3.983zm-2.962-.277A5.885 5.885 0 0 1 73.93.444a4.926 4.926 0 0 1 1.85-.362c.672 0 1.282.127 1.827.383a3.763 3.763 0 0 1 1.387 1.108c.378.482.669 1.068.872 1.757.203.689.305 1.466.305 2.332 0 .88-.109 1.675-.326 2.385-.217.71-.522 1.314-.914 1.81a4.137 4.137 0 0 1-1.429 1.16 4.165 4.165 0 0 1-1.87.416c-1.26 0-2.346-.419-3.256-1.256v4.983c0 .284-.14.426-.42.426h-1.24c-.28 0-.42-.142-.42-.426V.827c0-.284.14-.426.42-.426h.925c.28 0 .441.142.483.426l.105.682zm13.194 8.37a4.21 4.21 0 0 0 1.45-.277 5.463 5.463 0 0 0 1.45-.81V6.62c-.35-.085-.719-.152-1.104-.202a8.8 8.8 0 0 0-1.124-.075c-1.583 0-2.374.617-2.374 1.853 0 .54.147.955.441 1.246.294.29.715.437 1.261.437zm-2.458-7.625l-.158.053a.561.561 0 0 1-.179.033c-.182 0-.273-.128-.273-.384V1.38c0-.199.028-.337.084-.415.056-.078.169-.153.337-.224.448-.199 1-.359 1.66-.48.657-.12 1.316-.18 1.974-.18 1.33 0 2.311.277 2.942.83.63.554.945 1.413.945 2.577v7.284c0 .284-.14.426-.42.426h-.903c-.267 0-.42-.135-.463-.405l-.105-.702a5.74 5.74 0 0 1-1.67 1.022 4.908 4.908 0 0 1-1.817.362c-1.009 0-1.807-.288-2.395-.863-.589-.575-.883-1.345-.883-2.31 0-1.037.364-1.864 1.092-2.481.73-.618 1.71-.927 2.942-.927.784 0 1.667.12 2.647.362V3.852c0-.767-.168-1.307-.504-1.619-.336-.313-.925-.469-1.764-.469-.982 0-2.01.163-3.09.49zm14.16 10.84c-.379.98-.816 1.683-1.314 2.109-.496.426-1.144.639-1.943.639-.448 0-.847-.05-1.197-.15a.606.606 0 0 1-.336-.202c-.07-.093-.105-.237-.105-.437V14.5c0-.27.105-.405.315-.405.07 0 .175.014.315.043.14.028.33.043.567.043.532 0 .946-.128 1.24-.384.294-.255.56-.724.798-1.406l.4-1.086-4.056-10.137c-.098-.241-.146-.411-.146-.511 0-.17.097-.256.294-.256h1.26c.224 0 .378.036.463.106.083.072.167.228.251.47l2.942 8.263L99.708.976c.084-.24.168-.397.252-.469.084-.07.238-.106.462-.106h1.177c.196 0 .294.086.294.256 0 .1-.05.27-.147.51l-4.622 11.927M40.15 15.47c-3.761 2.814-9.216 4.31-13.912 4.31-6.583 0-12.51-2.466-16.996-6.572-.352-.322-.038-.763.385-.513 4.84 2.855 10.825 4.574 17.006 4.574 4.17 0 8.753-.877 12.971-2.691.636-.273 1.17.425.547.891" style="fill:#333e48"></path>
                                                                                            <path d="M41.717 13.657c-.482-.624-3.181-.296-4.394-.148-.368.044-.425-.281-.093-.517 2.153-1.533 5.682-1.09 6.092-.577.413.518-.108 4.104-2.127 5.816-.31.263-.605.122-.468-.225.455-1.15 1.471-3.724.99-4.349M37.429 2.06V.57A.365.365 0 0 1 37.8.193l6.59-.001c.21 0 .38.155.38.376v1.278c-.003.214-.18.494-.496.938L40.86 7.722c1.267-.03 2.607.163 3.757.818.26.148.33.367.35.582v1.59c0 .218-.237.472-.485.34-2.028-1.077-4.718-1.194-6.96.013-.23.124-.47-.126-.47-.345V9.209c0-.242.005-.656.246-1.024l3.953-5.75H37.81a.369.369 0 0 1-.38-.375M13.4 11.365h-2.005a.38.38 0 0 1-.358-.343L11.038.595a.38.38 0 0 1 .387-.375h1.866a.38.38 0 0 1 .365.35v1.36h.037C14.18.615 15.096 0 16.331 0c1.253 0 2.039.614 2.6 1.93C19.418.615 20.521 0 21.7 0c.842 0 1.758.351 2.32 1.141.635.878.505 2.15.505 3.27l-.002 6.58a.38.38 0 0 1-.387.374h-2.001a.378.378 0 0 1-.36-.374V5.463c0-.438.037-1.535-.056-1.952-.15-.703-.6-.9-1.179-.9-.486 0-.991.33-1.197.855-.206.527-.188 1.405-.188 1.997v5.527a.38.38 0 0 1-.386.375h-2.002a.379.379 0 0 1-.36-.374l-.001-5.528c0-1.163.186-2.874-1.235-2.874-1.44 0-1.384 1.668-1.384 2.874l-.001 5.527a.38.38 0 0 1-.387.375m37.059-9.236c-1.478 0-1.571 2.04-1.571 3.312 0 1.273-.02 3.993 1.552 3.993 1.554 0 1.628-2.194 1.628-3.532 0-.877-.038-1.93-.3-2.764-.224-.724-.673-1.01-1.31-1.01zM50.439 0c2.975 0 4.584 2.59 4.584 5.88 0 3.181-1.777 5.705-4.584 5.705-2.918 0-4.508-2.59-4.508-5.814C45.93 2.523 47.539 0 50.439 0zm8.441 11.365h-1.997a.379.379 0 0 1-.36-.374L56.52.561a.381.381 0 0 1 .386-.34L58.764.22c.175.009.32.13.356.291v1.595h.038C59.72.68 60.505 0 61.89 0c.898 0 1.778.329 2.339 1.229.524.834.524 2.237.524 3.247v6.561a.382.382 0 0 1-.385.328H62.36a.38.38 0 0 1-.357-.328V5.376c0-1.141.13-2.809-1.253-2.809-.487 0-.936.33-1.16.834-.281.636-.319 1.272-.319 1.975v5.614a.386.386 0 0 1-.39.375m-24.684.075a.41.41 0 0 1-.473.047c-.665-.56-.785-.82-1.149-1.354-1.1 1.136-1.879 1.477-3.304 1.477-1.687 0-3-1.055-3-3.166 0-1.65.882-2.77 2.138-3.32 1.087-.484 2.606-.572 3.769-.704v-.264c0-.484.037-1.055-.245-1.473-.243-.374-.712-.528-1.124-.528-.765 0-1.444.397-1.611 1.22-.035.183-.167.364-.348.374l-1.943-.214c-.164-.037-.346-.17-.299-.425C27.055.721 29.183 0 31.09 0c.975 0 2.25.263 3.018 1.011.975.924.881 2.155.881 3.497v3.165c0 .952.39 1.37.757 1.882.128.185.156.405-.007.54-.409.348-1.136.988-1.537 1.35l-.005-.005zm-2.02-4.953v-.44c-1.45 0-2.98.314-2.98 2.045 0 .88.45 1.473 1.218 1.473.562 0 1.069-.352 1.387-.923.394-.704.376-1.363.376-2.155zM7.926 11.44a.41.41 0 0 1-.473.047c-.667-.56-.786-.82-1.15-1.354C5.204 11.27 4.425 11.61 3 11.61c-1.688 0-3-1.055-3-3.166 0-1.65.88-2.77 2.137-3.32 1.087-.484 2.606-.572 3.768-.704v-.264c0-.484.038-1.055-.243-1.473-.244-.374-.713-.528-1.125-.528-.764 0-1.444.397-1.61 1.22-.036.183-.168.364-.35.374l-1.94-.214c-.165-.037-.347-.17-.3-.425C.783.721 2.911 0 4.818 0c.975 0 2.25.263 3.018 1.011.975.924.882 2.155.882 3.497v3.165c0 .952.39 1.37.756 1.882.128.185.157.405-.006.54a78.47 78.47 0 0 0-1.537 1.35l-.005-.005zm-2.02-4.953v-.44c-1.45 0-2.982.314-2.982 2.045 0 .88.45 1.473 1.219 1.473.562 0 1.069-.352 1.387-.923.394-.704.375-1.363.375-2.155z" style="fill:#333e48"></path>
                                                                                        </symbol>
                                                                                        <symbol id="shopify-svg__payments-apple-pay-dark" viewBox="0 0 43 19">
                                                                                            <path d="M6.948 1.409C7.934.147 9.305.147 9.305.147s.193 1.18-.771 2.316c-1.05 1.2-2.228.993-2.228.993s-.236-.93.642-2.047zM3.82 3.663c-1.735 0-3.6 1.51-3.6 4.363 0 2.916 2.186 6.555 3.943 6.555.6 0 1.543-.6 2.485-.6.922 0 1.607.559 2.464.559 1.907 0 3.322-3.826 3.322-3.826s-2.015-.744-2.015-2.936c0-1.944 1.629-2.73 1.629-2.73s-.836-1.447-2.936-1.447c-1.22 0-2.164.661-2.656.661-.622.021-1.5-.6-2.636-.6zM19.64 1.426c2.453 0 4.188 1.788 4.188 4.396 0 2.608-1.755 4.417-4.248 4.417h-2.932v4.564h-1.974V1.426h4.966zm-2.992 7.067h2.473c1.695 0 2.693-.967 2.693-2.65 0-1.683-.978-2.671-2.693-2.671h-2.473v5.321zm7.559 3.429c0-1.767 1.296-2.777 3.65-2.945l2.572-.147v-.78c0-1.156-.738-1.787-1.994-1.787-1.037 0-1.795.568-1.955 1.43h-1.775c.06-1.788 1.656-3.092 3.79-3.092 2.333 0 3.829 1.304 3.829 3.281v6.9h-1.815v-1.684h-.04c-.519 1.094-1.715 1.788-3.012 1.788-1.934.021-3.25-1.178-3.25-2.965zm6.222-.905v-.778l-2.313.168c-1.297.084-1.975.59-1.975 1.494 0 .862.718 1.409 1.815 1.409 1.396-.021 2.473-.968 2.473-2.293zm3.969 7.383v-1.64c.14.041.438.041.598.041.897 0 1.416-.4 1.735-1.472l.14-.526L33.4 4.707h2.054l2.453 8.224h.04L40.4 4.707h1.994l-3.57 10.538c-.818 2.419-1.715 3.197-3.67 3.197-.14.02-.598-.021-.757-.042z" style="fill:#000"></path>
                                                                                        </symbol>
                                                                                        <symbol id="shopify-svg__payments-apple-pay-light" viewBox="0 0 43 19">
                                                                                            <path d="M6.948 1.409C7.934.147 9.305.147 9.305.147s.193 1.18-.771 2.316c-1.05 1.2-2.228.993-2.228.993s-.236-.93.642-2.047zM3.82 3.663c-1.735 0-3.6 1.51-3.6 4.363 0 2.916 2.186 6.555 3.943 6.555.6 0 1.543-.6 2.485-.6.922 0 1.607.559 2.464.559 1.907 0 3.322-3.826 3.322-3.826s-2.015-.744-2.015-2.936c0-1.944 1.629-2.73 1.629-2.73s-.836-1.447-2.936-1.447c-1.22 0-2.164.661-2.656.661-.622.021-1.5-.6-2.636-.6zM19.64 1.426c2.453 0 4.188 1.788 4.188 4.396 0 2.608-1.755 4.417-4.248 4.417h-2.932v4.564h-1.974V1.426h4.966zm-2.992 7.067h2.473c1.695 0 2.693-.967 2.693-2.65 0-1.683-.978-2.671-2.693-2.671h-2.473v5.321zm7.559 3.429c0-1.767 1.296-2.777 3.65-2.945l2.572-.147v-.78c0-1.156-.738-1.787-1.994-1.787-1.037 0-1.795.568-1.955 1.43h-1.775c.06-1.788 1.656-3.092 3.79-3.092 2.333 0 3.829 1.304 3.829 3.281v6.9h-1.815v-1.684h-.04c-.519 1.094-1.715 1.788-3.012 1.788-1.934.021-3.25-1.178-3.25-2.965zm6.222-.905v-.778l-2.313.168c-1.297.084-1.975.59-1.975 1.494 0 .862.718 1.409 1.815 1.409 1.396-.021 2.473-.968 2.473-2.293zm3.969 7.383v-1.64c.14.041.438.041.598.041.897 0 1.416-.4 1.735-1.472l.14-.526L33.4 4.707h2.054l2.453 8.224h.04L40.4 4.707h1.994l-3.57 10.538c-.818 2.419-1.715 3.197-3.67 3.197-.14.02-.598-.021-.757-.042z" style="fill:#fff"></path>
                                                                                        </symbol>
                                                                                        <symbol id="shopify-svg__payments-paypal" viewBox="0 0 67 19">
                                                                                            <path d="M8.44.57H3.29a.718.718 0 0 0-.707.61L.502 14.517c-.041.263.16.5.425.5h2.458a.718.718 0 0 0 .707-.61l.561-3.597a.717.717 0 0 1 .706-.611h1.63c3.391 0 5.349-1.658 5.86-4.944.23-1.437.01-2.566-.657-3.357C11.461 1.029 10.162.57 8.44.57zm.594 4.87C8.752 7.308 7.34 7.308 5.976 7.308h-.777l.545-3.485a.43.43 0 0 1 .424-.366h.356c.93 0 1.807 0 2.26.535.27.32.353.794.25 1.45zm14.796-.06h-2.466a.43.43 0 0 0-.424.367l-.109.696-.172-.252c-.534-.783-1.724-1.044-2.912-1.044-2.725 0-5.052 2.084-5.505 5.008-.235 1.46.1 2.854.919 3.827.75.894 1.826 1.267 3.105 1.267 2.195 0 3.412-1.426 3.412-1.426l-.11.692a.432.432 0 0 0 .424.502h2.22a.718.718 0 0 0 .707-.61l1.333-8.526a.43.43 0 0 0-.423-.5zm-3.437 4.849c-.238 1.422-1.356 2.378-2.782 2.378-.716 0-1.288-.232-1.655-.672-.365-.436-.503-1.058-.387-1.75.222-1.41 1.359-2.397 2.763-2.397.7 0 1.269.235 1.644.678.375.448.524 1.073.417 1.763zM36.96 5.38h-2.478a.716.716 0 0 0-.592.318l-3.417 5.085-1.448-4.887a.719.719 0 0 0-.687-.515h-2.435a.433.433 0 0 0-.407.573l2.73 8.09-2.567 3.66a.434.434 0 0 0 .35.684h2.475a.712.712 0 0 0 .588-.31l8.24-12.016a.434.434 0 0 0-.352-.681z" style="fill:#253b80"></path>
                                                                                            <path d="M45.163.57h-5.15a.717.717 0 0 0-.706.61l-2.082 13.337a.43.43 0 0 0 .423.5h2.642a.502.502 0 0 0 .494-.427l.591-3.78a.717.717 0 0 1 .706-.611h1.63c3.392 0 5.348-1.658 5.86-4.944.231-1.437.009-2.566-.657-3.357C48.183 1.029 46.886.57 45.163.57zm.593 4.87c-.28 1.867-1.692 1.867-3.057 1.867h-.777l.546-3.485a.429.429 0 0 1 .423-.366h.356c.93 0 1.807 0 2.26.535.27.32.353.794.25 1.45zm14.795-.06h-2.464a.428.428 0 0 0-.423.367l-.109.696-.173-.252c-.534-.783-1.723-1.044-2.911-1.044-2.724 0-5.05 2.084-5.504 5.008-.235 1.46.099 2.854.918 3.827.753.894 1.826 1.267 3.105 1.267 2.195 0 3.413-1.426 3.413-1.426l-.11.692a.432.432 0 0 0 .424.502h2.22a.717.717 0 0 0 .707-.61l1.333-8.526a.433.433 0 0 0-.426-.5zm-3.436 4.849c-.237 1.422-1.356 2.378-2.782 2.378-.714 0-1.288-.232-1.655-.672-.365-.436-.502-1.058-.387-1.75.223-1.41 1.359-2.397 2.763-2.397.7 0 1.269.235 1.644.678.377.448.526 1.073.417 1.763zM63.458.935l-2.113 13.582a.43.43 0 0 0 .423.5h2.124a.716.716 0 0 0 .707-.61L66.683 1.07a.432.432 0 0 0-.423-.5h-2.379c-.21 0-.39.156-.423.366z" style="fill:#179bd7"></path>
                                                                                        </symbol>
                                                                                        <symbol id="shopify-svg__payments-shop-pay" viewBox="134 256 410 1">
                                                                                            <path d="M241.22,242.74c-3.07-6.44-8.89-10.6-17.66-10.6a17.58,17.58,0,0,0-13.81,7.1l-.32.39V214.39a.55.55,0,0,0-.55-.55h-12.4a.55.55,0,0,0-.54.55v72.4a.54.54,0,0,0,.54.54h13.28a.55.55,0,0,0,.55-.54V255.92c0-6,4-10.25,10.4-10.25,7,0,8.77,5.76,8.77,11.63v29.49a.54.54,0,0,0,.54.54h13.25a.55.55,0,0,0,.55-.54V255.54c0-1.07,0-2.12-.14-3.14A27.63,27.63,0,0,0,241.22,242.74Z" style="fill:#fff"></path>
                                                                                            <path d="M174.91,253.47s-6.76-1.59-9.25-2.23-6.84-2-6.84-5.29,3.51-4.34,7.07-4.34,7.52.86,7.83,4.81a.57.57,0,0,0,.57.52l13.09-.05a.56.56,0,0,0,.56-.6c-.81-12.64-11.9-17.16-22.13-17.16-12.13,0-21,8-21,16.82,0,6.44,1.82,12.48,16.13,16.68,2.51.73,5.92,1.68,8.9,2.51,3.58,1,5.51,2.51,5.51,4.89,0,2.76-4,4.68-7.93,4.68-5.69,0-9.73-2.11-10.06-5.9a.57.57,0,0,0-.57-.5l-13.06.06a.57.57,0,0,0-.57.59c.6,11.93,12.12,18.36,22.86,18.36,16,0,23.23-9,23.23-17.43C189.27,265.93,188.36,256.91,174.91,253.47Z" style="fill:#fff"></path>
                                                                                            <path d="M343.31,232.12c-6.65,0-12.22,3.68-15.81,8.12v-7.6a.54.54,0,0,0-.53-.54H314.55a.54.54,0,0,0-.54.54v71a.54.54,0,0,0,.54.53h13.29a.53.53,0,0,0,.53-.53V280.3h.2c2.11,3.22,7.88,7.08,15.42,7.08,14.18,0,26-11.76,26-27.65C370,244.48,358.24,232.12,343.31,232.12Zm-1.23,41.73a14.09,14.09,0,1,1,13.74-14.12A13.9,13.9,0,0,1,342.08,273.85Z" style="fill:#fff"></path>
                                                                                            <path d="M274.68,229c-12.39,0-18.57,4.21-23.53,7.58l-.15.1a1.23,1.23,0,0,0-.37,1.63l4.9,8.44a1.24,1.24,0,0,0,.87.6,1.21,1.21,0,0,0,1-.27l.39-.32c2.55-2.14,6.64-5,16.54-5.78,5.51-.44,10.27,1,13.78,4.28,3.86,3.56,6.17,9.31,6.17,15.38,0,11.17-6.58,18.19-17.15,18.33-8.71-.05-14.56-4.59-14.56-11.3,0-3.56,1.61-5.88,4.75-8.2a1.22,1.22,0,0,0,.37-1.56l-4.4-8.32a1.29,1.29,0,0,0-.77-.62,1.24,1.24,0,0,0-1,.13c-4.94,2.93-11,8.29-10.67,18.59.4,13.11,11.3,23.12,25.47,23.53l.71,0H278c16.84-.55,29-13.05,29-30C307,245.66,295.66,229,274.68,229Z" style="fill:#fff"></path>
                                                                                            <path d="M342.08,245.68a14.09,14.09,0,1,0,13.74,14.05A13.84,13.84,0,0,0,342.08,245.68Z" style="fill:#5a31f4"></path>
                                                                                            <rect x="383.23" y="214.02" width="141.73" height="90.42" rx="14.17" style="fill:#fff"></rect>
                                                                                            <path d="M439.07,246.62c0,9.67-6.77,16.57-16.23,16.57h-8.92a.75.75,0,0,0-.75.75v12.7a.75.75,0,0,1-.75.75h-6.28a.76.76,0,0,1-.75-.75V230.81a.75.75,0,0,1,.75-.75h16.7C432.3,230.06,439.07,237,439.07,246.62Zm-7.78,0c0-5.54-3.79-9.6-8.93-9.6h-8.44a.76.76,0,0,0-.75.75v17.71a.75.75,0,0,0,.75.74h8.44C427.5,256.22,431.29,252.17,431.29,246.62Z" style="fill:#5a31f4"></path>
                                                                                            <path d="M440.92,268.6a8.91,8.91,0,0,1,3.72-7.64c2.44-1.83,6.22-2.78,11.83-3l5.95-.2V256c0-3.51-2.36-5-6.15-5s-6.18,1.34-6.74,3.53a.72.72,0,0,1-.72.52h-5.87a.74.74,0,0,1-.75-.85c.88-5.2,5.18-9.15,14.35-9.15,9.74,0,13.25,4.53,13.25,13.18v18.38a.75.75,0,0,1-.75.76h-5.93a.75.75,0,0,1-.75-.76v-1.37a.56.56,0,0,0-1-.39c-1.77,1.93-4.65,3.33-9.24,3.33C445.39,278.2,440.92,274.68,440.92,268.6Zm21.5-4v-1.42l-7.7.4c-4.06.21-6.43,1.9-6.43,4.74,0,2.57,2.17,4,5.95,4C459.38,272.32,462.42,269.54,462.42,264.61Z" style="fill:#5a31f4"></path>
                                                                                            <path d="M475.75,291.27v-5.35a.76.76,0,0,1,.9-.75,14.84,14.84,0,0,0,2.75.26,7.11,7.11,0,0,0,7.17-5.07l.39-1.23a.74.74,0,0,0,0-.51l-12.34-31.7a.76.76,0,0,1,.71-1h6a.77.77,0,0,1,.71.49l8.38,22.36a.77.77,0,0,0,1.44,0l7.27-22.3a.75.75,0,0,1,.72-.52H506a.76.76,0,0,1,.71,1l-13.2,35.21c-3,8.18-8.25,10.28-14,10.28a11.17,11.17,0,0,1-3.21-.39A.77.77,0,0,1,475.75,291.27Z" style="fill:#5a31f4"></path>
                                                                                        </symbol>
                                                                                    </defs>
                                                                                </svg>
                                                                            </div>
                                                                        </div>
                                                                        <div data-testid="upstream-button" class="shopify-payment-button__button shopify-payment-button__button--branded BUz42FHpSPncCPJ4Pr_f">
                                                                            <div class="shopify-cleanslate">
                                                                                <div role="button" tabindex="0" class="kqsiVA9Jf8LJAbxw8Bau h7OYsWHrW5495r9beh2n jjzYeefyWpPZLH9pIgyw DnvZqPMEvBFbBre5UuP9" data-testid="ShopifyPay-button">
                                                                                    <span class="Xrk_DudB6JJ3t2Kh2_cU">Buy now with ShopPay</span>
                                                                                    <span aria-hidden="true">Buy with</span>
                                                                                    <span class="ElVMgDjOgshGFMIvg3se">
                                                                                        <svg preserveAspectRatio="xMidYMid" class="qZgSr5RiiBCTAMfQYsty" style="height:24px;width:82px">
                                                                                            <use xlink:href="#shopify-svg__payments-shop-pay"></use>
                                                                                        </svg>
                                                                                    </span>
                                                                                    <span aria-hidden="true"></span>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <button class="shopify-payment-button__more-options BUz42FHpSPncCPJ4Pr_f" type="button" data-testid="sheet-open-button">More payment options</button>
                                                                        <div>
                                                                            <div></div>
                                                                        </div>
                                                                        <div></div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="product-page-info__payments product-page-info__field mt-20 mb-10">
                                            <label class="mb-6">Guaranteed safe checkout:</label>
                                            <div class="payments overflow-hidden">
                                                <div class="row align-items-start justify-content-center justify-content-lg-start">
                                                    <div class="col-auto px-5 pb-10">
                                                        <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon--wide icon-payment-american-express" viewBox="0 0 62 40">
                                                            <path d="M0 4a4 4 0 0 1 4-4h54a4 4 0 0 1 4 4v32a4 4 0 0 1-4 4H4a4 4 0 0 1-4-4V4z" fill="#F5F5F5"></path>
                                                            <path d="M9.457 15.457h1.816l-.908-2.311-.908 2.311zM31.99 13.476c-.165-.082-.412-.082-.66-.082h-1.65v1.32h1.65c.248 0 .495 0 .66-.082.165-.083.248-.33.248-.578.083-.33-.083-.495-.248-.578z" fill="#016FD0"></path>
                                                            <path d="M49.654 11v.99l-.495-.99h-3.88v.99l-.495-.99h-5.282c-.908 0-1.651.165-2.312.495V11h-3.714v.495c-.413-.33-.908-.495-1.568-.495H18.619l-.908 2.063L16.803 11h-4.21v.99l-.495-.99H8.55L6.9 14.88 5 19.17h4.21l.495-1.32h1.155l.496 1.32h4.787v-.99l.413.99h2.393l.413-.99v.99h11.473v-2.146H31c.165 0 .165 0 .165.248v1.816h5.943v-.495c.495.247 1.238.495 2.229.495h2.476l.495-1.32h1.156l.495 1.32h4.787V17.85l.743 1.238h3.88V11h-3.715zm-27.899 6.933h-1.403v-4.54l-1.98 4.54h-1.239l-1.98-4.54v4.54h-2.807l-.578-1.238H8.962l-.495 1.32H6.898l2.477-5.86h2.063l2.311 5.53v-5.53h2.229l1.816 3.963 1.65-3.962h2.312v5.777zm5.613-4.54H24.15v1.074h3.137v1.155h-3.137v1.156h3.22v1.238h-4.623v-5.86h4.622v1.238zm6.19 2.394c.166.33.248.578.248 1.073v1.156h-1.403v-.743c0-.33 0-.825-.247-1.155-.248-.248-.496-.248-.99-.248h-1.487v2.146h-1.403v-5.86h3.137c.743 0 1.238 0 1.65.247.413.248.66.66.66 1.32 0 .909-.577 1.404-.99 1.57.413.082.66.33.826.494zm2.477 2.146h-1.403v-5.86h1.403v5.86zm16.26 0h-1.98l-2.642-4.374v4.374h-2.806l-.496-1.238h-2.889l-.495 1.32H39.42c-.66 0-1.486-.164-1.98-.66-.496-.495-.744-1.155-.744-2.228 0-.825.165-1.65.743-2.311.413-.495 1.156-.66 2.064-.66h1.32v1.238h-1.32c-.496 0-.743.082-1.073.33-.248.247-.413.743-.413 1.32 0 .66.082 1.073.413 1.404.247.247.577.33.99.33h.578l1.898-4.54h2.064l2.31 5.53v-5.53h2.064l2.394 4.044v-4.044h1.403v5.695h.165z" fill="#016FD0"></path>
                                                            <path d="M41.978 15.457h1.898l-.907-2.311-.991 2.311zM27.946 27.343v-4.705L25.8 24.95l2.146 2.394zM19.114 23.216v1.073h3.054v1.155h-3.054v1.239h3.384l1.569-1.734-1.486-1.733h-3.467zM31.082 23.216H29.35V24.7h1.816c.495 0 .825-.247.825-.742-.082-.496-.412-.743-.907-.743z" fill="#016FD0"></path>
                                                            <path d="M56.587 24.62v-3.715h-3.466c-.743 0-1.32.165-1.734.495v-.495h-3.796c-.578 0-1.321.165-1.651.495v-.495h-6.686v.495c-.495-.413-1.403-.495-1.816-.495h-4.457v.495c-.413-.413-1.403-.495-1.898-.495H26.13l-1.155 1.238-1.073-1.238h-7.429v8.089h7.264l1.155-1.238 1.073 1.238h4.457v-1.899H31c.578 0 1.32 0 1.898-.247v2.228h3.715V26.93h.165c.248 0 .248 0 .248.248v1.898H48.25c.743 0 1.486-.165 1.898-.495v.495h3.55c.742 0 1.485-.082 1.98-.413.826-.495 1.321-1.403 1.321-2.476 0-.578-.165-1.155-.413-1.568zM31 25.94h-1.65v1.98h-2.642l-1.65-1.898-1.734 1.899h-5.448v-5.86h5.53l1.651 1.898 1.734-1.899h4.374c1.073 0 2.311.33 2.311 1.899-.082 1.65-1.238 1.98-2.476 1.98zm8.254-.33c.165.247.248.577.248 1.073v1.155h-1.404v-.743c0-.33 0-.908-.247-1.155-.165-.248-.495-.248-.99-.248h-1.486v2.146h-1.403v-5.86h3.136c.66 0 1.238 0 1.65.247.414.248.744.66.744 1.321 0 .908-.578 1.403-.99 1.568.412.165.66.33.742.495zm5.695-2.394H41.73v1.073h3.137v1.155H41.73V26.6h3.22v1.238h-4.623v-5.86h4.622v1.238zm3.467 4.622h-2.641V26.6h2.641c.248 0 .413 0 .578-.165a.63.63 0 0 0 .165-.413.63.63 0 0 0-.165-.412c-.083-.083-.248-.165-.495-.165-1.321-.083-2.89 0-2.89-1.816 0-.826.496-1.734 1.982-1.734h2.723v1.403h-2.558c-.248 0-.413 0-.578.083-.165.082-.165.248-.165.413 0 .247.165.33.33.412.165.083.33.083.495.083h.743c.743 0 1.238.165 1.568.495.248.248.413.66.413 1.238 0 1.238-.743 1.816-2.146 1.816zm7.098-.578c-.33.33-.908.578-1.733.578H51.14V26.6h2.641c.248 0 .413 0 .578-.165a.63.63 0 0 0 .165-.413.63.63 0 0 0-.165-.412c-.083-.083-.248-.165-.495-.165-1.321-.083-2.89 0-2.89-1.816 0-.826.496-1.734 1.982-1.734h2.723v1.403h-2.476c-.247 0-.412 0-.578.083-.165.082-.165.248-.165.413 0 .247.083.33.33.412.166.083.33.083.496.083h.743c.742 0 1.238.165 1.568.495.082 0 .082.083.082.083.248.33.33.742.33 1.155 0 .495-.164.908-.495 1.238z" fill="#016FD0"></path>
                                                            <path d="M37.768 23.381c-.165-.082-.413-.082-.66-.082h-1.651v1.32h1.65c.248 0 .496 0 .661-.082.165-.083.248-.33.248-.578.082-.33-.083-.495-.248-.578zM31.99 13.476c-.164-.082-.412-.082-.66-.082h-1.65v1.32h1.65c.248 0 .496 0 .66-.082.166-.083.248-.33.248-.578.083-.33-.082-.495-.247-.578zM41.978 15.457h1.898l-.907-2.311-.991 2.311zM27.946 27.343v-4.705L25.8 24.95l2.146 2.394zM31.082 23.216H29.35V24.7h1.816c.495 0 .825-.247.825-.742-.082-.496-.412-.743-.907-.743z" fill="#016FD0"></path>
                                                            <path d="M37.768 23.381c-.165-.082-.413-.082-.66-.082h-1.651v1.32h1.65c.248 0 .496 0 .661-.082.165-.083.248-.33.248-.578.082-.33-.083-.495-.248-.578zM18.124 15.292l-1.32-1.32.99 2.146.33-.826zM52.377 23.794c0 .247.083.33.33.412.166.083.33.083.496.083h.743c.495 0 .825.082 1.155.248l-1.238-1.238h-.743c-.247 0-.412 0-.578.082a.63.63 0 0 0-.165.413zM49.489 18.841l.165.248h.082l-.247-.248z" fill="#016FD0"></path>
                                                        </svg>
                                                    </div>
                                                    <div class="col-auto px-5 pb-10">
                                                        <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon--wide icon-payment-apple-pay" viewBox="0 0 62 40">
                                                            <path d="M0 4a4 4 0 0 1 4-4h54a4 4 0 0 1 4 4v32a4 4 0 0 1-4 4H4a4 4 0 0 1-4-4V4z" fill="#F5F5F5"></path>
                                                            <path d="M17.222 13.32c-.527.609-1.37 1.088-2.215 1.02-.105-.822.308-1.696.791-2.235.528-.626 1.45-1.07 2.198-1.105.088.856-.255 1.695-.774 2.32zm.765 1.182c-1.222-.068-2.268.677-2.848.677-.589 0-1.477-.642-2.444-.625a3.624 3.624 0 0 0-3.067 1.815c-1.319 2.21-.343 5.48.931 7.279.625.89 1.372 1.867 2.356 1.832.932-.034 1.301-.59 2.426-.59 1.134 0 1.46.59 2.444.573 1.02-.017 1.661-.89 2.285-1.78.712-1.011 1.002-1.996 1.02-2.047-.018-.017-1.969-.745-1.987-2.938-.017-1.832 1.539-2.706 1.609-2.757-.879-1.267-2.25-1.404-2.725-1.439zm7.059-2.483v13.35h2.127v-4.564h2.944c2.69 0 4.58-1.798 4.58-4.402 0-2.603-1.855-4.384-4.51-4.384h-5.142zm2.127 1.747h2.452c1.846 0 2.9.959 2.9 2.646 0 1.687-1.054 2.655-2.909 2.655h-2.443v-5.301zm11.41 11.706c1.335 0 2.575-.66 3.137-1.704h.044v1.601h1.97v-6.645c0-1.927-1.583-3.168-4.018-3.168-2.259 0-3.929 1.258-3.99 2.988h1.916c.158-.822.94-1.361 2.013-1.361 1.3 0 2.03.59 2.03 1.678v.736l-2.654.155c-2.47.145-3.807 1.13-3.807 2.843 0 1.73 1.38 2.877 3.358 2.877zm.57-1.584c-1.133 0-1.854-.531-1.854-1.345 0-.839.694-1.327 2.022-1.404l2.364-.146v.754c0 1.25-1.09 2.14-2.531 2.14zM46.362 29c2.075 0 3.05-.77 3.903-3.108L54 15.684h-2.162l-2.505 7.887h-.044l-2.506-7.887H44.56l3.604 9.72-.193.59c-.325 1.002-.853 1.387-1.793 1.387-.167 0-.492-.017-.624-.034v1.602c.123.034.65.051.808.051z" fill="#141414"></path>
                                                        </svg>
                                                    </div>
                                                    <div class="col-auto px-5 pb-10">
                                                        <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon--wide icon-payment-diners-club" viewBox="0 0 62 40">
                                                            <rect width="62" height="40" rx="4" fill="#F5F5F5"></rect>
                                                            <path d="M0 4a4 4 0 0 1 4-4h54a4 4 0 0 1 4 4v32a4 4 0 0 1-4 4H4a4 4 0 0 1-4-4V4z" fill="#F5F5F5"></path>
                                                            <path fill-rule="evenodd" clip-rule="evenodd" d="M10.116 22.806c.39.004.77.008.77.742v4.24c-.026.587-.29.612-.832.664l-.023.002v.227h.03a33.694 33.694 0 0 1 1.864-.008c.228.003.46.008.702.008 3.294 0 3.833-2.177 3.833-3.043 0-1.549-1.312-3.06-3.72-3.06-.394 0-.735.005-1.028.01-.221.003-.415.006-.583.006-.363 0-.735 0-1.098-.017v.228H10.116zm2.65 5.595c-.456 0-.968-.079-.968-.752v-4.756l.144-.01a6.46 6.46 0 0 1 .582-.025c1.796 0 2.912 1.18 2.912 2.814 0 1.303-.66 2.729-2.67 2.729z" fill="#211E1F"></path>
                                                            <path d="M16.963 28.454h-.176v.227c.343-.009.679-.017 1.014-.017.169 0 .336.004.501.008.16.005.319.009.475.009v-.227h-.158c-.26 0-.465 0-.465-.29v-3.356c0-.07-.02-.123-.065-.123a.347.347 0 0 0-.168.044c-.037.026-.558.191-.995.315v.14l.041.02c.314.159.442.223.442.591v2.37c0 .289-.186.289-.446.289zM17.326 22.901c0 .227.214.437.456.437.25 0 .456-.2.456-.437 0-.236-.215-.42-.456-.42-.233 0-.456.201-.456.42zM19.122 25.27c.436.167.54.254.54.577v2.317c0 .29-.187.29-.447.29h-.168v.227c.335-.009.67-.018 1.005-.018.169 0 .335.005.5.01.163.004.325.008.486.008v-.227h-.167c-.26 0-.466 0-.466-.29v-2.587c.308-.193.783-.42 1.08-.42.531 0 .855.244.855.744v2.264c0 .289-.185.289-.446.289h-.167v.227c.334-.009.67-.017 1.005-.017.168 0 .334.004.499.008.163.005.325.009.487.009v-.227h-.167c-.261 0-.466 0-.466-.29V25.91c0-.682-.279-1.224-1.069-1.224-.624 0-1.08.298-1.611.656v-.569c0-.07-.028-.087-.056-.087-.423.174-.787.285-1.164.4l-.063.02v.166z" fill="#211E1F"></path>
                                                            <path fill-rule="evenodd" clip-rule="evenodd" d="M24.425 26.775c-.019-.298-.019-.428 0-.507h2.614l.085-.053c.009-.053.009-.105.009-.158-.01-.927-.82-1.372-1.573-1.372-.651 0-1.88.507-1.88 2.221 0 .56.299 1.906 1.778 1.906.763 0 1.293-.455 1.721-.988l-.13-.122c-.343.323-.744.585-1.256.585-.744 0-1.313-.682-1.367-1.512zm1.907-1.006c0 .105-.027.219-.26.219h-1.619c.112-.63.503-1.023 1.07-1.023.52 0 .81.358.81.804z" fill="#211E1F"></path>
                                                            <path d="M27.598 28.454h-.251v.227a42.42 42.42 0 0 1 1.107-.017c.332 0 .656.005 1.048.012l.254.005v-.227h-.52c-.261 0-.447 0-.447-.29V26.11c0-.525.52-.726.679-.726.167 0 .248.056.327.11.075.051.147.1.288.1.26 0 .436-.21.436-.446 0-.315-.297-.463-.53-.463-.567 0-.958.56-1.19.9h-.02V24.8c0-.088-.027-.114-.082-.114-.04 0-.14.048-.302.126-.19.092-.468.226-.835.373v.13c.03.015.068.029.11.044.16.058.374.136.374.35v2.456c0 .29-.186.29-.446.29zM32.102 28.532c-.68 0-1.052-.49-1.173-1.067l-.168.044.103 1.006c.325.175.762.297 1.134.297 1.108 0 1.6-.613 1.6-1.19 0-.736-.62-.986-1.197-1.218-.497-.201-.96-.388-.96-.862 0-.376.353-.577.725-.577.596 0 .921.315 1.014.865h.215l-.066-.891a2.57 2.57 0 0 0-1.06-.254c-1.023 0-1.442.63-1.442 1.12 0 .758.588 1.01 1.131 1.245.465.2.896.386.896.861 0 .307-.205.621-.752.621zM41.768 24.16H42l-.092-1.25c-.717-.236-1.443-.464-2.196-.464-1.823 0-3.526 1.285-3.526 3.078 0 1.967 1.377 3.288 3.553 3.288.615 0 1.667-.236 2.057-.464l.214-1.276-.214-.053c-.186.919-.95 1.513-1.87 1.513-1.432 0-2.773-1.267-2.773-3.035 0-2.098 1.554-2.77 2.625-2.77 1.041 0 1.813.41 1.99 1.433zM42.512 28.454h-.176v.227c.345-.009.68-.017 1.014-.017.17 0 .338.004.504.008.16.005.317.009.472.009v-.227h-.157c-.26 0-.465 0-.465-.29v-6.041c0-.07-.018-.123-.075-.123-.021 0-.07.026-.136.06l-.068.036a6.134 6.134 0 0 1-.959.377v.14l.036.01c.328.087.458.122.458.672v4.87c0 .289-.187.289-.448.289zM48.57 28.366c-.158 0-.26-.009-.26-.167v-3.225c0-.097 0-.158-.075-.158-.033 0-.119.009-.253.022-.247.025-.656.066-1.198.1v.158l.1.026c.316.08.68.174.68.332v2.353c-.39.305-.808.533-1.125.533-.809 0-.809-.752-.809-1.015V25.07c0-.193 0-.254-.103-.254-.054 0-.23.01-.44.023-.261.015-.573.033-.76.038v.167c.52.043.558.262.558.489v2.24c0 .733.52 1.039 1.023 1.039.661 0 1.09-.306 1.647-.734v.708l.047.026c.177-.052.94-.236 1.34-.27v-.185c-.062 0-.128.003-.193.005a5.54 5.54 0 0 1-.18.004z" fill="#211E1F"></path>
                                                            <path fill-rule="evenodd" clip-rule="evenodd" d="M51.548 24.685c-.512 0-1.015.332-1.387.63v-3.192c0-.07-.018-.123-.074-.123a.474.474 0 0 0-.132.058 6.073 6.073 0 0 1-1.032.414v.14l.036.01c.327.088.458.124.458.673v3.76c0 .533-.047 1.04-.13 1.556l.195.096.279-.2c.036.013.075.03.118.049.24.104.59.256 1.175.256 1.331 0 2.224-1.146 2.224-2.291 0-.952-.65-1.836-1.73-1.836zm-.428 3.9c-.624 0-.959-.56-.959-.893V25.57c.251-.202.54-.412.884-.412.726 0 1.489.787 1.489 1.73 0 .78-.419 1.698-1.414 1.698z" fill="#211E1F"></path>
                                                            <path d="M11.172 33.919c.137.005.273.01.394.01h.023v-.185h-.094c-.183-.004-.352-.017-.353-.25v-2.493c.001-.232.17-.248.353-.25h.094v-.185h-.023c-.118 0-.252.005-.387.01-.139.004-.28.009-.407.009-.13 0-.277-.005-.415-.01-.124-.005-.241-.009-.335-.009H10v.184h.093c.183.003.35.019.352.251v2.493c-.002.233-.169.246-.352.25H10v.184h.022c.094 0 .21-.004.332-.008.137-.005.282-.01.412-.01.127 0 .267.004.406.009zM15.337 34l-.209-.007-2.57-2.691v1.907c.007.413.074.53.455.535h.109v.184h-.023c-.11 0-.22-.004-.329-.01-.108-.004-.216-.009-.324-.009-.113 0-.227.005-.342.01-.116.005-.232.01-.347.01h-.022v-.185h.094c.334-.001.43-.203.433-.583v-2.003c0-.254-.221-.407-.438-.408h-.089v-.183h.022c.097 0 .196.004.294.009.097.004.193.009.288.009.062 0 .123-.003.186-.006.09-.005.181-.01.282-.005l2.225 2.353v-1.75c-.003-.378-.271-.424-.419-.427h-.134v-.183h.023c.12 0 .238.004.356.009.117.004.234.009.352.009.103 0 .206-.005.31-.01.104-.004.208-.008.313-.008h.022v.183h-.097c-.21.006-.424.023-.43.584v2.165c0 .166.006.332.03.477l.005.024h-.026zM16.592 30.845c-.354.006-.366.06-.436.363l-.013.055-.004.016h-.195l.003-.025.02-.126c.015-.091.03-.184.041-.278a2.53 2.53 0 0 0 .03-.4v-.022h.161l.004.015c.034.12.127.12.255.123h2.639c.142-.002.244-.004.253-.128l.002-.023.023.005.143.02-.003.022c-.02.127-.04.256-.056.383-.01.127-.01.256-.01.384v.015l-.014.005-.18.061v-.027c-.014-.18-.034-.438-.354-.438h-.808v2.511c.005.359.156.384.397.388h.12v.184h-.022c-.092 0-.217-.004-.352-.008-.157-.005-.327-.01-.474-.01-.168 0-.35.005-.515.01-.132.005-.252.008-.341.008h-.021v-.184h.117c.28-.006.392-.01.398-.378v-2.52h-.808zM21.791 33.92c-.26-.005-.544-.011-.79-.011-.254 0-.553.006-.818.011-.21.005-.4.008-.529.008h-.02v-.184h.091c.184-.002.35-.017.353-.25v-2.493c-.003-.232-.169-.247-.353-.25h-.092v-.184h.021c.143 0 .331.003.534.008.239.005.497.01.726.01.225 0 .476-.005.715-.01.214-.004.418-.008.581-.008h.023l-.001.02a6.909 6.909 0 0 0 .01.726v.018l-.016.004-.178.044-.001-.024c-.03-.31-.074-.533-.595-.538h-.682v1.205h.58c.292-.003.344-.143.379-.4l.001-.018h.195v.02c-.01.186-.017.372-.017.557 0 .18.006.36.016.542v.017l-.018.004-.176.032-.001-.022-.005-.039c-.031-.265-.048-.41-.369-.414h-.585v1.088c0 .286.26.287.586.29h.01c.61-.004.853-.032 1.006-.566l.005-.02.021.004.163.04-.005.02a10.27 10.27 0 0 0-.172.755l-.004.017h-.017c-.149 0-.352-.005-.572-.009z" fill="#211E1F"></path>
                                                            <path fill-rule="evenodd" clip-rule="evenodd" d="M25.974 33.919c.083.005.166.01.251.01h.022v-.182l-.019-.003c-.246-.03-.334-.078-.476-.276l-.85-1.197c.39-.15.692-.417.692-.847-.001-.691-.589-.857-1.227-.858-.13 0-.256.005-.384.009a11.596 11.596 0 0 1-.94-.002 8.855 8.855 0 0 0-.276-.007h-.022v.184h.123c.155.005.324.01.327.341v2.417c0 .16-.154.235-.337.236h-.113v.184h.022c.129 0 .253-.004.376-.01.12-.004.238-.009.358-.009.143 0 .288.005.434.01.146.005.292.01.436.01h.023v-.185h-.126c-.227-.005-.375-.008-.38-.36v-.997h.3c.326.544.66 1.055 1.047 1.533.106.005.206 0 .302-.004.065-.004.129-.007.191-.007.083 0 .164.005.246.01zm-1.102-2.465c-.005.553-.257.716-.758.72h-.226v-1.378l.05-.005c.051-.006.113-.013.216-.013.44.002.716.26.718.676z" fill="#211E1F"></path>
                                                            <path d="M29.956 34l-.209-.007-2.569-2.691v1.906c.006.414.073.532.455.536h.107v.184h-.022c-.11 0-.22-.005-.328-.01-.109-.004-.217-.01-.325-.01-.113 0-.228.006-.343.01-.115.005-.23.01-.345.01h-.023v-.184h.093c.334-.001.43-.203.433-.584v-2.003c0-.253-.22-.407-.437-.407h-.089v-.184h.023c.097 0 .195.005.293.01.097.004.194.009.289.009.062 0 .123-.004.186-.007.089-.005.18-.01.28-.005l2.225 2.354v-1.75c-.002-.378-.271-.425-.418-.427h-.134v-.184h.022c.12 0 .239.005.357.01.117.004.234.009.352.009.103 0 .206-.005.31-.01.104-.004.208-.01.313-.01h.022v.185h-.097c-.21.005-.424.023-.43.584v2.165c0 .166.005.331.03.477l.003.024h-.024z" fill="#211E1F"></path>
                                                            <path fill-rule="evenodd" clip-rule="evenodd" d="M33.94 33.928h.024l.023.002v-.186h-.052c-.163 0-.256-.05-.314-.178a4.89 4.89 0 0 1-.164-.422l-.022-.06-.933-2.49a4.793 4.793 0 0 1-.045-.12.064.064 0 0 0-.056-.027.116.116 0 0 0-.04.008l-.01.003c-.097.058-.3.154-.459.204a4.922 4.922 0 0 1-.188.57l-.013.033-.81 2.184a.432.432 0 0 1-.42.295h-.052v.186l.024-.002h.016c.176-.01.353-.019.53-.019.198 0 .4.01.6.019h.01l.023.002v-.186h-.078c-.168 0-.357-.029-.358-.145 0-.05.025-.122.058-.212.017-.046.035-.098.053-.153l.157-.48h1.117l.193.537c.056.152.101.282.1.336 0 .092-.174.117-.291.117h-.078v.186l.022-.002.047-.001c.243-.01.48-.018.713-.018.233 0 .454.01.674.019zm-1.5-1.482h-.885L32 31.17l.44 1.275z" fill="#211E1F"></path>
                                                            <path d="M34.187 30.845h.808v2.52c-.007.37-.119.373-.398.38h-.118v.183h.022c.089 0 .209-.003.342-.008.163-.005.347-.01.514-.01.146 0 .317.005.474.01.134.004.26.008.35.008h.023v-.184h-.119c-.24-.004-.392-.03-.397-.388v-2.51h.808c.32 0 .34.258.353.437v.027l.18-.06.015-.006v-.015c0-.128 0-.257.01-.384a9.47 9.47 0 0 1 .055-.383l.004-.021-.143-.021-.024-.005-.002.023c-.009.124-.11.126-.25.129H34.08l-.026-.001h-.002c-.129-.002-.22-.003-.255-.123l-.005-.015h-.16v.021c0 .137-.01.269-.03.401-.01.1-.027.195-.043.291l-.018.114-.003.024h.195l.004-.016.013-.057c.07-.302.082-.355.436-.36zM38.425 33.919c.137.005.273.01.394.01h.022v-.185h-.093c-.185-.002-.35-.017-.353-.25v-2.493c.002-.232.168-.248.353-.25h.093v-.184h-.022c-.118 0-.252.004-.388.009-.139.004-.28.009-.408.009-.13 0-.276-.005-.414-.01-.124-.004-.24-.008-.334-.008h-.022v.183h.093c.183.003.35.02.351.251v2.493c0 .233-.168.248-.351.25h-.093v.184h.022c.093 0 .21-.004.331-.008.137-.006.282-.011.413-.011.127 0 .267.005.406.01z" fill="#211E1F"></path>
                                                            <path fill-rule="evenodd" clip-rule="evenodd" d="M40.838 30.495c1.087 0 1.96.636 1.961 1.662 0 1.106-.847 1.84-1.935 1.843-1.083-.002-1.914-.694-1.916-1.729.002-1 .826-1.775 1.89-1.776zm.077 3.255c.962-.002 1.13-.794 1.132-1.488 0-.69-.396-1.515-1.219-1.516-.868 0-1.125.725-1.127 1.358 0 .848.412 1.644 1.214 1.646z" fill="#211E1F"></path>
                                                            <path d="M46.273 33.993l.21.007h.024l-.004-.023a2.96 2.96 0 0 1-.029-.478v-2.165c.004-.56.22-.578.428-.584H47v-.183h-.021c-.106 0-.21.004-.314.009-.104.004-.207.009-.31.009-.118 0-.235-.005-.352-.01a9.097 9.097 0 0 0-.356-.008h-.023v.183h.133c.148.003.418.049.42.428v1.75l-2.225-2.354c-.1-.005-.193 0-.283.005-.062.003-.123.006-.185.006-.095 0-.191-.005-.288-.01-.098-.004-.197-.008-.294-.008h-.021v.183h.087c.218 0 .439.154.44.407v2.004c-.005.38-.1.582-.434.583h-.093v.184h.021c.115 0 .231-.005.347-.01.115-.004.23-.009.343-.009.107 0 .215.005.324.01.109.005.218.01.329.01h.022v-.185h-.11c-.38-.005-.447-.122-.453-.535v-1.907l2.57 2.69z" fill="#211E1F"></path>
                                                            <path fill-rule="evenodd" clip-rule="evenodd" d="M50.49 33.928l-.103-.003a14.856 14.856 0 0 0-.593-.016c-.205 0-.413.008-.626.015l-.133.005h-.022v-.185h.076c.118 0 .293-.025.293-.117.001-.054-.044-.184-.1-.336l-.193-.538H47.97l-.156.48a3.56 3.56 0 0 1-.054.157.716.716 0 0 0-.056.209c0 .116.19.145.357.145h.077v.186l-.022-.002-.09-.003c-.174-.008-.35-.016-.522-.016-.152 0-.305.008-.458.015l-.088.005h-.022v-.185h.051a.436.436 0 0 0 .42-.295l.811-2.184.026-.071c.062-.166.136-.367.175-.531.159-.052.362-.147.46-.205l.006-.002a.122.122 0 0 1 .042-.008.058.058 0 0 1 .056.028l.018.047.028.072.931 2.488.026.072c.052.145.105.291.161.412.06.126.152.176.313.177h.053v.186l-.023-.002zm-2.407-1.482h.885l-.44-1.275-.445 1.275z" fill="#211E1F"></path>
                                                            <path d="M52.672 33.919c.223.005.446.01.669.01h.017l.005-.017c.024-.108.05-.216.076-.324.039-.16.077-.322.112-.485l.004-.025h-.19l-.005.016a1.03 1.03 0 0 1-.153.336.716.716 0 0 1-.471.248 3.824 3.824 0 0 1-.664.01c-.158-.021-.282-.069-.283-.246v-2.455c.003-.23.115-.232.295-.236h.175v-.184h-.021c-.13 0-.26.004-.387.009-.128.004-.255.009-.383.009-.134 0-.266-.005-.399-.01-.133-.004-.267-.008-.401-.008h-.022v.183h.092c.185.003.357.02.36.25v2.447c-.003.282-.176.293-.36.297h-.092v.184h.022c.223 0 .446-.004.669-.01.222-.004.445-.009.668-.009.222 0 .444.005.667.01z" fill="#211E1F"></path>
                                                            <path fill-rule="evenodd" clip-rule="evenodd" d="M53.202 31.194v.024h.257v-.024l-.017-.002c-.05-.007-.06-.008-.06-.038v-.166h.058c.03.04.056.078.078.11.048.073.08.12.114.12h.104v-.016a.53.53 0 0 1-.118-.118l-.087-.115c.073-.021.126-.076.126-.15 0-.092-.086-.134-.18-.134h-.273v.026c.07-.003.075.015.075.067v.37c0 .036-.01.037-.062.044l-.015.002zm.242-.24h-.063v-.235h.06c.054 0 .104.028.104.108 0 .078-.032.128-.1.128z" fill="#211E1F"></path>
                                                            <path fill-rule="evenodd" clip-rule="evenodd" d="M54 30.955c0-.283-.228-.503-.533-.503-.305 0-.533.22-.533.503 0 .28.228.499.533.499.305 0 .533-.218.533-.5zm-.111 0a.417.417 0 0 1-.422.406.417.417 0 0 1-.423-.406c0-.216.183-.41.423-.41.241 0 .422.193.422.41z" fill="#211E1F"></path>
                                                            <path d="M28.361 8.653a4.648 4.648 0 0 0-2.95 4.333 4.646 4.646 0 0 0 2.95 4.331V8.653zM31.652 8.653v8.666a4.647 4.647 0 0 0 2.952-4.333 4.646 4.646 0 0 0-2.952-4.333z" fill="#0079BE"></path>
                                                            <path fill-rule="evenodd" clip-rule="evenodd" d="M42 13.07c0 4.363-3.953 7.95-8.283 7.93H29.99c-4.383.02-7.99-3.566-7.99-7.93 0-4.772 3.607-8.072 7.99-8.07h3.727C38.047 4.998 42 8.297 42 13.07zm-19.244-.084c.001-4.046 3.246-7.324 7.25-7.325 4.006.001 7.252 3.28 7.253 7.325 0 4.044-3.247 7.322-7.252 7.323-4.005-.001-7.25-3.279-7.25-7.323z" fill="#0079BE"></path>
                                                        </svg>
                                                    </div>
                                                    <div class="col-auto px-5 pb-10">
                                                        <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon--wide icon-payment-discover" viewBox="0 0 62 40">
                                                            <path d="M0 4a4 4 0 0 1 4-4h54a4 4 0 0 1 4 4v32a4 4 0 0 1-4 4H4a4 4 0 0 1-4-4V4z" fill="#F5F5F5"></path>
                                                            <path d="M9.288 22.711c-.511.462-1.175.663-2.226.663h-.437V17.86h.437c1.051 0 1.689.188 2.226.674.563.5.901 1.277.901 2.076 0 .8-.338 1.6-.9 2.101zm-1.9-6.264H5v8.339h2.375c1.263 0 2.175-.298 2.976-.963a4.185 4.185 0 0 0 1.514-3.201c0-2.461-1.84-4.175-4.477-4.175M12.613 24.786h1.627v-8.34h-1.627v8.34zM18.218 19.647c-.977-.361-1.263-.6-1.263-1.05 0-.526.51-.925 1.212-.925.487 0 .887.2 1.311.676l.851-1.115a3.649 3.649 0 0 0-2.45-.924c-1.476 0-2.601 1.024-2.601 2.39 0 1.148.524 1.736 2.052 2.286.636.225.96.375 1.124.475.325.212.488.513.488.863 0 .676-.537 1.176-1.263 1.176-.776 0-1.401-.388-1.775-1.112L14.851 23.4c.75 1.1 1.65 1.588 2.888 1.588 1.69 0 2.876-1.124 2.876-2.739 0-1.325-.548-1.925-2.398-2.601M21.13 20.622c0 2.451 1.924 4.352 4.401 4.352.7 0 1.3-.138 2.04-.486v-1.915c-.65.651-1.227.914-1.964.914-1.638 0-2.801-1.188-2.801-2.877 0-1.601 1.2-2.864 2.725-2.864.776 0 1.363.277 2.04.938V16.77c-.714-.362-1.302-.512-2.001-.512-2.465 0-4.44 1.94-4.44 4.364zM40.469 22.048l-2.224-5.601h-1.777L40.007 25h.875l3.603-8.553h-1.763l-2.253 5.601zM45.22 24.786h4.614v-1.412h-2.988v-2.25h2.877V19.71h-2.877V17.86h2.988v-1.413H45.22v8.339M53.01 20.286h-.475V17.76h.501c1.013 0 1.564.424 1.564 1.236 0 .838-.55 1.29-1.59 1.29zm3.264-1.378c0-1.56-1.075-2.462-2.951-2.462H50.91v8.34h1.624v-3.35h.213l2.251 3.35h2l-2.625-3.513c1.225-.25 1.9-1.087 1.9-2.364z" fill="#201D1C"></path>
                                                            <circle cx="32.628" cy="20.617" r="4.362" fill="url(#a)"></circle>
                                                            <defs>
                                                                <linearGradient id="a" x1="29.927" y1="17.917" x2="36.367" y2="24.564" gradientUnits="userSpaceOnUse">
                                                                    <stop stop-color="#DF461F"></stop>
                                                                    <stop offset="1" stop-color="#F59314"></stop>
                                                                </linearGradient>
                                                            </defs>
                                                        </svg>
                                                    </div>
                                                    <div class="col-auto px-5 pb-10">
                                                        <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon--wide icon-payment-google-pay" viewBox="0 0 62 40">
                                                            <path d="M0 4a4 4 0 0 1 4-4h54a4 4 0 0 1 4 4v32a4 4 0 0 1-4 4H4a4 4 0 0 1-4-4V4z" fill="#F5F5F5"></path>
                                                            <path d="M29.338 20.296v5.25h-1.667V12.578h4.419A3.992 3.992 0 0 1 34.95 13.7a3.604 3.604 0 0 1 1.194 2.737 3.592 3.592 0 0 1-1.194 2.753c-.773.737-1.727 1.106-2.861 1.104l-2.752.002zm0-6.121v4.528h2.793a2.197 2.197 0 0 0 1.648-.671 2.21 2.21 0 0 0 .044-3.126c-.015-.015-.029-.03-.044-.043a2.173 2.173 0 0 0-1.648-.688h-2.793zm10.648 2.209c1.232 0 2.203.329 2.916.986.712.658 1.067 1.561 1.067 2.707v5.469h-1.593v-1.232h-.072c-.69 1.014-1.608 1.521-2.753 1.521-.977 0-1.796-.29-2.453-.87a2.776 2.776 0 0 1-.987-2.173c0-.918.348-1.648 1.042-2.19.693-.542 1.62-.814 2.78-.814.988 0 1.804.18 2.443.542v-.382a1.897 1.897 0 0 0-.688-1.474 2.359 2.359 0 0 0-1.608-.607c-.93 0-1.667.393-2.21 1.178l-1.466-.924c.805-1.159 2-1.737 3.581-1.737zm-2.157 6.446c-.002.431.204.835.552 1.087.369.289.826.444 1.295.434a2.661 2.661 0 0 0 1.874-.778c.552-.52.828-1.128.828-1.83-.52-.413-1.243-.621-2.173-.621-.677 0-1.242.162-1.694.49-.455.332-.682.734-.682 1.218zm15.287-6.157l-5.562 12.785h-1.72l2.064-4.473-3.659-8.312h1.811l2.644 6.375h.036l2.572-6.375h1.814z" fill="#141414"></path>
                                                            <path d="M22.604 19.162c0-.508-.041-1.015-.128-1.516h-7.027v2.87h4.024a3.446 3.446 0 0 1-1.488 2.263v1.863h2.402c1.406-1.294 2.217-3.212 2.217-5.48z" fill="#4285F4"></path>
                                                            <path d="M15.45 26.444c2.01 0 3.704-.66 4.938-1.8l-2.402-1.863c-.669.454-1.529.713-2.536.713-1.943 0-3.593-1.31-4.182-3.075H8.794v1.92a7.448 7.448 0 0 0 6.656 4.105z" fill="#34A853"></path>
                                                            <path d="M11.268 20.419a4.464 4.464 0 0 1 0-2.852v-1.92H8.793a7.45 7.45 0 0 0 0 6.692l2.473-1.92z" fill="#FBBC04"></path>
                                                            <path d="M15.45 14.492a4.047 4.047 0 0 1 2.857 1.117l2.128-2.126a7.167 7.167 0 0 0-4.985-1.94 7.451 7.451 0 0 0-6.656 4.104l2.474 1.92c.59-1.765 2.24-3.075 4.182-3.075z" fill="#EA4335"></path>
                                                        </svg>
                                                    </div>
                                                    <div class="col-auto px-5 pb-10">
                                                        <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon--wide icon-payment-master" viewBox="0 0 62 40">
                                                            <path d="M0 4a4 4 0 0 1 4-4h54a4 4 0 0 1 4 4v32a4 4 0 0 1-4 4H4a4 4 0 0 1-4-4V4z" fill="#F5F5F5"></path>
                                                            <path d="M35.858 24.44h-9.003V8.26h9.003v16.18z" fill="#FF5F00"></path>
                                                            <path d="M27.431 16.35c0-3.283 1.537-6.206 3.93-8.09a10.245 10.245 0 0 0-6.359-2.2c-5.682 0-10.289 4.606-10.289 10.29 0 5.683 4.607 10.29 10.29 10.29 2.4 0 4.608-.823 6.358-2.2a10.273 10.273 0 0 1-3.93-8.09z" fill="#EB001B"></path>
                                                            <path d="M48 16.35c0 5.683-4.606 10.29-10.289 10.29-2.4 0-4.609-.823-6.36-2.2a10.272 10.272 0 0 0 3.931-8.09c0-3.283-1.537-6.206-3.93-8.09 1.75-1.378 3.959-2.2 6.36-2.2C43.393 6.06 48 10.665 48 16.35z" fill="#F79E1B"></path>
                                                            <path d="M15.411 33.926v-2.205c0-.846-.586-1.398-1.592-1.398-.503 0-1.048.148-1.425.625-.293-.404-.712-.625-1.34-.625-.42 0-.839.11-1.174.515v-.44H9v3.528h.88v-1.948c0-.625.377-.92.964-.92s.88.332.88.92v1.948h.88v-1.948c0-.625.419-.92.964-.92.586 0 .88.332.88.92v1.948h.963zm13.033-3.529h-1.425v-1.066h-.88v1.066h-.796v.699h.796v1.617c0 .81.377 1.287 1.383 1.287.377 0 .796-.11 1.09-.257l-.252-.662a1.529 1.529 0 0 1-.754.184c-.42 0-.587-.22-.587-.589v-1.58h1.425v-.699zm7.459-.073c-.503 0-.838.22-1.048.514v-.44h-.88v3.528h.88v-1.985c0-.588.294-.919.838-.919.168 0 .378.037.545.074l.252-.736c-.168-.037-.42-.037-.587-.037zm-11.272.367c-.42-.257-1.006-.367-1.635-.367-1.005 0-1.676.44-1.676 1.14 0 .587.503.918 1.383 1.029l.419.036c.46.074.712.184.712.368 0 .257-.335.441-.922.441a2.538 2.538 0 0 1-1.34-.367l-.42.588c.461.294 1.09.441 1.718.441 1.174 0 1.844-.478 1.844-1.14 0-.625-.544-.956-1.383-1.066l-.419-.037c-.377-.036-.67-.11-.67-.33 0-.258.293-.405.754-.405.503 0 1.006.184 1.257.294l.378-.625zm23.382-.367c-.502 0-.838.22-1.047.514v-.44h-.88v3.528h.88v-1.985c0-.588.293-.919.838-.919.167 0 .377.037.545.074l.251-.736c-.168-.037-.419-.037-.587-.037zm-11.23 1.838c0 1.066.838 1.838 2.137 1.838.587 0 1.006-.11 1.425-.404l-.42-.625c-.334.22-.67.33-1.047.33-.712 0-1.215-.44-1.215-1.14 0-.661.503-1.102 1.215-1.139.377 0 .712.11 1.048.33l.419-.624c-.42-.294-.838-.405-1.425-.405-1.299 0-2.137.773-2.137 1.839zm8.13 0v-1.765h-.88v.441c-.294-.33-.713-.515-1.258-.515-1.131 0-2.011.773-2.011 1.839 0 1.066.88 1.838 2.011 1.838.587 0 1.006-.184 1.257-.515v.441h.88v-1.764zm-3.227 0c0-.625.46-1.14 1.215-1.14.712 0 1.215.478 1.215 1.14 0 .625-.503 1.14-1.215 1.14-.754-.037-1.215-.515-1.215-1.14zm-10.518-1.838c-1.174 0-2.012.735-2.012 1.838 0 1.103.838 1.838 2.053 1.838.587 0 1.174-.147 1.635-.478l-.42-.551c-.334.22-.753.367-1.173.367-.544 0-1.09-.22-1.215-.845h2.975v-.294c.042-1.14-.712-1.875-1.843-1.875zm0 .661c.544 0 .922.294 1.005.846h-2.095c.084-.478.461-.846 1.09-.846zM53 32.162V29h-.88v1.838c-.293-.33-.712-.515-1.257-.515-1.132 0-2.012.773-2.012 1.839 0 1.066.88 1.838 2.012 1.838.587 0 1.006-.184 1.257-.515v.441H53v-1.764zm-3.227 0c0-.625.461-1.14 1.216-1.14.712 0 1.215.478 1.215 1.14 0 .625-.503 1.14-1.215 1.14-.755-.037-1.216-.515-1.216-1.14zm-29.417 0v-1.765h-.88v.441c-.293-.33-.712-.515-1.257-.515-1.131 0-2.011.773-2.011 1.839 0 1.066.88 1.838 2.011 1.838.587 0 1.006-.184 1.257-.515v.441h.88v-1.764zm-3.268 0c0-.625.46-1.14 1.215-1.14.712 0 1.215.478 1.215 1.14 0 .625-.503 1.14-1.215 1.14-.754-.037-1.215-.515-1.215-1.14z" fill="#141414"></path>
                                                        </svg>
                                                    </div>
                                                    <div class="col-auto px-5 pb-10">
                                                        <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon--wide icon-payment-paypal" viewBox="0 0 62 40">
                                                            <path d="M0 4a4 4 0 0 1 4-4h54a4 4 0 0 1 4 4v32a4 4 0 0 1-4 4H4a4 4 0 0 1-4-4V4z" fill="#F5F5F5"></path>
                                                            <path d="M24.403 16.843h-2.881a.4.4 0 0 0-.396.338l-1.165 7.388a.24.24 0 0 0 .238.277h1.375a.4.4 0 0 0 .396-.338l.314-1.992a.4.4 0 0 1 .395-.339h.912c1.898 0 2.993-.918 3.28-2.738.128-.796.005-1.422-.368-1.86-.41-.481-1.136-.736-2.1-.736zm.332 2.699c-.157 1.034-.947 1.034-1.71 1.034h-.436l.305-1.931a.241.241 0 0 1 .238-.203h.199c.52 0 1.01 0 1.265.297.15.177.197.44.14.803zm8.28-.034h-1.38a.24.24 0 0 0-.237.203l-.06.386-.097-.14c-.299-.434-.965-.578-1.63-.578-1.524 0-2.826 1.154-3.08 2.774-.132.808.056 1.58.514 2.12.42.495 1.022.702 1.738.702 1.228 0 1.91-.79 1.91-.79l-.062.383a.24.24 0 0 0 .237.278h1.243a.4.4 0 0 0 .395-.338l.746-4.723a.24.24 0 0 0-.237-.277zm-1.923 2.686c-.133.788-.758 1.317-1.556 1.317-.401 0-.721-.128-.927-.372-.204-.242-.281-.586-.216-.97a1.544 1.544 0 0 1 1.546-1.327c.392 0 .71.13.92.376.21.248.293.594.233.976zm9.272-2.686h-1.387a.402.402 0 0 0-.331.176l-1.913 2.817-.81-2.707a.402.402 0 0 0-.385-.286h-1.362a.24.24 0 0 0-.228.318l1.527 4.482-1.436 2.026a.24.24 0 0 0 .196.38h1.385a.4.4 0 0 0 .33-.172l4.61-6.657a.24.24 0 0 0-.197-.377z" fill="#253B80"></path>
                                                            <path d="M44.954 16.843h-2.882a.4.4 0 0 0-.395.338l-1.165 7.388a.24.24 0 0 0 .236.278h1.48a.28.28 0 0 0 .276-.237l.33-2.094a.4.4 0 0 1 .395-.339h.912c1.898 0 2.993-.918 3.28-2.738.13-.796.005-1.422-.368-1.86-.409-.481-1.135-.736-2.1-.736zm.332 2.699c-.157 1.034-.947 1.034-1.711 1.034h-.434l.305-1.931a.24.24 0 0 1 .237-.203h.2c.519 0 1.01 0 1.264.297.151.177.197.44.14.803zm8.28-.034h-1.38a.238.238 0 0 0-.236.203l-.06.386-.098-.14c-.299-.433-.964-.578-1.629-.578-1.525 0-2.826 1.154-3.08 2.774-.131.808.055 1.58.514 2.12.42.495 1.022.702 1.737.702 1.229 0 1.91-.79 1.91-.79l-.061.383a.238.238 0 0 0 .136.256.24.24 0 0 0 .101.022h1.243a.4.4 0 0 0 .395-.338l.746-4.722a.242.242 0 0 0-.138-.256.241.241 0 0 0-.1-.022zm-1.923 2.686a1.537 1.537 0 0 1-1.557 1.317c-.4 0-.72-.128-.926-.372-.204-.242-.281-.586-.217-.97a1.545 1.545 0 0 1 1.546-1.327c.392 0 .71.13.92.376.211.248.295.594.234.976zm3.55-5.148l-1.183 7.523a.239.239 0 0 0 .237.278h1.188a.4.4 0 0 0 .396-.339l1.166-7.387a.24.24 0 0 0-.236-.278h-1.332a.24.24 0 0 0-.237.203z" fill="#179BD7"></path>
                                                            <path d="M10.06 26.282l.221-1.4-.49-.01H7.446l1.628-10.328a.133.133 0 0 1 .133-.113h3.951c1.312 0 2.218.273 2.69.812.222.253.363.517.431.808.072.305.073.67.003 1.114l-.005.032v.285l.222.126c.169.085.321.201.448.342.19.216.313.49.364.816.054.335.036.734-.051 1.185a4.171 4.171 0 0 1-.486 1.34 2.76 2.76 0 0 1-.768.843 3.119 3.119 0 0 1-1.036.468c-.382.099-.817.149-1.294.149h-.308c-.22 0-.433.08-.6.221a.932.932 0 0 0-.314.56l-.024.126-.389 2.466-.018.09c-.004.03-.012.044-.024.053a.065.065 0 0 1-.04.015h-1.9z" fill="#253B80"></path>
                                                            <path d="M16.71 17.23a6.837 6.837 0 0 1-.04.232c-.522 2.675-2.305 3.6-4.582 3.6h-1.16a.563.563 0 0 0-.556.476l-.593 3.765-.168 1.067a.296.296 0 0 0 .292.343h2.057c.243 0 .45-.177.488-.417l.02-.104.388-2.457.025-.135a.494.494 0 0 1 .488-.418h.308c1.992 0 3.552-.809 4.008-3.15.19-.977.091-1.794-.412-2.368a1.966 1.966 0 0 0-.563-.434z" fill="#179BD7"></path>
                                                            <path d="M16.165 17.013a4.104 4.104 0 0 0-.507-.113 6.44 6.44 0 0 0-1.022-.074h-3.097a.494.494 0 0 0-.489.418l-.659 4.173-.018.122a.563.563 0 0 1 .556-.477h1.16c2.277 0 4.06-.925 4.58-3.6.016-.08.03-.157.041-.232a2.782 2.782 0 0 0-.545-.217z" fill="#222D65"></path>
                                                            <path d="M11.05 17.244a.493.493 0 0 1 .489-.418h3.097c.367 0 .71.024 1.022.075a4.1 4.1 0 0 1 .624.148c.154.051.296.111.428.181.155-.989-.001-1.662-.536-2.272-.589-.67-1.653-.958-3.014-.958H9.208a.565.565 0 0 0-.558.477L7.004 24.911a.34.34 0 0 0 .335.392h2.44l.612-3.886.66-4.174z" fill="#253B80"></path>
                                                        </svg>
                                                    </div>
                                                    <div class="col-auto px-5 pb-10">
                                                        <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon--wide icon-payment-shopify-pay" viewBox="0 0 62 40">
                                                            <path d="M0 4a4 4 0 0 1 4-4h54a4 4 0 0 1 4 4v32a4 4 0 0 1-4 4H4a4 4 0 0 1-4-4V4z" fill="#F5F5F5"></path>
                                                            <path d="M21.2 13.634a.16.16 0 0 0-.156-.14c-.061 0-1.428-.101-1.428-.101s-.944-.935-1.06-1.036c-.103-.1-.305-.074-.383-.05-.013 0-.203.065-.537.166-.318-.92-.88-1.756-1.864-1.756h-.088c-.269-.352-.626-.517-.917-.517-2.3 0-3.399 2.841-3.744 4.278-.89.279-1.53.465-1.608.493-.495.151-.51.163-.573.63-.05.353-1.353 10.325-1.353 10.325l10.148 1.88 5.501-1.173c0-.013-1.926-12.911-1.94-13h.001zm-4.124-1.011c-.287.085-.572.174-.855.267v-.19c0-.556-.079-1.01-.207-1.375.513.077.846.644 1.062 1.297v.002-.001zm-1.697-1.172c.14.354.226.844.226 1.526v.1c-.559.177-1.16.354-1.774.543.344-1.298 1-1.932 1.548-2.169zm-.678-.645c.106.003.21.038.294.101-.743.342-1.52 1.198-1.85 2.93-.486.15-.96.288-1.405.426.382-1.313 1.313-3.455 2.96-3.455v-.002z" fill="#95BF47"></path>
                                                            <path d="M21.047 13.482c-.066 0-1.431-.101-1.431-.101s-.944-.935-1.06-1.036a.207.207 0 0 0-.141-.062l-.765 15.522 5.501-1.172-1.942-13a.217.217 0 0 0-.164-.151h.002z" fill="#5E8E3E"></path>
                                                            <path d="M15.772 16.486l-.675 1.992s-.6-.315-1.326-.315c-1.075 0-1.124.668-1.124.835 0 .91 2.4 1.26 2.4 3.395 0 1.677-1.075 2.762-2.529 2.762-1.749 0-2.63-1.071-2.63-1.071l.473-1.528s.917.782 1.685.782a.694.694 0 0 0 .508-.189.663.663 0 0 0 .206-.491c0-1.188-1.965-1.238-1.965-3.193 0-1.642 1.188-3.233 3.598-3.233.922-.01 1.38.254 1.38.254z" fill="#fff"></path>
                                                            <path d="M32.273 14.204c2.404 0 3.965 1.573 3.965 3.811 0 2.248-1.56 3.799-3.975 3.799H29.39v4.513h-1.67V14.204h4.556-.002zm2.25 3.811c0-1.5-.881-2.364-2.404-2.364h-2.733v4.727h2.733c1.523 0 2.403-.87 2.403-2.364l.001.001zm5.493 8.463c-1.85 0-3.123-1.138-3.123-2.87 0-1.633 1.162-2.744 3.357-2.744h2.496v-.923c0-1.19-.772-1.731-1.997-1.731-1.205 0-1.715.454-1.906 1.101h-1.588c.146-1.581 1.418-2.478 3.549-2.478 1.97 0 3.593.826 3.593 3.118v6.375h-1.58v-1.233h-.071c-.462.745-1.327 1.385-2.732 1.385h.002zm.452-1.361c1.288 0 2.278-.852 2.278-1.98v-1.046h-2.36c-1.289 0-1.815.63-1.815 1.465 0 1.064.91 1.561 1.897 1.561zM54 16.984h-1.742l-2.533 7.753h-.071l-2.524-7.753h-1.823l3.501 9.457-.144.48c-.254.933-.717 1.467-1.85 1.467-.228 0-.564-.02-.72-.044v1.305c.335.054.672.08 1.01.08 2.041 0 2.739-1.314 3.275-2.754l.245-.64L54 16.985H54z" fill="#141414"></path>
                                                        </svg>
                                                    </div>
                                                    <div class="col-auto px-5 pb-10">
                                                        <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon--wide icon-payment-visa" viewBox="0 0 62 40">
                                                            <path d="M0 4a4 4 0 0 1 4-4h54a4 4 0 0 1 4 4v32a4 4 0 0 1-4 4H4a4 4 0 0 1-4-4V4z" fill="#F5F5F5"></path>
                                                            <path d="M28.34 25.783h-3.264l2.04-12.559h3.265l-2.04 12.56zm-6.01-12.559l-3.111 8.639-.368-1.86-1.098-5.648s-.133-1.13-1.548-1.13H11.06l-.06.212s1.573.328 3.414 1.436l2.836 10.91h3.4l5.193-12.559h-3.512zm25.673 12.56H51l-2.613-12.56h-2.624c-1.211 0-1.506.936-1.506.936l-4.868 11.623h3.402l.68-1.865h4.15l.382 1.865zm-3.592-4.443l1.715-4.7.965 4.7h-2.68zm-4.767-5.097l.466-2.696S38.672 13 37.174 13c-1.62 0-5.466.71-5.466 4.158 0 3.244 4.514 3.284 4.514 4.989 0 1.704-4.049 1.399-5.385.324l-.486 2.82S31.81 26 34.035 26c2.228 0 5.588-1.155 5.588-4.3 0-3.265-4.555-3.57-4.555-4.989 0-1.42 3.18-1.237 4.576-.466z" fill="url(#a)"></path>
                                                            <defs>
                                                                <linearGradient id="a" x1="17.459" y1="17.472" x2="34.77" y2="33.229" gradientUnits="userSpaceOnUse">
                                                                    <stop stop-color="#222357"></stop>
                                                                    <stop offset="1" stop-color="#254AA5"></stop>
                                                                </linearGradient>
                                                            </defs>
                                                        </svg>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="product-page-info__share product-page-info__field mt-20 mb-10">
                                            <label class="mb-6">Share:</label>
                                            <div class="social-share social-share--type-1 overflow-hidden">
                                                <div class="row">
                                                    <div class="social-share__col col-2 px-5 mb-10">
                                                        <a href="https://typecase.co/products/airtag-dog-collar-holder2-pack-anti-lost-silicone-pet-collar-case?variant=39847464370229" target="_blank" class="social-share__item social-share__item--facebook position-relative d-block">
                                                            <div class="social-share__item_bg absolute-stretch"></div>
                                                            <div class="social-share__item_content position-relative d-flex flex-center">
                                                                <i>
                                                                    <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-social-facebook" viewBox="0 0 264 512">
                                                                        <path d="M76.7 512V283H0v-91h76.7v-71.7C76.7 42.4 124.3 0 193.8 0c33.3 0 61.9 2.5 70.2 3.6V85h-48.2c-37.8 0-45.1 18-45.1 44.3V192H256l-11.7 91h-73.6v229"></path>
                                                                    </svg>
                                                                </i>
                                                            </div>
                                                        </a>
                                                    </div>
                                                    <div class="social-share__col col-2 px-5 mb-10">
                                                        <a href="https://typecase.co/products/airtag-dog-collar-holder2-pack-anti-lost-silicone-pet-collar-case?variant=39847464370229" target="_blank" class="social-share__item social-share__item--twitter position-relative d-block">
                                                            <div class="social-share__item_bg absolute-stretch"></div>
                                                            <div class="social-share__item_content position-relative d-flex flex-center">
                                                                <i>
                                                                    <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-social-twitter" viewBox="0 0 512 512">
                                                                        <path d="M459.37 151.716c.325 4.548.325 9.097.325 13.645 0 138.72-105.583 298.558-298.558 298.558-59.452 0-114.68-17.219-161.137-47.106 8.447.974 16.568 1.299 25.34 1.299 49.055 0 94.213-16.568 130.274-44.832-46.132-.975-84.792-31.188-98.112-72.772 6.498.974 12.995 1.624 19.818 1.624 9.421 0 18.843-1.3 27.614-3.573-48.081-9.747-84.143-51.98-84.143-102.985v-1.299c13.969 7.797 30.214 12.67 47.431 13.319-28.264-18.843-46.781-51.005-46.781-87.391 0-19.492 5.197-37.36 14.294-52.954 51.655 63.675 129.3 105.258 216.365 109.807-1.624-7.797-2.599-15.918-2.599-24.04 0-57.828 46.782-104.934 104.934-104.934 30.213 0 57.502 12.67 76.67 33.137 23.715-4.548 46.456-13.32 66.599-25.34-7.798 24.366-24.366 44.833-46.132 57.827 21.117-2.273 41.584-8.122 60.426-16.243-14.292 20.791-32.161 39.308-52.628 54.253z"></path>
                                                                    </svg>
                                                                </i>
                                                            </div>
                                                        </a>
                                                    </div>
                                                    <div class="social-share__col col-2 px-5 mb-10">
                                                        <a href="https://typecase.co/products/airtag-dog-collar-holder2-pack-anti-lost-silicone-pet-collar-case?variant=39847464370229" target="_blank" class="social-share__item social-share__item--pinterest position-relative d-block">
                                                            <div class="social-share__item_bg absolute-stretch"></div>
                                                            <div class="social-share__item_content position-relative d-flex flex-center">
                                                                <i>
                                                                    <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-social-pinterest-2" viewBox="0 0 16 20">
                                                                        <path d="M9.336 14.506c-1.252-.094-1.778-.698-2.76-1.278-.54 2.754-1.199 5.393-3.152 6.772C2.82 15.838 4.31 12.713 5 9.395c-1.178-1.93.142-5.812 2.628-4.855 3.059 1.176-2.649 7.173 1.183 7.922 4 .782 5.633-6.75 3.152-9.2C8.38-.275 1.53 3.182 2.373 8.245c.204 1.238 1.52 1.614.525 3.322-2.294-.494-2.979-2.254-2.89-4.6C.148 3.127 3.554.44 6.97.067c4.32-.47 8.376 1.543 8.935 5.495.63 4.46-1.95 9.29-6.57 8.944z"></path>
                                                                    </svg>
                                                                </i>
                                                            </div>
                                                        </a>
                                                    </div>
                                                    <div class="social-share__col col-2 px-5 mb-10">
                                                        <a href="https://typecase.co/products/airtag-dog-collar-holder2-pack-anti-lost-silicone-pet-collar-case?variant=39847464370229" target="_blank" class="social-share__item social-share__item--linkedin position-relative d-block">
                                                            <div class="social-share__item_bg absolute-stretch"></div>
                                                            <div class="social-share__item_content position-relative d-flex flex-center">
                                                                <i>
                                                                    <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-social-linkedin" viewBox="0 0 20 20">
                                                                        <path d="M11.086 8.307c0-.472-.008-.945.003-1.417.006-.215-.063-.296-.286-.294-1.157.008-2.315.008-3.473 0-.212-.001-.292.057-.291.284.006 4.277.005 8.554 0 12.832 0 .222.07.289.287.287 1.211-.008 2.423-.008 3.634 0 .22.003.282-.066.281-.286a691.86 691.86 0 0 1 0-6.095 13.31 13.31 0 0 1 .092-1.504c.065-.544.238-1.058.62-1.473.489-.532 1.124-.652 1.81-.64.958.019 1.555.466 1.829 1.385.176.593.19 1.202.19 1.812.002 2.162 0 4.323.001 6.485 0 .302.01.312.306.312h3.542c.369 0 .37 0 .369-.364-.01-2.619-.018-5.238-.037-7.857a8.903 8.903 0 0 0-.332-2.369c-.335-1.184-.967-2.15-2.128-2.654-1.215-.528-2.486-.623-3.772-.307-1.11.273-1.987.897-2.645 1.863zm-6.57 5.003c0-2.139-.003-4.277.006-6.415 0-.232-.06-.302-.292-.3-1.204.01-2.407.01-3.61 0-.226-.001-.302.062-.302.298.007 4.27.007 8.538 0 12.808 0 .233.072.3.3.299 1.203-.01 2.406-.01 3.61 0 .228.002.295-.062.294-.298-.01-2.13-.006-4.261-.006-6.392zM0 2.435c0 1.333 1.09 2.45 2.421 2.437 1.374-.014 2.44-1.052 2.438-2.44C4.857 1.021 3.771-.008 2.42 0 .976.008.003 1.166 0 2.435z"></path>
                                                                    </svg>
                                                                </i>
                                                            </div>
                                                        </a>
                                                    </div>
                                                    <div class="social-share__col col-2 px-5 mb-10">
                                                        <a href="https://typecase.co/products/airtag-dog-collar-holder2-pack-anti-lost-silicone-pet-collar-case?variant=39847464370229" target="_blank" class="social-share__item social-share__item--buffer position-relative d-block">
                                                            <div class="social-share__item_bg absolute-stretch"></div>
                                                            <div class="social-share__item_content position-relative d-flex flex-center">
                                                                <i>
                                                                    <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-social-buffer" viewBox="0 0 18 16">
                                                                        <path d="M.208 4.058l8.634 3.477c.1.04.217.04.317 0l8.634-3.477c.276-.111.276-.44 0-.551L9.159.03a.43.43 0 0 0-.317 0L.208 3.507c-.276.111-.276.44 0 .551z"></path>
                                                                        <path d="M.207 8.275l8.634 3.477c.1.04.217.04.317 0l8.634-3.477c.276-.11.276-.44 0-.55L15.97 6.99l-5.785 2.33a3.203 3.203 0 0 1-2.371 0L2.029 6.99l-1.822.733c-.276.112-.276.44 0 .551z"></path>
                                                                        <path d="M17.792 11.942l-1.822-.734-5.785 2.33a3.204 3.204 0 0 1-2.371 0l-5.785-2.33-1.822.734c-.276.111-.276.44 0 .55l8.634 3.478c.1.04.217.04.317 0l8.634-3.477c.276-.111.276-.44 0-.551z"></path>
                                                                    </svg>
                                                                </i>
                                                            </div>
                                                        </a>
                                                    </div>
                                                    <div class="social-share__col col-2 px-5 mb-10">
                                                        <a href="https://typecase.co/products/airtag-dog-collar-holder2-pack-anti-lost-silicone-pet-collar-case?variant=39847464370229" target="_blank" class="social-share__item social-share__item--reddit position-relative d-block">
                                                            <div class="social-share__item_bg absolute-stretch"></div>
                                                            <div class="social-share__item_content position-relative d-flex flex-center">
                                                                <i>
                                                                    <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-social-reddit" viewBox="0 0 20 20">
                                                                        <path d="M17.772 7.757c-.632 0-1.188.266-1.597.68-1.504-1.057-3.532-1.737-5.78-1.81l1.168-5.338 3.717.847c0 .923.742 1.677 1.652 1.677.927 0 1.673-.774 1.673-1.698 0-.924-.74-1.698-1.672-1.698-.65 0-1.21.397-1.489.94L11.338.435c-.206-.056-.409.094-.464.304L9.593 6.623c-2.23.095-4.237.774-5.746 1.831a2.227 2.227 0 0 0-1.619-.697c-2.343 0-3.11 3.19-.965 4.281-.075.338-.11.698-.11 1.057 0 3.584 3.98 6.488 8.865 6.488 4.907 0 8.886-2.904 8.886-6.488 0-.36-.037-.736-.13-1.074 2.103-1.095 1.329-4.263-1.002-4.264zM4.668 12.265c0-.94.742-1.698 1.674-1.698.91 0 1.652.752 1.652 1.698 0 .924-.741 1.678-1.652 1.678a1.672 1.672 0 0 1-1.674-1.678zm9.033 3.998c-1.534 1.557-5.863 1.557-7.398 0-.17-.15-.17-.415 0-.585a.4.4 0 0 1 .556 0c1.172 1.219 5.059 1.24 6.281 0a.4.4 0 0 1 .557 0c.172.171.172.436.004.585zm-.034-2.317c-.91 0-1.652-.753-1.652-1.676 0-.94.742-1.698 1.652-1.698.927 0 1.673.752 1.673 1.698a1.68 1.68 0 0 1-1.673 1.676z"></path>
                                                                    </svg>
                                                                </i>
                                                            </div>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        </div>
    </div>
    <div class="popup__body position-relative d-none flex-center px-15 py-30" id="delivery-return" data-popup-center="">
        <div class="popup-delivery-return position-relative py-30 px-15" data-popup-content="">
            <i class="popup-delivery-return__close position-absolute cursor-pointer" data-js-popup-close="" onclick="nav_close()">
                <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-theme-164" viewBox="0 0 24 24">
                    <path d="M19.583 4.965a.65.65 0 0 1-.176.449l-6.445 6.426 6.445 6.426c.117.131.176.28.176.449a.65.65 0 0 1-.176.449.846.846 0 0 1-.215.127.596.596 0 0 1-.468 0 .846.846 0 0 1-.215-.127l-6.426-6.445-6.426 6.445a.846.846 0 0 1-.215.127.596.596 0 0 1-.468 0 .846.846 0 0 1-.215-.127.65.65 0 0 1-.176-.449c0-.169.059-.318.176-.449l6.445-6.426-6.445-6.426a.65.65 0 0 1-.176-.449c0-.169.059-.318.176-.449a.652.652 0 0 1 .449-.176c.169 0 .319.059.449.176l6.426 6.445 6.426-6.445a.652.652 0 0 1 .449-.176c.169 0 .319.059.449.176.117.13.176.28.176.449z"></path>
                </svg>
            </i>
            <div class="popup-delivery-return__content mx-auto">
                <div class="rte">
                    <h4 class="mb-10">Shipping</h4>
                    <ul class="list-sm mb-30">
                        <li>Complimentary ground shipping within 1 to 7 business days</li>
                        <li>In-store collection available within 1 to 7 business days</li>
                        <li>Next-day and Express delivery options also available</li>
                        <li>Purchases are delivered in an orange box tied with a Bolduc ribbon, with the exception of certain items</li>
                        <li>See the delivery FAQs for details on shipping methods, costs and delivery times</li>
                    </ul>
                    <h4 class="mb-10">Returns And Exchanges</h4>
                    <ul class="list-sm">
                        <li>Easy and complimentary, within 14 days</li>
                        <li>See conditions and procedure in our return FAQs</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="popup__body position-relative d-none flex-center px-15 py-30" id="message" data-popup-center="">
        <div class="popup-product-contact position-relative py-30 px-15" data-popup-content="">
            <i class="popup-product-contact__close position-absolute cursor-pointer" data-js-popup-close="" onclick="nav_close()">
                <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-theme-164" viewBox="0 0 24 24">
                    <path d="M19.583 4.965a.65.65 0 0 1-.176.449l-6.445 6.426 6.445 6.426c.117.131.176.28.176.449a.65.65 0 0 1-.176.449.846.846 0 0 1-.215.127.596.596 0 0 1-.468 0 .846.846 0 0 1-.215-.127l-6.426-6.445-6.426 6.445a.846.846 0 0 1-.215.127.596.596 0 0 1-.468 0 .846.846 0 0 1-.215-.127.65.65 0 0 1-.176-.449c0-.169.059-.318.176-.449l6.445-6.426-6.445-6.426a.65.65 0 0 1-.176-.449c0-.169.059-.318.176-.449a.652.652 0 0 1 .449-.176c.169 0 .319.059.449.176l6.426 6.445 6.426-6.445a.652.652 0 0 1 .449-.176c.169 0 .319.059.449.176.117.13.176.28.176.449z"></path>
                </svg>
            </i>
            <div class="popup-product-contact__content mx-auto">
                <h3>Drop Us A Line</h3>
                <p class="fs-lg">We’re happy to answer any questions you have or provide you with an estimate. Just send us a message in the form below with any questions you may have.</p>
                <form method="post" action="/contact#contact_form" id="contact_form" accept-charset="UTF-8" class="contact-form" siq_id="autopick_2111">
                    <input type="hidden" name="form_type" value="contact">
                    <input type="hidden" name="utf8" value="✓">
                    <input type="text" name="contact[product_url]" id="ContactFormProductUrl" value="/products/airtag-dog-collar-holder2-pack-anti-lost-silicone-pet-collar-case" hidden="hidden" required="required">
                    <input type="text" name="contact[name]" id="ContactFormName" placeholder="Enter please your name" value="" required="required">
                    <input type="email" name="contact[email]" id="ContactFormEmail" placeholder="Enter please your email address" value="" spellcheck="false" autocomplete="off" autocapitalize="off" required="required">
                    <input type="tel" class="form-control" name="contact[phone]" id="ContactFormPhone" placeholder="Enter please your phone number" value="" required="required">
                    <textarea rows="8" name="contact[body]" id="ContactFormMessage" placeholder="Enter please your message" required="required"></textarea>
                    <div class="pt-10">
                        <button type="submit" class="btn">
                            <i class="mr-5">
                                <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-theme-196" viewBox="0 0 24 24">
                                    <path d="M21.842 2.54a.601.601 0 0 1 .186.439v12.5c0 .169-.062.315-.186.439s-.271.186-.439.186h-8.535l-5.449 4.238c-.065.052-.13.088-.195.107s-.13.029-.195.029c-.052 0-.101-.007-.146-.02l-.127-.039c-.104-.052-.188-.13-.254-.234s-.098-.215-.098-.332v-3.75h-3.75c-.169 0-.315-.062-.439-.186s-.186-.271-.186-.439v-12.5c0-.169.062-.315.186-.439s.271-.186.439-.186h18.75a.606.606 0 0 1 .438.187zm-1.065 1.064h-17.5v11.25h3.75c.169 0 .315.062.439.186s.186.271.186.439v3.105l4.609-3.594c.065-.052.13-.088.195-.107s.13-.029.195-.029h8.125V3.604z"></path>
                                </svg>
                            </i>SUBMIT </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="popup__body position-relative d-none flex-lg-column" id="filter_sidebar">
        <div class="popup-navigation js-popup-navigation back-white">
            <div class="popup-navigation__head pt-20 pb-10 px-10 d-lg-none">
                <div class="container">
                    <div class="popup-navigation__button d-flex align-items-center" data-js-popup-navigation-button="close">
                        <i class="popup-navigation__close cursor-pointer" data-js-popup-close="" data-button-content="close">
                            <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-theme-164" viewBox="0 0 24 24">
                                <path d="M19.583 4.965a.65.65 0 0 1-.176.449l-6.445 6.426 6.445 6.426c.117.131.176.28.176.449a.65.65 0 0 1-.176.449.846.846 0 0 1-.215.127.596.596 0 0 1-.468 0 .846.846 0 0 1-.215-.127l-6.426-6.445-6.426 6.445a.846.846 0 0 1-.215.127.596.596 0 0 1-.468 0 .846.846 0 0 1-.215-.127.65.65 0 0 1-.176-.449c0-.169.059-.318.176-.449l6.445-6.426-6.445-6.426a.65.65 0 0 1-.176-.449c0-.169.059-.318.176-.449a.652.652 0 0 1 .449-.176c.169 0 .319.059.449.176l6.426 6.445 6.426-6.445a.652.652 0 0 1 .449-.176c.169 0 .319.059.449.176.117.13.176.28.176.449z"></path>
                            </svg>
                        </i>
                        <i class="popup-navigation__back cursor-pointer d-lg-none" data-button-content="back">
                            <svg aria-hidden="true" focusable="false" role="presentation" class="icon icon-theme-012" viewBox="0 0 24 24">
                                <path d="M21.036 12.569a.601.601 0 0 1-.439.186H4.601l4.57 4.551c.117.13.176.28.176.449a.652.652 0 0 1-.176.449.877.877 0 0 1-.215.127.596.596 0 0 1-.468 0 .877.877 0 0 1-.215-.127l-5.625-5.625a2.48 2.48 0 0 1-.068-.107c-.02-.032-.042-.068-.068-.107a.736.736 0 0 1 0-.468 2.48 2.48 0 0 0 .068-.107c.02-.032.042-.068.068-.107l5.625-5.625a.652.652 0 0 1 .449-.176c.169 0 .319.059.449.176.117.13.176.28.176.449a.652.652 0 0 1-.176.449l-4.57 4.551h15.996a.6.6 0 0 1 .439.186.601.601 0 0 1 .186.439.599.599 0 0 1-.186.437z"></path>
                            </svg>
                        </i>
                    </div>
                </div>
            </div>
            <div class="popup-sidebar__content pt-50 px-15 py-30" data-js-position-mobile="sidebar">
                <?php include('product-sidebar.php')?>
            </div>
        </div>
    </div>
</div>