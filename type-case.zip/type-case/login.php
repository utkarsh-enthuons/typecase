<?php
session_start();
if(isset($_COOKIE["shopping_user"])){
	header("location:dashboard.php");
}
print_r($_COOKIE["shopping_user"]);
if(isset($_POST["login"])){
    include 'config.php';
        if(!empty($_POST['email']) && !empty($_POST['password'])) {
            $user=$_POST['email'];
            $pass=$_POST['password'];
            $query=mysqli_query($con,"SELECT * FROM tbl_customer WHERE cust_email='".$user."' AND cust_password='".$pass."'");
            $numrows=mysqli_num_rows($query);
            $valid=1;
            if($numrows!=0)
            {
                while($row=mysqli_fetch_assoc($query))
            {
            $dbusername=$row['cust_name']; 
            $dbpassword=$row['cust_password'];$dbEmail=$row['cust_email'];
            $id=$row['cust_id'];
            $status=$row['cust_status'];
            }
            if($status=='0'){
                    $re="Your account has been suspended.";
            } else {
                $cart_data = array();
                $item_array = array(
                    'Userid'		=>	$id,
                    'username'		=>	$dbusername,
                    'use_email'		=>	$dbEmail
                );
                $cart_data[] = $item_array;
        $item_data = json_encode($cart_data);
        setcookie('');
            setcookie('shopping_user',$item_data, time() + (86400 * 30));
            header("location:index.php?success=1");
            }
            }
            else {
            $re="<div class='alert alert-danger' role='alert'>Invalid username or password!</div>";
            }
        } else {
            $re= "<div class='alert alert-warning' role='alert'>All fields are required!</div>";
        }
        }
    
?>
<!DOCTYPE html>
<html>
<head>
    <?php include_once("include/head.php");
     ?>
</head>

<body>
    <div id="shopify-section-header" class="shopify-section">
        <div data-section-id="header" data-section-type="header">
            <?php include_once("include/header.php")?>
        </div>
    </div>
    <section class="sub-banner back_blue-1">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <ul
                        class="breadcrumbs py-2 list-unstyled d-inline-block flex-wrap justify-content-center justify-content-lg-start">
                        <li class="d-inline">
                            <a href="<?php path();?>" class="d-inline">Home</a>
                        </li class="d-inline">
                        <li>
                            <span>Account</span>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </section>
    <!-- product detail section started... -->
    <!-- business order started... -->
    <section class="py-30">
        <div class="container">
            <div class="row">
                <div class="col-md-9 col-lg-6 mx-auto">
                    <div class="card-box review-form">
                        <div class="card-box-body">
                          <?php echo $re; ?>
                            <h1 class="text-center title2 text-black mb-1">Login</h1>
                            <form  method="post" id="myform">
                                <div class="form-group">
                                    <!-- <label for="" class="text-black">Email*</label>  -->
                                    <input type="email" required="" class="form-control" name="email" placeholder="Your Email">
                                </div>
                                <div class="form-group">
                                    <!-- <label for="" class="text-black">Password*</label> -->
                                    <input class="form-control" required="" type="password" name="password" placeholder="Password">
                                </div>
                                <button type="submit" class="btn btn-aqua w-100" name="login">Login Now</button>
                                <div class="form-row mt-3">
                                    <div class="col-6">
                                        <a href="<?php path();?>/login" class="text-underline text-black d-inline-block">Already a User?</a>
                                    </div>
                                    <div class="col-6 text-right">
                                        <a href="" class="text-underline text-grey d-inline-block">Forgot Password?</a>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- business order ended... -->
    <?php include_once("include/footer.php")?>
</body>
</html>