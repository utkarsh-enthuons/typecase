<?php
setcookie("shopping_user","",time()-1);
header("location:login.php")
	
?>