<!DOCTYPE html>
<html>

<head>
    <?php include_once("include/head.php")?>
</head>

<body>
    <div id="shopify-section-header" class="shopify-section">
        <div data-section-id="header" data-section-type="header">
            <?php include_once("include/header.php")?>
        </div>
    </div>
    <!-- dash section started... -->
    <section class="py-60 back_blue-1">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <?php include_once("include/left_sidebar.php")?>
                </div>
                <div class="col-md-9">
                    <div class="card-box">
                        <div class="card-box-body">
                        <div class="order-table">
                            <table border="1">
                                <thead>
                                    <tr>
                                        <th>Sr. No.</th>
                                        <th>Product Name</th>
                                        <th>Order Date</th>
                                        <th>Delivery Date</th>
                                        <th>Track Package</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>1.</td>
                                        <td><a href="product-detail.php?id=35" target="_blank">Typecase Flexbook Keyboard Case with Touch for iPad Pro 12.9 5th/4th/3rd Gen (2021/2020/2018)</a></td>
                                        <td>12-Feb-2023</td>
                                        <td>18-Feb-2023</td>
                                        <td><a href="">Track Now</a></td>
                                    </tr>
                                    <tr>
                                        <td>2.</td>
                                        <td><a href="product-detail.php?id=35" target="_blank">Typecase Flexbook Keyboard Case with Touch for iPad Pro 12.9 5th/4th/3rd Gen (2021/2020/2018)</a></td>
                                        <td>12-Feb-2023</td>
                                        <td><span class="text-danger">Not Delivered Yet</span></td>
                                        <td><a href="">Track Now</a></td>
                                    </tr>
                                    <tr>
                                        <td>3.</td>
                                        <td><a href="product-detail.php?id=35" target="_blank">Typecase Flexbook Keyboard Case with Touch for iPad Pro 12.9 5th/4th/3rd Gen (2021/2020/2018)</a></td>
                                        <td>12-Feb-2023</td>
                                        <td>18-Feb-2023</td>
                                        <td><a href="">Track Now</a></td>
                                    </tr>
                                    <tr>
                                        <td>4.</td>
                                        <td><a href="product-detail.php?id=35" target="_blank">Typecase Flexbook Keyboard Case with Touch for iPad Pro 12.9 5th/4th/3rd Gen (2021/2020/2018)</a></td>
                                        <td>12-Feb-2023</td>
                                        <td><span class="text-danger">Not Delivered Yet</span></td>
                                        <td><a href="">Track Now</a></td>
                                    </tr>
                                    <tr>
                                        <td>5.</td>
                                        <td><a href="product-detail.php?id=35" target="_blank">Typecase Flexbook Keyboard Case with Touch for iPad Pro 12.9 5th/4th/3rd Gen (2021/2020/2018)</a></td>
                                        <td>12-Feb-2023</td>
                                        <td>18-Feb-2023</td>
                                        <td><a href="">Track Now</a></td>
                                    </tr>
                                    <tr>
                                        <td>6.</td>
                                        <td><a href="product-detail.php?id=35" target="_blank">Typecase Flexbook Keyboard Case with Touch for iPad Pro 12.9 5th/4th/3rd Gen (2021/2020/2018)</a></td>
                                        <td>12-Feb-2023</td>
                                        <td><span class="text-danger">Not Delivered Yet</span></td>
                                        <td><a href="">Track Now</a></td>
                                    </tr>
                                    <tr>
                                        <td>7.</td>
                                        <td><a href="product-detail.php?id=35" target="_blank">Typecase Flexbook Keyboard Case with Touch for iPad Pro 12.9 5th/4th/3rd Gen (2021/2020/2018)</a></td>
                                        <td>12-Feb-2023</td>
                                        <td>18-Feb-2023</td>
                                        <td><a href="">Track Now</a></td>
                                    </tr>
                                    <tr>
                                        <td>8.</td>
                                        <td><a href="product-detail.php?id=35" target="_blank">Typecase Flexbook Keyboard Case with Touch for iPad Pro 12.9 5th/4th/3rd Gen (2021/2020/2018)</a></td>
                                        <td>12-Feb-2023</td>
                                        <td><span class="text-danger">Not Delivered Yet</span></td>
                                        <td><a href="">Track Now</a></td>
                                    </tr>
                                    <tr>
                                        <td>9.</td>
                                        <td><a href="product-detail.php?id=35" target="_blank">Typecase Flexbook Keyboard Case with Touch for iPad Pro 12.9 5th/4th/3rd Gen (2021/2020/2018)</a></td>
                                        <td>12-Feb-2023</td>
                                        <td>18-Feb-2023</td>
                                        <td><a href="">Track Now</a></td>
                                    </tr>
                                    <tr>
                                        <td>10.</td>
                                        <td><a href="product-detail.php?id=35" target="_blank">Typecase Flexbook Keyboard Case with Touch for iPad Pro 12.9 5th/4th/3rd Gen (2021/2020/2018)</a></td>
                                        <td>12-Feb-2023</td>
                                        <td><span class="text-danger">Not Delivered Yet</span></td>
                                        <td><a href="">Track Now</a></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- dash section ended... -->
    <?php include_once("include/footer.php")?>
</body>
</html>