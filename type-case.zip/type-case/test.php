<!DOCTYPE html>
<html>
<head>
    <!-- Include jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
    <div id="product-container">
        <!-- Product data will be displayed here -->
    </div>

    <script>
        $(document).ready(function () {
            // Make an AJAX request to load the content from load_content.php
            $.ajax({
                url: 'ajax/load.php',
                method: 'GET',
                dataType: 'json',
                success: function (data) {
                    // Handle the JSON response and display the content
                    if (data.length > 0) {
                        var productContainer = $('#product-container');

                        data.forEach(function (product) {
                            var productHTML = '<div class="product">';
                            productHTML += '<h2>' + product.name + '</h2>';
                            // Add more product data as needed
                            productHTML += '</div>';

                            productContainer.append(productHTML);
                        });
                    } else {
                        // Handle the case when there are no products
                        $('#product-container').html('No products found.');
                    }
                },
                error: function (error) {
                    console.log('Error: ' + error);
                }
            });
        });
    </script>
</body>
</html>
