<!DOCTYPE html>
<html>

<head>
    <?php include_once("include/head.php")?>
</head>

<body>
    <div id="shopify-section-header" class="shopify-section">
        <div data-section-id="header" data-section-type="header">
            <?php include_once("include/header.php")?>
        </div>
    </div>
    <!-- dash section started... -->
    <section class="py-60 back_blue-1">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <?php include_once("include/left_sidebar.php")?>
                </div>
                <div class="col-md-9">
                    <div class="card-box">
                        <div class="card-box-body">
                            <div class="trace-order">
                                <div class="track-box active">
                                    <div class="track-span"><span></span></div>
                                    <div class="track-content">
                                        <h3>Ordered Friday, 27 Jan 2023</h3>
                                        <p>Package has left an Amazon facility at SURAT, GUJARAT at <span>8:07 PM Saturday, 28 January</span></p>
                                    </div>
                                </div>
                                <div class="track-box active">
                                    <div class="track-span"><span></span></div>
                                    <div class="track-content">
                                        <h3>Shipped Saturday 28, Jan 2023</h3>
                                        <p>Package has left an Amazon facility at SURAT, GUJARAT at <span>8:07 PM Saturday, 28 January</span></p>
                                        <p>Package has left an Amazon facility at SURAT, GUJARAT at <span>8:07 PM Saturday, 28 January</span></p>
                                        <p>Package has left an Amazon facility at SURAT, GUJARAT at <span>8:07 PM Saturday, 28 January</span></p>
                                        <p>Package has left an Amazon facility at SURAT, GUJARAT at <span>8:07 PM Saturday, 28 January</span></p>
                                        <p>Package has left an Amazon facility at SURAT, GUJARAT at <span>8:07 PM Saturday, 28 January</span></p>
                                    </div>
                                </div>
                                <div class="track-box">
                                    <div class="track-span"><span></span></div>
                                    <div class="track-content">
                                        <h3>Out for Delivery</h3>
                                    </div>
                                </div>
                                <div class="track-box">
                                    <div class="track-span"><span></span></div>
                                        <div class="track-content">
                                        <h3>Arriving Thursday</h3>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- dash section ended... -->
    <?php include_once("include/footer.php")?>
</body>
</html>