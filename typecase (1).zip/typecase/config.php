<?php

$con = mysqli_connect("localhost","wedigita_ty","typecase@1234","wedigita_typecase")or die("Not Database connect");


?>